"""命令行入口：工业智能体动态证据图。

用法示例：

    # 无 Key 纯规则模式，跑全部交易日志
    python main.py --mode rule

    # 只跑 IND-001、IND-053 两条，并输出可视化报告
    python main.py --mode rule --only IND-001 IND-053

    # 指定日志路径与产出目录
    python main.py --log data/monitor_log_60.json --out output --report report

    # 补证后重算（G6），新增证据写在 updates.json 中
    python main.py --mode rule --only IND-043 --updates updates.json

    # 打印生效配置（API Key 打码）后退出
    python main.py --print-config

环境变量（也可写入 .env）：
    EG_LLM_BASE_URL / EG_LLM_API_KEY / EG_LLM_MODEL / EG_MODE / EG_RENDER
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from config.settings import load_settings
from egraph.pipeline import (
    analyze_all,
    iter_summaries,
    load_updates,
    write_artifacts,
)
from egraph.render import render_all


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="evidence-graph",
        description="工业智能体动态证据图：从监控日志生成证据图 / 补查计划 / 置信度成绩单。",
    )
    parser.add_argument("--log", help="监控日志文件或目录（缺省自动探测 data/ 与交付原始路径）")
    parser.add_argument("--only", nargs="+", metavar="CASE_ID", help="仅处理指定 case_id，可多个")
    parser.add_argument(
        "--mode",
        choices=("rule", "hybrid", "llm"),
        help="运行模式：rule 纯规则 / hybrid 规则+模型（缺 Key 自动降级）/ llm 纯模型",
    )
    parser.add_argument("--out", help="产出 JSON 目录（缺省 output/）")
    parser.add_argument("--report", help="可视化报告目录（缺省 report/）")
    parser.add_argument("--updates", help="补证新增证据文件，形如 {case_id: [事件, ...]}")
    parser.add_argument("--no-render", action="store_true", help="不生成可视化报告")
    parser.add_argument("--no-validate", action="store_true", help="跳过产出物结构校验")
    parser.add_argument("--print-config", action="store_true", help="打印生效配置后退出")
    parser.add_argument("--json-summary", action="store_true", help="以 JSON 打印运行摘要")
    parser.add_argument("--quiet", action="store_true", help="只打印汇总，不逐条打印")
    return parser


def _overrides(args: argparse.Namespace) -> dict:
    overrides: dict = {}
    if args.log:
        overrides["log_path"] = args.log
    if args.only:
        overrides["only"] = args.only
    if args.mode:
        overrides["mode"] = args.mode
    if args.out:
        overrides["output_dir"] = args.out
    if args.report:
        overrides["report_dir"] = args.report
    if args.no_render:
        overrides["render"] = False
    return overrides


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    settings = load_settings(_overrides(args))

    if args.print_config:
        print(json.dumps(settings.to_dict(), ensure_ascii=False, indent=2))
        return 0

    updates = load_updates(args.updates) if args.updates else None

    try:
        artifacts = analyze_all(
            settings,
            updates=updates,
            validate=not args.no_validate,
        )
    except (FileNotFoundError, ValueError) as exc:
        print(f"[错误] {exc}", file=sys.stderr)
        return 2

    written = []
    for art in artifacts:
        paths = write_artifacts(art, settings.output_dir)
        written.append(paths)

    summaries = list(iter_summaries(artifacts))
    if args.json_summary:
        print(json.dumps(summaries, ensure_ascii=False, indent=2))
    else:
        _print_table(summaries)

    if settings.render and not args.no_render:
        render_all(artifacts, settings.report_dir)
        print(f"\n可视化报告：{settings.report_dir / 'index.html'}")
    print(f"产出 JSON：{settings.output_dir}")

    errors = [(a.run.case_id, a.schema_errors) for a in artifacts if a.schema_errors]
    if errors:
        print("\n[警告] 以下产出未通过结构校验：", file=sys.stderr)
        for case_id, messages in errors:
            print(f"  - {case_id}: {'；'.join(messages)}", file=sys.stderr)
        return 1
    return 0


def _print_table(summaries) -> None:
    header = ("CASE", "评级", "总分", "结论", "缺口", "动作", "高风险", "SCHEMA")
    widths = (9, 4, 6, 4, 4, 4, 6, 6)

    def _row(values):
        return "  ".join(str(v)[: w].ljust(w) for v, w in zip(values, widths))

    print(_row(header))
    print("-" * (sum(widths) + 2 * (len(widths) - 1)))
    for item in summaries:
        print(
            _row(
                (
                    item["case_id"],
                    item["grade"],
                    f"{item['overall']:.3f}",
                    item["claims"],
                    item["gaps"],
                    item["actions"],
                    item["flags"] or "-",
                    item["schema_errors"] or "ok",
                )
            )
        )
    grades: dict = {}
    for item in summaries:
        grades[item["grade"]] = grades.get(item["grade"], 0) + 1
    print("-" * (sum(widths) + 2 * (len(widths) - 1)))
    print(
        f"共 {len(summaries)} 条；评级分布 "
        + "，".join(f"{k}:{v}" for k, v in sorted(grades.items()))
    )


if __name__ == "__main__":
    sys.exit(main())
