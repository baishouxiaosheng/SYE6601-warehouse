"""配置模块。

集中管理工程运行时的全部可调参数，解析优先级由低到高：

1. ``config/config.json``      静态配置（评分配置、阈值、规则开关、单位表）
2. ``.env``                    项目根目录下的环境变量文件
3. 进程环境变量                  （同名变量覆盖 .env）
4. 调用方显式传入的 overrides    （例如 CLI 参数）

设计约束：只依赖 Python 标准库。API Key 未配置时依然能以纯规则模式完整跑通，
因此工程可先离线复现，稍后补充 Key 再切换到模型增强模式。
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

#: 工程根目录（evidence_graph/）
PROJECT_ROOT = Path(__file__).resolve().parent.parent

#: 未显式指定日志时，按顺序尝试的候选日志路径。
#: 前两个位于工程内便于随工程分发，后两个指向本次交付数据的原始位置。
DEFAULT_LOG_CANDIDATES: List[Path] = [
    PROJECT_ROOT / "data" / "monitor_log_60.json",
    PROJECT_ROOT / "data" / "industrial_agent_monitor_log.json",
    Path(r"D:\xwechat_files\wxid_3150771513011_3ef3\msg\file\2026-11\工业智能体模拟监控日志_60条(1).json"),
]


def load_dotenv(path: Path) -> Dict[str, str]:
    """极简 .env 解析：支持 ``KEY=VALUE``、``#`` 注释与引号包裹。"""
    result: Dict[str, str] = {}
    if not path.exists():
        return result
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        result[key.strip()] = value
    return result


@dataclass
class LLMSettings:
    """模型调用相关配置（OpenAI 兼容协议）。"""

    base_url: str = "https://api.openai.com/v1"
    api_key: str = ""
    model: str = "deepseek-chat"
    temperature: float = 0.0
    max_tokens: int = 4096
    timeout: int = 60
    max_retries: int = 3
    json_mode: bool = True

    def is_configured(self) -> bool:
        return bool(self.api_key and self.base_url and self.model)

    def masked(self) -> Dict[str, Any]:
        data = asdict(self)
        if data.get("api_key"):
            data["api_key"] = data["api_key"][:4] + "***"
        return data


@dataclass
class AppSettings:
    """应用级配置聚合对象。"""

    project_root: Path = PROJECT_ROOT
    prompts_dir: Path = PROJECT_ROOT / "prompts"
    schemas_dir: Path = PROJECT_ROOT / "schemas"
    output_dir: Path = PROJECT_ROOT / "output"
    report_dir: Path = PROJECT_ROOT / "report"

    #: 运行日志路径；None 表示自动探测 DEFAULT_LOG_CANDIDATES。
    log_path: Optional[Path] = None
    #: 运行模式：rule（纯规则）/ hybrid（规则+模型，缺 Key 自动降级）/ llm（纯模型）。
    mode: str = "hybrid"
    #: 仅处理指定 case_id（便于单例调试）。
    only: Optional[List[str]] = None
    #: 是否输出可视化报告。
    render: bool = True

    llm: LLMSettings = field(default_factory=LLMSettings)
    verify: Dict[str, Any] = field(default_factory=dict)
    scoring: Dict[str, Any] = field(default_factory=dict)
    rule_version: str = "1.0.0"

    def resolve_log_path(self) -> Path:
        """返回实际可用的日志路径，找不到时抛出 FileNotFoundError。"""
        candidates = [self.log_path] if self.log_path else list(DEFAULT_LOG_CANDIDATES)
        for candidate in candidates:
            if candidate and Path(candidate).exists():
                return Path(candidate)
        raise FileNotFoundError(
            "未找到监控日志，请通过 --log 指定，或把日志放到 data/ 目录。已尝试："
            + "；".join(str(c) for c in candidates)
        )

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["project_root"] = str(self.project_root)
        data["prompts_dir"] = str(self.prompts_dir)
        data["schemas_dir"] = str(self.schemas_dir)
        data["output_dir"] = str(self.output_dir)
        data["report_dir"] = str(self.report_dir)
        data["log_path"] = str(self.log_path) if self.log_path else None
        data["llm"] = self.llm.masked()
        return data


def _load_static_config(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on", "y"}


def load_settings(
    overrides: Optional[Dict[str, Any]] = None,
    env: Optional[Dict[str, str]] = None,
) -> AppSettings:
    """按优先级装配 AppSettings。

    :param overrides: 最高优先级，例如 ``{"mode": "rule", "log_path": "x.json"}``。
    :param env: 完整的环境变量快照（用于测试注入）；显式传入时**不再**读取
        进程环境变量与 ``.env``，以保证测试结果不受本机配置影响。缺省则读取
        ``os.environ`` 并与 ``.env`` 合并（进程环境变量优先）。
    """
    overrides = dict(overrides or {})
    if env is None:
        dotenv = load_dotenv(PROJECT_ROOT / ".env")
        process_env = dict(os.environ)
    else:
        dotenv = {}
        process_env = dict(env)

    def env_get(key: str, default: Optional[str] = None) -> Optional[str]:
        if key in process_env:
            return process_env[key]
        return dotenv.get(key, default)

    static_path = overrides.pop("config_path", PROJECT_ROOT / "config" / "config.json")
    static = _load_static_config(Path(static_path))

    llm = LLMSettings(
        base_url=env_get("EG_LLM_BASE_URL", env_get("OPENAI_BASE_URL", "https://api.openai.com/v1")) or "",
        api_key=env_get("EG_LLM_API_KEY", env_get("OPENAI_API_KEY", "")) or "",
        model=env_get("EG_LLM_MODEL", env_get("OPENAI_MODEL", "deepseek-chat")) or "deepseek-chat",
        temperature=float(env_get("EG_LLM_TEMPERATURE", "0") or 0),
        max_tokens=int(env_get("EG_LLM_MAX_TOKENS", "4096") or 4096),
        timeout=int(env_get("EG_LLM_TIMEOUT", "60") or 60),
        max_retries=int(env_get("EG_LLM_MAX_RETRIES", "3") or 3),
        json_mode=_as_bool(env_get("EG_LLM_JSON_MODE"), True),
    )

    settings = AppSettings(
        project_root=PROJECT_ROOT,
        prompts_dir=PROJECT_ROOT / "prompts",
        schemas_dir=PROJECT_ROOT / "schemas",
        output_dir=PROJECT_ROOT / "output",
        report_dir=PROJECT_ROOT / "report",
        log_path=None,
        mode=env_get("EG_MODE", "hybrid") or "hybrid",
        only=None,
        render=_as_bool(env_get("EG_RENDER"), True),
        llm=llm,
        verify=static.get("verify", {}),
        scoring=static.get("scoring", {}),
        rule_version=static.get("rule_version", "1.0.0"),
    )

    # 应用 overrides（CLI 参数）
    if "log_path" in overrides and overrides["log_path"]:
        settings.log_path = Path(overrides["log_path"]).expanduser()
    if "mode" in overrides and overrides["mode"]:
        settings.mode = str(overrides["mode"])
    if "only" in overrides and overrides["only"]:
        only = overrides["only"]
        settings.only = only if isinstance(only, list) else [str(only)]
    if "output_dir" in overrides and overrides["output_dir"]:
        settings.output_dir = Path(overrides["output_dir"])
    if "report_dir" in overrides and overrides["report_dir"]:
        settings.report_dir = Path(overrides["report_dir"])
    if "render" in overrides and overrides["render"] is not None:
        settings.render = bool(overrides["render"])
    if "rule_version" in overrides and overrides["rule_version"]:
        settings.rule_version = str(overrides["rule_version"])

    if settings.mode not in {"rule", "hybrid", "llm"}:
        raise ValueError(f"未知运行模式：{settings.mode}（可选 rule/hybrid/llm）")

    return settings
