# 任务：从日志可引用依据中提取业务规则（G2/G5）

## 输入

- 文档/知识库返回：
{{documents_json}}

- 工具返回中显式给出的状态、阈值与前置条件：
{{explicit_fields_json}}

## 要求

1. 每条规则必须给出来自日志的**逐字引用** `excerpt` 与来源定位 `locator`。
2. 提取规则的 `applicable_to`（适用对象/型号/设备）与 `condition`（触发条件）、
   `conclusion`（规则结论）。日志未给出的适用范围写 `null`，**不要推断**。
3. 区分三类：
   - `threshold_rule`：可复算的数值阈值（如“超过 190℃ 属异常”），需给出 `expression`。
   - `procedure_rule`：排查/操作建议（不可直接推出设备已故障）。
   - `authorization_rule`：审批/放行/许可类依据。
4. **日志里没有的规则不要提**。若某结论所需的规则在日志中找不到，写入 `missing_rules`。

## 输出 JSON

```json
{
  "rules": [
    {
      "kind": "threshold_rule",
      "text": "规则自然语言表述",
      "excerpt": "手册原文逐字引用",
      "locator": "trace[c4].result.excerpt",
      "applicable_to": "SZL-20",
      "condition": "排烟温度 > 190",
      "conclusion": "属于异常排查情形",
      "expression": "exhaust_temp_c > 190"
    }
  ],
  "missing_rules": [
    {"text": "所需但日志缺失的规则", "needed_by": "结论原文", "why": "无法在该依据下放行"}
  ]
}
```
