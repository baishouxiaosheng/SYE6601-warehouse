# 任务：提出结论到证据字段的映射（G5，模型提案）

## 输入

- 原子结论：{{claims_json}}
- 工具调用清单（仅含可定位字段路径）：
{{evidence_json}}

## 要求

1. 为每条结论给出**候选证据字段路径** `locator`，格式必须与清单中的字段路径完全一致。
2. 字段路径不存在或不确定时，把该映射放入 `unresolved`，不要编造路径。
3. 指出结论**尚缺的条件**（对象匹配、时间窗口、单位一致、状态、前置规则），
   每项给出 `kind` 与 `reason`。缺失的判定依据放入 `missing_rules`。
4. 单独判断是否存在**替代证据来源**：若两个不同工具能提供同等对象/范围/时效/权威性的信息，
   用 `alternative_to` 标出。
5. 你提出的所有内容都是**候选**（`review_status="proposed"`），不会单独使结论通过。

## 输出 JSON

```json
{
  "mappings": [
    {
      "claim": "结论原文",
      "locator": "trace[c1].result.system_pressure_kpa",
      "reason": "该字段直接给出系统压力读数",
      "confidence": 0.9
    }
  ],
  "unresolved": [
    {"claim": "结论原文", "reason": "回答中的对象在工具返回中找不到对应实体"}
  ],
  "missing_rules": [
    {"claim": "结论原文", "kind": "MISSING_RULE", "reason": "缺少该设备适用的放行规则来源"}
  ],
  "alternative_to": [
    {"claim": "结论原文", "primary": "toolA.field", "alternative": "toolB.field", "reason": "两者口径相同"}
  ]
}
```
