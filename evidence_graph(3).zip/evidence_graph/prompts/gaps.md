# 任务：提出潜在遗漏与证据缺口（G5）

## 输入

- 原子结论：{{claims_json}}
- 已执行的确定性检查结果：{{checks_json}}
- 现有缺口：{{gaps_json}}

## 要求

1. 指出**可能被忽略的前提**：对象是否匹配、时间窗口是否覆盖、单位是否一致、
   分页是否完整、状态是否离线、是否缺少适用规则或授权记录。
2. 每条缺口给出：`type`、受影响结论、`criticality`（HIGH/MEDIUM/LOW）、
   建议的目标来源 `target_source`。
3. 缺口类型取值：`MISSING_EVIDENCE` / `MISSING_RULE` / `MISSING_DEPENDENCY` /
   `INCOMPLETE_RESULT` / `CONFLICT` / `LIMITED_SCOPE`。
4. **审慎核查建议不得表述为已确认缺陷**。例如传感器校准记录缺失时应写
   “缺少校准记录（审慎核查建议，不代表传感器已失准）”。
5. 不要重复已存在于 `gaps_json` 中的缺口。

## 输出 JSON

```json
{
  "gaps": [
    {
      "type": "MISSING_RULE",
      "affected_claims": ["可以开机"],
      "description": "缺少适用的放行规则或明确授权记录",
      "criticality": "HIGH",
      "target_source": "设备放行审批记录 / 主管授权",
      "mandatory": false
    }
  ]
}
```
