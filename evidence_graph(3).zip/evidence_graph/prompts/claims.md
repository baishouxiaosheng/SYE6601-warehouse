# 任务：把最终回答拆解为原子结论（G1）

## 输入

- 用户问题：{{user_question}}
- 智能体回答：{{ai_answer}}
- 已拆解目标：{{goals_json}}

## 要求

1. **一个句子可包含多个原子结论，必须逐条拆开。**
   例：“保养已完成，系统显示可以启动，可以开机。”
   → 结论a=保养工单已完成；结论b=系统显示可启动；结论c=可以开机（放行动作）。
2. 每条结论给出 `assertion_strength`（断言强度），取值之一：
   - `reading`：直接读数或工具字段的直接转述
   - `approval`：审批/放行/完成状态的断言
   - `assertion`：一般事实性断言
   - `inference`：带推测措辞（可能 / 或许 / 大约 / 推测 / 看起来）
   - `negative_finding`：否定性发现（未找到 / 未发现 / 无法确定）
   - `recommendation`：操作建议（建议 / 应 / 需要 / 请）
3. 提取 `numerals`：结论中出现的**数值及其单位**，原样保留（这一步非常关键，
   单位写错的结论必须能被单独评价）。
4. 提取 `entities`：结论中的对象标识（设备编号、批次号、产线、工单号等）。
5. 标出 `covers_goals`：该结论回应了哪些目标（用目标序号，从 0 开始）；没有回应则空数组。
6. **不要把建议当成事实结论**，两者分别评价。

## 输出 JSON

```json
{
  "claims": [
    {
      "text": "原子结论原文",
      "assertion_strength": "reading",
      "numerals": [{"value": 21500, "unit": "MPa", "raw": "21500 MPa"}],
      "entities": ["HP-03"],
      "covers_goals": [0],
      "source_span": "回答中的原文定位片段"
    }
  ]
}
```
