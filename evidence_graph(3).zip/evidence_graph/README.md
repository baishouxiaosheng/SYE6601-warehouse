# 工业智能体动态证据图

从工业智能体的一次「监控日志」出发，自动生成三份交付物：**动态证据图**、**自动补证计划**、
**置信度成绩单**，并可渲染成自包含的可视化报告。

工程对应《工业智能体动态证据图需求说明》第 3–6 节：

| 需求 | 实现位置 |
| --- | --- |
| G1 目标拆解（问题 → 待回答目标） | [egraph/extract/goals.py](egraph/extract/goals.py) |
| G2 可定位证据（工具调用 → 返回字段） | [egraph/extract/evidence.py](egraph/extract/evidence.py) |
| G3 逻辑路径（AND / OR + 共同必要条件） | [egraph/graph.py](egraph/graph.py) |
| G4 规则约束与可复算检查 | [egraph/verify/engine.py](egraph/verify/engine.py) |
| G5 模型提案 / 规则产出的区分 | `created_by` / `review_status` 字段 |
| G6 新证据重算与差异留痕 | [egraph/pipeline.py](egraph/pipeline.py) `recompute_with_updates` |
| 第 3 节 证据图 | [egraph/graph.py](egraph/graph.py) |
| 第 4 节 B1–B3 自动补证 | [egraph/plan.py](egraph/plan.py) |
| 第 5 节 置信度成绩单 | [egraph/scorecard.py](egraph/scorecard.py) |
| 第 6 节 输出与验收 | [main.py](main.py) + [egraph/render.py](egraph/render.py) |
| 结构化输出校验 | [egraph/validate/schema.py](egraph/validate/schema.py) |
| Prompt 模板 | [prompts/](prompts) |
| 模型调用 | [egraph/llm/client.py](egraph/llm/client.py) |

> 工程**只依赖 Python 标准库**（Python ≥ 3.9）。模型调用基于 `urllib` 实现 OpenAI 兼容协议，
> 测试基于 `unittest`。**未配置 API Key 时自动降级为纯规则模式，链路依然完整可复现**。

---

## 1. 目录结构

```
evidence_graph/
├── main.py                  # 命令行入口
├── requirements.txt         # 仅说明依赖（无第三方包）
├── .env.example             # 环境变量样例（复制为 .env 填 Key）
├── config/
│   ├── settings.py          # 配置模块：.env / 环境变量 / 显式覆盖 的优先级装配
│   └── config.json          # 静态配置：评分配置、校验阈值、放行规则
├── egraph/
│   ├── models.py            # 数据模型（Node/Edge/Check/Gap/PlanAction/Scorecard…）
│   ├── loader.py            # 日志加载与规范化（文件 / 数组 / 目录 三种形态）
│   ├── extract/             # 抽取：goals / evidence / rules / claims / text
│   ├── verify/              # 规则约束校验：engine / units / timeutil
│   ├── graph.py             # 图结构生成算法（含 diff_graphs 重算差异）
│   ├── plan.py              # 自动补证计划（B1–B3）
│   ├── scorecard.py         # 置信度成绩单（三维度 + 逐结论评价）
│   ├── render.py            # 可视化：SVG + 单例 HTML 报告 + 批量总览
│   ├── pipeline.py          # 端到端编排
│   ├── llm/                 # 模型调用客户端与 Prompt 装载
│   └── validate/schema.py   # 结构化输出校验（JSON Schema 子集，零依赖）
├── prompts/                 # Prompt 模板（system/goals/claims/evidence_mapping/rules/gaps/review）
├── schemas/                 # 产出物与模型输出的 JSON Schema
├── data/monitor_log_60.json # 交付用监控日志（60 条）
├── output/                  # 产出：<case>_graph.json / _plan.json / _scorecard.json
├── report/                  # 产出：<case>_report.html 与 index.html
└── tests/                   # unittest 测试（57 个用例）
```

---

## 2. 环境要求

- Python **3.9 及以上**
- 无需安装任何第三方包

```powershell
python --version    # 确认 >= 3.9
```

---

## 3. 快速开始（无需 API Key）

在工程根目录 `evidence_graph/` 下执行：

```powershell
# 跑全部 60 条日志（纯规则模式），生成产出 JSON 与可视化报告
python main.py --mode rule

# 只跑验收场景
python main.py --mode rule --only IND-001 IND-002 IND-024 IND-030 IND-043 IND-053
```

运行后：

- `output/` 下生成 `IND-XXX_graph.json`、`IND-XXX_plan.json`、`IND-XXX_scorecard.json`；
- `report/` 下生成 `IND-XXX_report.html` 与总览 `index.html`；
- 终端打印 `CASE / 评级 / 总分 / 结论 / 缺口 / 动作 / 高风险 / SCHEMA` 汇总表。

### 预期验收结果（纯规则模式）

| CASE | 评级 | 总分 | 关键结论 |
| --- | --- | --- | --- |
| IND-001 | B | 0.864 | 排烟温度偏高链路完整，多数结论 SUPPORT |
| IND-002 | B | 0.786 | CLM-007「可以开机」= MISSING_RULE（缺放行依据） |
| IND-024 | E | 0.317 | CLM-001/002 = REFUTE（MPa 与 kPa 单位错误） |
| IND-030 | D | 0.550 | 触发 INCOMPLETE_RESULT（仅第 1/8 页）→ refetch_page |
| IND-043 | D | 0.550 | 触发 MISSING_EVIDENCE（夜班时段未覆盖） |
| IND-053 | C | 0.620 | CLM-005「可以正常作业」= REFUTE（18t 超出限重）→ CONFLICT |

---

## 4. 配置模型（可选，配 Key 后启用增强模式）

```powershell
Copy-Item .env.example .env
# 编辑 .env，填入 API Key 与端点（任意 OpenAI 兼容服务均可）
```

`.env` 关键项：

```ini
EG_LLM_BASE_URL=https://api.deepseek.com/v1
EG_LLM_API_KEY=<你的 Key>
EG_LLM_MODEL=deepseek-chat
EG_MODE=hybrid        # rule | hybrid | llm
```

配置优先级（由低到高）：`config/config.json` → `.env` → 进程环境变量 → 命令行参数。

模式说明：

- `rule`：**纯规则**，不调用模型（无 Key 也可运行，结果 100% 可复现）；
- `hybrid`：**规则 + 模型**，模型参与目标/结论/规则抽取，输出经结构化校验，不合规自动回落规则；
- `llm`：**纯模型**抽取（仍需规则兜底校验）。

> 模型只负责「提案」，确定性判断一律由代码复算（见第 7 节），因此换 Key 不会改变可复算结论。

---

## 5. 命令行用法

```text
python main.py [选项]

--log PATH          监控日志文件或目录（缺省自动探测 data/ 与交付原始路径）
--only CASE [CASE…] 仅处理指定 case_id
--mode {rule,hybrid,llm}
--out DIR           产出 JSON 目录（缺省 output/）
--report DIR        可视化报告目录（缺省 report/）
--updates PATH      补证新增证据文件（G6 重算），形如 {case_id: [事件, ...]}
--no-render         不生成可视化报告
--no-validate       跳过产出物结构校验
--print-config      打印生效配置（API Key 打码）后退出
--json-summary      以 JSON 打印运行摘要
--quiet             只打印汇总
```

示例：

```powershell
python main.py --print-config                       # 查看生效配置
python main.py --mode rule --only IND-001 --json-summary
python main.py --log data/monitor_log_60.json --out output --report report
python main.py --mode rule --only IND-043 --updates updates.json   # 补证后重算
```

---

## 6. 三类产出物

| 文件 | 内容 |
| --- | --- |
| `<case>_graph.json` | 动态证据图：`goals / nodes / edges / checks / paths / gaps / common_necessary_conditions / changes / limitations` |
| `<case>_plan.json` | 补证计划：每个动作含 `action_type / tool / known_arguments / pending_arguments / success_criterion / executability / priority` |
| `<case>_scorecard.json` | 置信度成绩单：三个维度得分、总分与评级、逐结论评价、高风险标记 |

三者用同一 `run_id` 与结论标识（`CLM-XXX`）关联。

关键状态字段（严格区分两类状态）：

- **命题证据状态** `evidence_status`：`SUPPORT / REFUTE / UNKNOWN / CONFLICT / MISSING_RULE`
- **结构审核状态** `review_status`：`proposed / verified / rejected / unresolved`

### 可视化报告

`report/index.html` 为总览，`report/<case>_report.html` 为单例报告（含证据图 SVG、逻辑路径与
共同必要条件、检查明细、缺口、补证计划、成绩单、边界说明）。HTML 内联 CSS/SVG，**零外部依赖、可离线打开**。

---

## 7. 设计要点

- **关系主轴**：`工具调用 → 返回字段 → 证据条件 → 推导规则 → 原子结论`（借鉴 W3C PROV-DM）。
- **模型提案 + 代码复算**：模型只提候选，确定性判断由 [egraph/verify/engine.py](egraph/verify/engine.py)
  复算，覆盖对象匹配、时间窗口、单位换算、空值/离线、分页完整性、显式状态/阈值/前置条件、字段复述。
  代码找不到依据时一律保留 `UNKNOWN`，不臆测。
- **AND / OR 路径**：一条路径内的条件为 AND，多条可替代路径为 OR，并计算所有路径的
  **共同必要条件**（`common_necessary_conditions`）。
- **可复现**：图/计划/成绩单均由确定性规则生成，相同输入必得相同输出（ID 序列稳定）；
  已由 `tests` 中的重复运行一致性用例保证。

---

## 8. 运行测试

```powershell
# 在工程根目录执行
python -m unittest discover -s tests -t .
```

覆盖内容：

- 文本与单位工具（数值/区间抽取、分句、单位换算）；
- 规则约束引擎（放行动作词边界不误伤设备名、复述 token、限值判定）；
- 图结构算法（目标非空、目标按句拆分、命题状态合法、逻辑路径与共同必要条件、确定性）；
- 端到端验收（IND-002/024/030/043/053 的状态/缺口/动作断言）与**全量 60 条结构合规**；
- 换一份不同工具/设备域的**异构日志**仍能稳定跑通，以及目录/包装形态加载；
- G6 补证重算；产出物 JSON Schema 校验与可视化渲染。

---

## 9. 换一份日志仍可复现

- [egraph/loader.py](egraph/loader.py) 支持**单条对象 / 数组 / `{"runs": [...]}` 包装 / 目录**四种输入；
- 抽取与校验全部基于通用规则（关键词、数值复算、字段定位），不硬编码任何 case；
- 新增日志只要含 `case_id / run_id / user_question / trace / ai_answer`，即可直接：

```powershell
python main.py --log D:\path\to\your_log.json --mode rule
```

若日志字段命名不同，可在 [egraph/extract/evidence.py](egraph/extract/evidence.py) 与
[egraph/verify/engine.py](egraph/verify/engine.py) 的信号识别处扩展，主链路无需改动。

---

## 10. 更新记录

### 2026-11-16

- **修复缺口悬空引用**（[egraph/verify/engine.py](egraph/verify/engine.py)）：
  断言强度为 `recommendation` 的结论在图结构里会转化为义务节点（`CLM-xxx → OBL-xxx`），
  但校验器此前仍按命题检查，生成的缺口会引用改名前的 id，形成悬空引用
  （如 IND-027 `GAP-003 → CLM-007`）。现新增 `NON_PROPOSITIONAL_STRENGTHS`，
  校验器只对命题结论做证据检查；全量 60 条悬空引用归零，评级分布不变。
- **新增回归断言**（[tests/test_pipeline_acceptance.py](tests/test_pipeline_acceptance.py)）：
  全量 60 条中每个缺口引用的结论 id 必须真实存在于图中。
- **配置读取隔离**（[config/settings.py](config/settings.py)）：显式传入 `env` 时不再读取
  `.env` 与进程环境变量，保证测试不受本地 Key 影响、结果稳定可复现。
