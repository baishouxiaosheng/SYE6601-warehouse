"""结构化输出校验与可视化测试。"""

from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from support import PROJECT_ROOT, artifacts_for  # noqa: E402

from egraph.render import render_all, render_graph_svg  # noqa: E402
from egraph.validate.schema import (  # noqa: E402
    SchemaError,
    artifact_schemas,
    load_schema,
    model_output_validator,
    validate_against,
)

SCHEMAS_DIR = PROJECT_ROOT / "schemas"


class SchemaValidationTest(unittest.TestCase):
    def test_type_mismatch_raises(self):
        schema = {"type": "object", "properties": {"n": {"type": "integer"}},
                  "required": ["n"]}
        with self.assertRaises(SchemaError):
            validate_against({"n": "not-an-int"}, schema)

    def test_enum_violation_raises(self):
        schema = {"type": "string", "enum": ["A", "B"]}
        with self.assertRaises(SchemaError):
            validate_against("C", schema)

    def test_valid_payload_passes(self):
        schema = {"type": "object", "properties": {"n": {"type": "number", "minimum": 0}},
                  "required": ["n"]}
        validate_against({"n": 1.5}, schema)  # 不抛异常即通过

    def test_artifact_schemas_load_three(self):
        schemas = artifact_schemas(SCHEMAS_DIR)
        self.assertEqual(set(schemas), {"graph", "plan", "scorecard"})

    def test_real_artifacts_match_their_schemas(self):
        artifacts = artifacts_for("IND-001")
        schemas = artifact_schemas(SCHEMAS_DIR)
        validate_against(artifacts.graph.to_dict(), schemas["graph"])
        validate_against(artifacts.plan.to_dict(), schemas["plan"])
        validate_against(artifacts.scorecard.to_dict(), schemas["scorecard"])

    def test_model_output_validator_rejects_missing_key(self):
        schema = load_schema("llm_goals", SCHEMAS_DIR)
        validate = model_output_validator(schema, ["goals"])
        with self.assertRaises(SchemaError):
            validate({"items": []})
        with self.assertRaises(SchemaError):
            # goals 为空数组不满足 minItems=1
            validate({"goals": []})
        # 合规输出应通过
        validate({"goals": [{"text": "排烟温度是否偏高？", "question_type": "diagnosis"}]})


class RenderTest(unittest.TestCase):
    def test_svg_contains_nodes_and_arrows(self):
        artifacts = artifacts_for("IND-001")
        svg = render_graph_svg(artifacts.graph, title="IND-001")
        self.assertIn("<svg", svg)
        self.assertIn("marker", svg)
        self.assertIn("CLM-001", svg)

    def test_render_all_writes_files(self):
        artifacts = [artifacts_for("IND-001"), artifacts_for("IND-030")]
        with tempfile.TemporaryDirectory() as tmp:
            written = render_all(artifacts, Path(tmp))
            self.assertIn("index", written)
            for case_id in ("IND-001", "IND-030"):
                path = written[case_id]
                self.assertTrue(path.exists())
                self.assertIn("证据图", path.read_text(encoding="utf-8"))
            self.assertTrue(written["index"].exists())


if __name__ == "__main__":
    unittest.main()
