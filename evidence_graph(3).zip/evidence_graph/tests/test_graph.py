"""图结构生成算法与目标抽取测试。"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from support import artifacts_for, rule_settings, run_for  # noqa: E402

from egraph.extract.goals import extract_goals_rule  # noqa: E402
from egraph.loader import RunRecord  # noqa: E402
from egraph.models import EVIDENCE_STATUSES, IdFactory  # noqa: E402
from egraph.pipeline import analyze_run  # noqa: E402


class GoalSplittingTest(unittest.TestCase):
    """回归：目标须按句子拆分，不得因句内逗号而丢失承载对象的前半句。"""

    def test_diagnosis_question_keeps_subject(self):
        run = RunRecord(
            case_id="T-1",
            run_id="R-1",
            user_question="三号锅炉排烟温度偏高了，看看怎么回事",
        )
        goals = extract_goals_rule(run)
        self.assertEqual(len(goals), 1)
        self.assertIn("三号锅炉", goals[0]["text"])
        self.assertIn("三号锅炉", goals[0]["subject"])

    def test_multi_sentence_question_splits(self):
        run = RunRecord(
            case_id="T-2",
            run_id="R-2",
            user_question="设备锁定解除了吗？保养工单完成了吗？",
        )
        goals = extract_goals_rule(run)
        self.assertEqual(len(goals), 2)

    def test_plain_statement_becomes_one_goal(self):
        run = RunRecord(case_id="T-3", run_id="R-3", user_question="今天产量统计一下")
        goals = extract_goals_rule(run)
        self.assertEqual(len(goals), 1)
        self.assertEqual(goals[0]["text"], "今天产量统计一下")


class GraphStructureTest(unittest.TestCase):
    def test_goals_are_populated(self):
        artifacts = artifacts_for("IND-001")
        self.assertTrue(artifacts.graph.goals, "graph.goals 不应为空")
        self.assertTrue(artifacts.graph.nodes_of("goal"))

    def test_claim_status_is_legal(self):
        for case_id in ("IND-001", "IND-007", "IND-024", "IND-053"):
            artifacts = artifacts_for(case_id)
            for node in artifacts.graph.nodes_of("claim"):
                self.assertIn(node.evidence_status, EVIDENCE_STATUSES, f"{case_id} {node.id}")

    def test_logic_paths_and_common_conditions(self):
        artifacts = artifacts_for("IND-001")
        self.assertTrue(artifacts.graph.paths, "应至少生成一条逻辑路径")
        assert_common = artifacts.graph.common_necessary_conditions
        self.assertTrue(assert_common, "应至少记录一条共同必要条件")
        sample = assert_common[0]
        self.assertIn("claim", sample)
        self.assertIn("condition", sample)
        self.assertTrue(sample["necessary_for_all_paths"])

    def test_edges_use_known_types(self):
        from egraph.models import EDGE_TYPES

        artifacts = artifacts_for("IND-053")
        self.assertTrue(artifacts.graph.edges)
        for edge in artifacts.graph.edges:
            self.assertIn(edge.type, EDGE_TYPES)

    def test_claims_linked_to_goals(self):
        artifacts = artifacts_for("IND-001")
        linked = [c for c in artifacts.graph.nodes_of("claim") if c.related_goals]
        self.assertTrue(linked, "至少有结论回应了用户目标")
        dimension = artifacts.scorecard.dimensions["question_coverage"]
        self.assertGreater(dimension["total"], 0)


class DeterminismTest(unittest.TestCase):
    """G4：相同输入必得相同输出，保证可复算、可复现。"""

    def test_repeat_run_is_identical(self):
        settings = rule_settings()
        run = run_for("IND-001")
        first = analyze_run(run, settings)
        second = analyze_run(run, settings)
        self.assertEqual(first.graph.to_dict(), second.graph.to_dict())
        self.assertEqual(first.scorecard.to_dict(), second.scorecard.to_dict())

    def test_id_factory_sequence_stable(self):
        factory = IdFactory()
        self.assertEqual(factory.next("CLM"), "CLM-001")
        self.assertEqual(factory.next("CLM"), "CLM-002")


if __name__ == "__main__":
    unittest.main()
