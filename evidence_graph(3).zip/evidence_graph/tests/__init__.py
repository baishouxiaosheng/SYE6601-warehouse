"""测试包。

运行方式（在工程根目录执行）::

    python -m unittest discover -s tests -t .
"""
