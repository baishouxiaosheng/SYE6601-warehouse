"""规则约束校验引擎测试（关键词边界与可复算工具函数）。"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from support import artifacts_for  # noqa: E402

from egraph.verify import engine  # noqa: E402


class ActionHintBoundaryTest(unittest.TestCase):
    """回归：设备名里的「起重」不得被当作放行动作而触发越限误判。"""

    def test_device_name_does_not_hit_action_hints(self):
        device_lines = (
            "CRANE-02桥式起重机已于2026年11月1日通过检验",
            "本次吊装使用桥式起重机",
        )
        for line in device_lines:
            self.assertFalse(
                engine._has(line, engine.ACTION_HINTS),
                f"设备名不应命中放行动作词：{line}",
            )

    def test_real_action_statement_hits(self):
        for line in ("可以正常作业", "能否吊", "可以开机"):
            self.assertTrue(engine._has(line, engine.ACTION_HINTS), line)

    def test_limit_hint_does_not_contain_nouns(self):
        self.assertNotIn("起重", engine.LIMIT_HINTS)
        self.assertNotIn("吊装", engine.LIMIT_HINTS)


class RestatementTokenTest(unittest.TestCase):
    def test_coding_tokens_are_kept(self):
        tokens = engine._restatement_tokens("当前使用 REC-204 的 R2 版本，证书 INSP-2026-CR-0215")
        lowered = {t.lower() for t in tokens}
        self.assertIn("rec-204", lowered)
        self.assertIn("r2", lowered)
        self.assertIn("insp-2026-cr-0215", lowered)

    def test_short_generic_words_are_dropped(self):
        # 「已」「通过」这类无区分度的短词不应进入复述 token
        tokens = engine._restatement_tokens("已通过 OK A")
        self.assertNotIn("OK", tokens)
        self.assertNotIn("A", tokens)

    def test_longer_tokens_rank_first(self):
        tokens = engine._restatement_tokens("R2 REC-204")
        self.assertEqual(tokens[0], "REC-204")


class VerdictHelperTest(unittest.TestCase):
    def test_combine_verdicts_priority(self):
        self.assertEqual(engine.combine_verdicts(["SUPPORT", "REFUTE"]), "REFUTE")
        self.assertEqual(engine.combine_verdicts(["UNKNOWN", "SUPPORT"]), "UNKNOWN")
        self.assertEqual(engine.combine_verdicts([]), "UNKNOWN")

    def test_violates(self):
        self.assertTrue(engine._violates("<=", 20.0, 18.0))
        self.assertFalse(engine._violates("<=", 18.0, 18.0))
        self.assertTrue(engine._violates(">=", 17.0, 18.0))
        self.assertFalse(engine._violates(">=", 18.0, 18.0))


class LimitRuleIntegrationTest(unittest.TestCase):
    """IND-053：限值规则应使「可以正常作业」被证伪，同时不误伤设备检验结论。"""

    def test_crane_case(self):
        artifacts = artifacts_for("IND-053")
        status = {n.id: n.evidence_status for n in artifacts.graph.nodes_of("claim")}
        self.assertEqual(status.get("CLM-005"), "REFUTE")
        self.assertEqual(status.get("CLM-001"), "SUPPORT")
        kinds = {c.kind for c in artifacts.graph.checks}
        self.assertIn("limit_threshold", kinds)


if __name__ == "__main__":
    unittest.main()
