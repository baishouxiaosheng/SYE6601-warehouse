"""测试公共支撑。

负责把工程根目录加入 ``sys.path``，并缓存 60 条日志与单例产物构建，
避免每个用例重复解析日志。所有用例都在 **纯规则模式** 下运行，
因此不依赖任何 API Key，结果可复现。
"""

from __future__ import annotations

import functools
import sys
from pathlib import Path
from typing import Dict, List, Tuple

TESTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = TESTS_DIR.parent
for _path in (str(PROJECT_ROOT), str(TESTS_DIR)):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from config.settings import AppSettings, load_settings          # noqa: E402
from egraph.loader import RunRecord, load_runs                  # noqa: E402
from egraph.models import Node                                  # noqa: E402
from egraph.pipeline import RunArtifacts, analyze_run           # noqa: E402

#: 工程内置的交付日志
DATA_LOG: Path = PROJECT_ROOT / "data" / "monitor_log_60.json"

#: 需求验收涉及的场景
ACCEPTANCE_CASES: Tuple[str, ...] = ("IND-002", "IND-024", "IND-030", "IND-043", "IND-053")


def rule_settings(**overrides) -> AppSettings:
    """构造强制纯规则模式的配置（无 Key 也能跑通）。"""
    overrides.setdefault("mode", "rule")
    return load_settings(overrides)


@functools.lru_cache(maxsize=1)
def all_runs() -> Tuple[RunRecord, ...]:
    return tuple(load_runs(DATA_LOG))


def run_for(case_id: str) -> RunRecord:
    for record in all_runs():
        if record.case_id == case_id:
            return record
    raise KeyError(f"日志中不存在 {case_id}")


def artifacts_for(case_id: str) -> RunArtifacts:
    """构建单条 case 的产物（纯规则）。"""
    return analyze_run(run_for(case_id), rule_settings())


def claims(artifacts: RunArtifacts) -> Dict[str, Node]:
    return {node.id: node for node in artifacts.graph.nodes_of("claim")}


def claim_status(artifacts: RunArtifacts, claim_id: str) -> str:
    node = claims(artifacts).get(claim_id)
    if node is None:
        raise KeyError(f"{artifacts.run.case_id} 中不存在结论 {claim_id}")
    return node.evidence_status or "UNKNOWN"


def gap_types(artifacts: RunArtifacts) -> List[str]:
    return [gap.type for gap in artifacts.graph.gaps]


def action_types(artifacts: RunArtifacts) -> List[str]:
    return [action.action_type for action in artifacts.plan.actions]
