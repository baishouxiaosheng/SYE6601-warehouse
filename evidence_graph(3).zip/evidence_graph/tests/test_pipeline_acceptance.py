"""端到端验收：需求要求的关键场景与“换一份日志仍能稳定跑通”。"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from support import (  # noqa: E402
    ACCEPTANCE_CASES,
    action_types,
    artifacts_for,
    claim_status,
    claims,
    gap_types,
    rule_settings,
)

from egraph.loader import load_runs, normalize_record  # noqa: E402
from egraph.pipeline import analyze_run, iter_summaries  # noqa: E402

VALID_GRADES = {"A", "B", "C", "D", "E", "N/A"}


class AcceptanceScenarioTest(unittest.TestCase):
    def test_ind002_missing_release_rule(self):
        artifacts = artifacts_for("IND-002")
        self.assertEqual(claim_status(artifacts, "CLM-007"), "MISSING_RULE")
        self.assertIn("MISSING_RULE", gap_types(artifacts))

    def test_ind024_unit_error_refutes(self):
        artifacts = artifacts_for("IND-024")
        self.assertEqual(claim_status(artifacts, "CLM-001"), "REFUTE")
        self.assertEqual(claim_status(artifacts, "CLM-002"), "REFUTE")
        unit_checks = [c for c in artifacts.graph.checks if c.kind == "unit_consistency"]
        self.assertTrue(unit_checks, "应产生单位一致性检查")
        self.assertTrue(any(c.status == "violated" for c in unit_checks))

    def test_ind030_incomplete_result_needs_refetch(self):
        artifacts = artifacts_for("IND-030")
        self.assertIn("INCOMPLETE_RESULT", gap_types(artifacts))
        types = action_types(artifacts)
        self.assertIn("refetch_page", types)
        refetch = next(a for a in artifacts.plan.actions if a.action_type == "refetch_page")
        self.assertEqual(refetch.executability, "executable")
        self.assertTrue(refetch.success_criterion)

    def test_ind043_missing_evidence_gap(self):
        artifacts = artifacts_for("IND-043")
        self.assertIn("MISSING_EVIDENCE", gap_types(artifacts))
        self.assertTrue(artifacts.plan.actions, "缺口应反推出补证动作")

    def test_ind053_limit_conflict(self):
        artifacts = artifacts_for("IND-053")
        self.assertEqual(claim_status(artifacts, "CLM-001"), "SUPPORT")
        self.assertEqual(claim_status(artifacts, "CLM-005"), "REFUTE")
        self.assertIn("CONFLICT", gap_types(artifacts))
        self.assertTrue(
            any(flag["severity"] == "HIGH" for flag in artifacts.scorecard.severity_flags)
        )

    def test_ind007_restatement_supported(self):
        # 回归：复述工具返回字段值（R2 / R3）的结论应被判为 SUPPORT
        artifacts = artifacts_for("IND-007")
        self.assertEqual(claim_status(artifacts, "CLM-002"), "SUPPORT")
        self.assertEqual(claim_status(artifacts, "CLM-004"), "SUPPORT")

    def test_acceptance_cases_schema_clean(self):
        for case_id in ACCEPTANCE_CASES:
            with self.subTest(case=case_id):
                artifacts = artifacts_for(case_id)
                self.assertEqual(artifacts.schema_errors, [])


class FullCorpusTest(unittest.TestCase):
    """全量日志：链路稳定、产出结构全部合规、评级合法。"""

    def test_all_60_runs_are_schema_clean(self):
        settings = rule_settings()
        runs = load_runs(Path(__file__).resolve().parent.parent / "data" / "monitor_log_60.json")
        self.assertEqual(len(runs), 60)
        summaries = []
        for run in runs:
            artifacts = analyze_run(run, settings)
            self.assertEqual(artifacts.schema_errors, [], f"{run.case_id} 结构校验失败")
            self.assertTrue(artifacts.graph.nodes_of("claim"), f"{run.case_id} 无结论节点")
            # 缺口引用的结论 id 必须真实存在（回归：操作建议转成 OBL 后不得留下悬空引用）
            node_ids = {node.id for node in artifacts.graph.nodes}
            for gap in artifacts.graph.gaps:
                for claim_id in gap.affected_claims or []:
                    self.assertIn(
                        claim_id, node_ids, f"{run.case_id} {gap.id} 引用了不存在的节点 {claim_id}"
                    )
            summaries.append(next(iter_summaries([artifacts])))
        for row in summaries:
            self.assertIn(row["grade"], VALID_GRADES)


class ForeignLogTest(unittest.TestCase):
    """换一份不同工具/设备域的日志，链路仍应稳定跑出三类产出物。"""

    SYNTHETIC = {
        "case_id": "EXT-001",
        "run_id": "EXT-001-r1",
        "user_question": "2号空压机排气温度正常吗？",
        "visible_context": {
            "site": "华南二厂",
            "workshop": "空压站",
            "received_at": "2026-11-14T09:00:00+08:00",
        },
        "trace": [
            {
                "id": "e1",
                "event": "tool_call",
                "type": "basic_lookup",
                "tool": "asset_registry.find",
                "arguments": {"site": "华南二厂", "workshop": "空压站", "display_name": "2号空压机"},
                "result": {"asset_id": "AC-02", "equipment_model": "GA-90"},
            },
            {
                "id": "e2",
                "event": "tool_call",
                "type": "ops_monitoring",
                "tool": "plant_monitor.get_outlet_temp",
                "arguments": {"asset_id": "AC-02", "lookback_minutes": 60},
                "result": {
                    "as_of": "2026-11-14T09:00:00+08:00",
                    "sensors": [
                        {
                            "sensor_id": "TO-AC02-01",
                            "position": "排气口",
                            "current_c": 96,
                            "normal_range_c": [70, 95],
                            "trend_2h": "RISING",
                            "data_quality": "GOOD",
                        }
                    ],
                },
            },
        ],
        "ai_answer": "2号空压机排气口温度为96℃，已超出正常范围（70-95℃），属于异常。",
    }

    def test_synthetic_run_analyzes(self):
        run = normalize_record(json.loads(json.dumps(self.SYNTHETIC, ensure_ascii=False)))
        artifacts = analyze_run(run, rule_settings())
        self.assertEqual(artifacts.schema_errors, [])
        self.assertTrue(artifacts.graph.goals)
        self.assertTrue(artifacts.graph.nodes_of("claim"))
        self.assertTrue(artifacts.graph.nodes_of("evidence"))
        self.assertTrue(artifacts.graph.checks, "应产出可复算检查")
        self.assertTrue(artifacts.plan is not None and artifacts.scorecard is not None)

    def test_loader_accepts_wrapper_and_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            wrapped = Path(tmp) / "a.json"
            wrapped.write_text(
                json.dumps({"runs": [self.SYNTHETIC]}, ensure_ascii=False), encoding="utf-8"
            )
            loaded = load_runs(wrapped)
            self.assertEqual([r.case_id for r in loaded], ["EXT-001"])

            nested = Path(tmp) / "sub"
            nested.mkdir()
            (nested / "b.json").write_text(
                json.dumps([self.SYNTHETIC], ensure_ascii=False), encoding="utf-8"
            )
            from_dir = load_runs(Path(tmp))
            self.assertIn("EXT-001", {r.case_id for r in from_dir})

    def test_missing_required_field_raises(self):
        with self.assertRaises(ValueError):
            normalize_record({"case_id": "X", "run_id": "Y"})


class UpdateRecomputeTest(unittest.TestCase):
    """G6：补证后重算应记录差异。"""

    def test_recompute_records_changes(self):
        from egraph.pipeline import recompute_with_updates

        artifacts = artifacts_for("IND-043")
        extra = [
            {
                "id": "u1",
                "event": "tool_call",
                "type": "ops_monitoring",
                "tool": "mes.get_output_by_shift",
                "arguments": {"line_id": "D", "date": "2026-11-13"},
                "result": {"shifts": [{"shift": "night", "output": 1000},
                                      {"shift": "day", "output": 1800},
                                      {"shift": "middle", "output": 2400}]},
            }
        ]
        after = recompute_with_updates(artifacts, rule_settings(), extra)
        self.assertEqual(after.schema_errors, [])
        self.assertTrue(after.plan.notes and any("重算" in n for n in after.plan.notes))


if __name__ == "__main__":
    unittest.main()
