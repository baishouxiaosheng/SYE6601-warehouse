"""文本处理与单位换算工具测试。"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from support import PROJECT_ROOT  # noqa: E402

from egraph.extract import text as text_mod  # noqa: E402
from egraph.verify import units  # noqa: E402


class NumeralTest(unittest.TestCase):
    def test_single_value_with_unit(self):
        found = text_mod.extract_numerals("排烟温度 218℃ 偏高")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].value, 218.0)
        self.assertEqual(found[0].unit, "℃")
        self.assertFalse(found[0].is_range)

    def test_range_value(self):
        found = text_mod.extract_numerals("正常区间 140-190℃")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].value, 140.0)
        self.assertEqual(found[0].upper, 190.0)
        self.assertTrue(found[0].is_range)

    def test_thousands_separator_and_percent(self):
        found = text_mod.extract_numerals("系统压力 21,500 kPa，负载率 5.8%")
        self.assertEqual([n.value for n in found], [21500.0, 5.8])
        self.assertEqual([n.unit for n in found], ["kPa", "%"])

    def test_bare_numbers_are_ignored(self):
        # 日期、编号等不带单位的数字不应被误抽为带单位数值
        self.assertEqual(text_mod.extract_numerals("11月13日 工单 WO-28501"), [])


class SplitTest(unittest.TestCase):
    def test_split_sentences(self):
        self.assertEqual(
            text_mod.split_sentences("排烟温度偏高了。看看怎么回事！"),
            ["排烟温度偏高了", "看看怎么回事"],
        )

    def test_keyword_overlap_is_symmetric(self):
        a = text_mod.keyword_overlap("三号锅炉排烟温度偏高", "三号锅炉排烟温度偏高了，看看怎么回事")
        b = text_mod.keyword_overlap("三号锅炉排烟温度偏高了，看看怎么回事", "三号锅炉排烟温度偏高")
        self.assertAlmostEqual(a, b, places=9)
        self.assertGreater(a, 0.2)


class UnitTest(unittest.TestCase):
    def test_same_dimension(self):
        self.assertEqual(units.resolve("MPa").dimension, units.resolve("kPa").dimension)
        self.assertTrue(units.same_dimension("MPa", "kPa"))
        self.assertFalse(units.same_dimension("℃", "kPa"))

    def test_convert_within_dimension(self):
        converted = units.convert(25.0, "MPa", "kPa")
        self.assertIsNotNone(converted)
        self.assertAlmostEqual(converted, 25000.0, places=3)

    def test_cross_dimension_returns_none(self):
        self.assertIsNone(units.convert(1.0, "℃", "kg"))


class PromptFilesTest(unittest.TestCase):
    def test_prompt_files_exist(self):
        prompts_dir = PROJECT_ROOT / "prompts"
        for name in ("system", "goals", "claims", "evidence_mapping", "rules", "gaps", "review"):
            self.assertTrue((prompts_dir / f"{name}.md").exists(), f"缺少 prompts/{name}.md")


if __name__ == "__main__":
    unittest.main()
