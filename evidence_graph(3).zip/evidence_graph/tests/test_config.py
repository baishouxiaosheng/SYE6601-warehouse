"""配置模块测试：优先级、覆盖项与 Key 打码。"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from support import DATA_LOG  # noqa: E402

from config.settings import load_settings  # noqa: E402


class SettingsTest(unittest.TestCase):
    def test_default_is_hybrid(self):
        settings = load_settings({}, env={})
        self.assertEqual(settings.mode, "hybrid")

    def test_override_mode_rule(self):
        self.assertEqual(load_settings({"mode": "rule"}, env={}).mode, "rule")

    def test_unknown_mode_raises(self):
        with self.assertRaises(ValueError):
            load_settings({"mode": "bogus"}, env={})

    def test_only_override_normalised_to_list(self):
        self.assertEqual(load_settings({"only": "IND-001"}, env={}).only, ["IND-001"])
        self.assertEqual(load_settings({"only": ["IND-001", "IND-002"]}, env={}).only,
                         ["IND-001", "IND-002"])

    def test_log_path_override(self):
        settings = load_settings({"log_path": str(DATA_LOG)}, env={})
        self.assertEqual(settings.resolve_log_path(), DATA_LOG)

    def test_env_injection_configures_llm(self):
        settings = load_settings(
            {},
            env={
                "EG_LLM_API_KEY": "sk-secret",
                "EG_LLM_BASE_URL": "https://example.com/v1",
                "EG_LLM_MODEL": "demo-model",
                "EG_MODE": "hybrid",
            },
        )
        self.assertTrue(settings.llm.is_configured())
        self.assertEqual(settings.llm.model, "demo-model")

    def test_no_key_means_rule_only(self):
        settings = load_settings({"mode": "rule"}, env={})
        self.assertFalse(settings.llm.is_configured())

    def test_masked_hides_key(self):
        settings = load_settings({}, env={"EG_LLM_API_KEY": "sk-secret"})
        self.assertEqual(settings.llm.masked()["api_key"], "sk-s***")
        self.assertEqual(settings.to_dict()["llm"]["api_key"], "sk-s***")


if __name__ == "__main__":
    unittest.main()
