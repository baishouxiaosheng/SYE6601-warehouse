"""图结构生成算法（对应需求第 3 节 G1–G6）。

职责：
* 把目标、结论、证据、规则、证据条件、义务组装成一张**有向证据图**，
  关系主轴为 ``工具调用 → 返回字段 → 证据条件 → 推导规则 → 原子结论``；
* 依据 :mod:`egraph.verify.engine` 产出的可复算检查，为每条结论推导命题证据状态；
* 以 **AND** 表示一条路径上需同时满足的条件，以 **OR** 表示可替代的充分路径，
  并记录所有路径的**共同必要条件**（G3）；
* 保留模型提案与规则产出的区别（``created_by`` / ``review_status``，G5）；
* 提供 :func:`diff_graphs`，用于新证据/规则更新后的重算差异留痕（G6）。

本模块只使用**确定性规则**，相同输入必得相同输出，满足 G4 的可复算要求。
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from .extract.evidence import EvidenceBundle
from .extract.text import keyword_overlap
from .loader import RunRecord
from .models import (
    Check,
    Edge,
    EvidenceGraph,
    Gap,
    Goal,
    IdFactory,
    LogicPath,
    Node,
)
from .verify.engine import VerifyOutcome

#: 图版本后缀
GRAPH_VERSION_SUFFIX = "evidence-graph-v1"

#: 命题证据状态优先级（越靠前越具决定性）
VERDICT_PRIORITY: Tuple[str, ...] = ("REFUTE", "CONFLICT", "MISSING_RULE", "UNKNOWN", "SUPPORT")

#: “关于证据是否充分的表述”：当图中确有缺口时，这类结论本身可被判为被支持
INSUFFICIENCY_PHRASES = (
    "不足以", "无法确定", "尚不能确定", "暂无法", "未能确定", "无法判断", "不能确定", "无法给出",
)

#: 断言强度为“操作建议”的结论应转化为义务节点，而非作为命题参与证据评价
OBLIGATION_STRENGTHS = ("recommendation",)

#: 结论与目标关联所需的词面重叠下限（Jaccard）
GOAL_MATCH_OVERLAP = 0.2


# --------------------------------------------------------------------------
# 对外主入口
# --------------------------------------------------------------------------


def build_graph(
    *,
    run: RunRecord,
    ids: IdFactory,
    goals: List[Goal],
    claims: List[Node],
    bundle: EvidenceBundle,
    rules: List[Node],
    outcome: VerifyOutcome,
    extra_gaps: Optional[Sequence[Gap]] = None,
    global_obligations: Optional[Sequence[str]] = None,
) -> EvidenceGraph:
    """组装单次运行的动态证据图。"""
    graph = EvidenceGraph(
        graph_version=f"{run.case_id}-{GRAPH_VERSION_SUFFIX}",
        run_id=run.run_id,
        case_id=run.case_id,
        task=_build_task(run, bundle),
        scope_declaration=_build_scope(run, goals),
        goals=list(goals),
    )

    # 1) 目标节点
    for goal in goals:
        graph.add_node(
            Node(
                id=goal.id,
                type="goal",
                content=goal.text,
                created_by="rule",
                review_status="proposed",
                meta={"question_type": goal.question_type, "subject": goal.subject},
            )
        )

    # 2) 结论节点：把“操作建议”拆成义务节点，其余作为命题结论
    claim_nodes: List[Node] = []
    obligation_nodes: List[Node] = []
    for claim in claims:
        if claim.assertion_strength in OBLIGATION_STRENGTHS:
            obligation_nodes.append(
                Node(
                    id=claim.id.replace("CLM", "OBL"),
                    type="obligation",
                    content=claim.content,
                    created_by=claim.created_by,
                    review_status="proposed",
                    meta={"derived_from_claim": claim.id},
                )
            )
            continue
        claim_nodes.append(claim)

    # 3) 证据 / 事实 / 规则 / 条件节点
    for node in bundle.nodes:
        graph.add_node(node)
    for fact in outcome.facts:
        graph.add_node(fact)
    for rule in rules:
        graph.add_node(rule)
    for condition in outcome.conditions:
        graph.add_node(condition)

    # 4) 检查与缺口
    graph.checks = list(outcome.checks)
    graph.gaps = list(outcome.gaps)
    if extra_gaps:
        for gap in extra_gaps:
            graph.gaps.append(gap)

    condition_by_check = _condition_index(outcome.conditions)

    # 5) 结论状态推导 + 逻辑路径
    for claim in claim_nodes:
        checks = _checks_for(claim.id, graph.checks)
        claim.evidence_status, claim.meta["verdict_reason"] = _derive_status(
            claim, checks, gaps_exist=bool(graph.gaps)
        )
        claim.related_goals = _related_goals(claim, goals)
        claim.meta["checks"] = [c.check_id for c in checks]
        graph.add_node(claim)
        graph.paths.extend(_build_paths(claim, checks, condition_by_check, ids))

    for obligation in obligation_nodes:
        graph.add_node(obligation)

    # 6) 额外的全局义务（例如人工确认事项）
    for index, text in enumerate(global_obligations or []):
        graph.add_node(
            Node(
                id=ids.next("OBL"),
                type="obligation",
                content=text,
                created_by="rule",
                review_status="proposed",
                meta={"source": "gap"},
            )
        )

    # 7) 边
    _build_edges(graph, goals, condition_by_check)

    # 8) 共同必要条件、边界与说明
    graph.common_necessary_conditions = _common_conditions(graph)
    graph.limitations = _collect_limitations(graph, claim_nodes)
    graph.proposal_status = "proposed"
    if not graph.limitations:
        graph.limitations = ["本图为基于单份监控日志的离线分析结果，不代表数据源的现实真实性。"]
    return graph


# --------------------------------------------------------------------------
# 任务与范围
# --------------------------------------------------------------------------


def _first_id(bundle: EvidenceBundle, keys: Iterable[str]) -> Optional[str]:
    wanted = {k.lower() for k in keys}
    for signal in bundle.signals:
        if signal.kind == "id" and str(signal.key).lower() in wanted and isinstance(signal.value, str):
            return signal.value
    return None


def _build_task(run: RunRecord, bundle: EvidenceBundle) -> Dict[str, Any]:
    incident = _first_id(bundle, ("asset_id", "equipment_id", "incident_id", "line_id"))
    if incident is None:
        incident = run.visible_context.get("incident_id") or run.visible_context.get("asset_id")
    return {
        "task_id": run.case_id,
        "run_id": run.run_id,
        "question": run.user_question,
        "customer_id": run.visible_context.get("customer_id"),
        "incident_id": incident,
        "event_time": run.received_at,
    }


def _build_scope(run: RunRecord, goals: List[Goal]) -> Dict[str, Any]:
    subjects = [g.subject for g in goals if g.subject]
    scope = "；".join(subjects) if subjects else run.user_question
    return {
        "scope": f"{run.case_id}：{scope}",
        "in_scope": [g.text for g in goals] or [run.user_question],
        "out_of_scope": [
            "未经日志证据支持的具体故障诊断或因果结论",
            "日志未提供依据的业务规则、参数基准与适用范围",
        ],
    }


# --------------------------------------------------------------------------
# 结论状态推导
# --------------------------------------------------------------------------


def _checks_for(claim_id: str, checks: Sequence[Check]) -> List[Check]:
    return [c for c in checks if claim_id in (c.affected_claims or [])]


def _dominant_verdict(checks: Sequence[Check]) -> str:
    verdicts = {c.verdict for c in checks if c.verdict}
    for candidate in VERDICT_PRIORITY:
        if candidate in verdicts:
            return candidate
    return "UNKNOWN"


def _derive_status(claim: Node, checks: Sequence[Check], gaps_exist: bool) -> Tuple[str, str]:
    """由可复算检查推导结论的命题证据状态，并给出理由。"""
    verdict = _dominant_verdict(checks)
    if verdict == "UNKNOWN" and _expresses_insufficiency(claim.content) and gaps_exist:
        return (
            "SUPPORT",
            "图中确实存在证据缺口，该结论关于“现有证据不足”的表述本身得到支持",
        )
    reason = {
        "SUPPORT": "现有证据条件全部满足",
        "REFUTE": "存在与结论直接矛盾的可复算检查结果",
        "CONFLICT": "结论与日志给出的限制/规则冲突",
        "MISSING_RULE": "缺少判定所必需的适用规则或授权依据",
        "UNKNOWN": "日志未给出足以判定的依据，按规则保留未知",
    }.get(verdict, "日志未给出足以判定的依据")
    return verdict, reason


def _expresses_insufficiency(text: str) -> bool:
    return any(phrase in (text or "") for phrase in INSUFFICIENCY_PHRASES)


def _related_goals(claim: Node, goals: List[Goal]) -> List[str]:
    """判定一条结论回应了哪些目标（用于问题覆盖度与 claim→goal 边）。

    依次尝试：抽取阶段给出的 ``covers_goals`` → 目标主语包含 → 词面重叠达阈值
    → 与目标共享编码类 token（``R3``、``BLR-03`` 等）。全部为确定性规则。
    """
    related: List[str] = []
    for position in claim.meta.get("covers_goals") or []:
        if isinstance(position, int) and 0 <= position < len(goals):
            related.append(goals[position].id)
    if related:
        return related
    for goal in goals:
        if _claim_addresses(claim, goal):
            related.append(goal.id)
    return related


def _claim_addresses(claim: Node, goal: Goal) -> bool:
    text = claim.content or ""
    subject = (goal.subject or "").strip()
    if len(subject) >= 2 and subject in text:
        return True
    if keyword_overlap(text, goal.text) >= GOAL_MATCH_OVERLAP:
        return True
    return bool(_codes(text) & _codes(goal.text))


def _codes(text: str) -> Set[str]:
    """抽出文本中的字母数字编码 token（设备/证书/版本号等）。"""
    return {token.lower() for token in re.findall(r"[A-Za-z0-9][A-Za-z0-9\-_/]{1,}", text or "")}


# --------------------------------------------------------------------------
# 逻辑路径（G3）
# --------------------------------------------------------------------------


def _condition_index(conditions: Sequence[Node]) -> Dict[str, Node]:
    index: Dict[str, Node] = {}
    for node in conditions:
        check_id = (node.meta or {}).get("check_id")
        if check_id:
            index[check_id] = node
    return index


def _build_paths(
    claim: Node,
    checks: Sequence[Check],
    condition_by_check: Dict[str, Node],
    ids: IdFactory,
) -> List[LogicPath]:
    """按“证据/规则来源”分组条件，每组构成一条 AND 路径；组间为 OR 关系。"""
    groups: Dict[str, List[Check]] = {}
    for check in checks:
        key = check.evidence_ref or check.rule_id or "__direct__"
        groups.setdefault(str(key), []).append(check)

    paths: List[LogicPath] = []
    for key, group in groups.items():
        condition_ids = [condition_by_check[c.check_id].id for c in group if c.check_id in condition_by_check]
        satisfied = [condition_by_check[c.check_id].id for c in group
                     if c.check_id in condition_by_check and c.status == "satisfied"]
        missing = [condition_by_check[c.check_id].id for c in group
                   if c.check_id in condition_by_check and c.status in ("violated", "unknown")]
        rationale = (
            f"路径来源 {key}，需同时满足 {len(condition_ids)} 个条件："
            + "；".join(c.description for c in group)
        )
        paths.append(
            LogicPath(
                path_id=ids.next("PATH"),
                goal_claim=claim.id,
                conditions=condition_ids,
                satisfied=not missing,
                satisfied_conditions=satisfied,
                missing_conditions=missing,
                rationale=rationale,
                created_by="rule",
            )
        )
    if len(paths) > 1:
        paths.insert(
            0,
            LogicPath(
                path_id=ids.next("PATH"),
                goal_claim=claim.id,
                conditions=[],
                satisfied=any(p.satisfied for p in paths),
                satisfied_conditions=[],
                missing_conditions=[],
                rationale=f"该结论存在 {len(paths)} 条可替代路径（OR）；任一路径满足即可成立。",
                created_by="rule",
            ),
        )
    return paths


def _common_conditions(graph: EvidenceGraph) -> List[Dict[str, Any]]:
    """计算每条结论所有路径的共同必要条件。"""
    by_claim: Dict[str, List[LogicPath]] = {}
    for path in graph.paths:
        if not path.conditions and "可替代路径" in path.rationale:
            continue
        by_claim.setdefault(path.goal_claim, []).append(path)

    result: List[Dict[str, Any]] = []
    for claim_id, paths in by_claim.items():
        common: Optional[Set[str]] = None
        for path in paths:
            conds = set(path.conditions)
            common = conds if common is None else (common & conds)
        for cond_id in sorted(common or []):
            node = graph.node(cond_id)
            result.append(
                {
                    "claim": claim_id,
                    "condition": cond_id,
                    "content": node.content if node else "",
                    "status": (node.meta or {}).get("status") if node else None,
                    "paths": [p.path_id for p in paths],
                    "necessary_for_all_paths": True,
                }
            )
    return result


# --------------------------------------------------------------------------
# 边
# --------------------------------------------------------------------------


def _add_edge(
    graph: EvidenceGraph,
    seen: Set[Tuple[str, str, str]],
    source: str,
    target: str,
    edge_type: str,
    *,
    logic: Optional[str] = None,
    rationale: str = "",
    created_by: str = "rule",
) -> None:
    if not source or not target or source == target:
        return
    key = (source, target, edge_type)
    if key in seen:
        return
    seen.add(key)
    graph.add_edge(
        Edge(
            id=f"E-{len(graph.edges) + 1:04d}",
            source=source,
            target=target,
            type=edge_type,
            logic=logic,
            rationale=rationale,
            created_by=created_by,
            review_status="verified" if created_by == "rule" else "proposed",
        )
    )


def _build_edges(graph: EvidenceGraph, goals: List[Goal], condition_by_check: Dict[str, Node]) -> None:
    seen: Set[Tuple[str, str, str]] = set()
    node_ids = {n.id for n in graph.nodes}

    for check in graph.checks:
        for claim_id in check.affected_claims or []:
            if claim_id not in node_ids:
                continue
            edge_type = _verdict_edge(check.verdict)
            if check.evidence_ref and check.evidence_ref in node_ids:
                _add_edge(
                    graph, seen, check.evidence_ref, claim_id, edge_type,
                    rationale=check.description,
                )
            if check.rule_id and check.rule_id in node_ids:
                _add_edge(
                    graph, seen, check.rule_id, claim_id, edge_type,
                    rationale=f"依据规则：{check.description}",
                )
            condition = condition_by_check.get(check.check_id)
            if condition is not None:
                _add_edge(
                    graph, seen, condition.id, claim_id,
                    "supports" if check.status == "satisfied" else "checks",
                    logic="AND",
                    rationale=f"证据条件（{check.status}）：{check.description}",
                )
            if check.rule_id and condition is not None and check.rule_id in node_ids:
                _add_edge(graph, seen, check.rule_id, condition.id, "requires")

    # 事实由证据字段复算而来
    for fact in graph.nodes_of("fact"):
        if fact.source_id and fact.source_id in node_ids:
            _add_edge(graph, seen, fact.id, fact.source_id, "derived_from",
                      rationale="事实由该证据字段复算得到")

    # 结论 → 目标（该结论回应哪个目标）
    goal_by_id = {g.id: g for g in goals}
    for claim in graph.nodes_of("claim"):
        for goal_id in claim.related_goals:
            if goal_id in goal_by_id:
                _add_edge(graph, seen, claim.id, goal_id, "supports",
                          rationale="该结论用于回答此目标")

    # 义务 → 缺口
    for gap in graph.gaps:
        for condition_id in [gap.missing_condition] if gap.missing_condition else []:
            if condition_id in node_ids:
                _add_edge(graph, seen, condition_id, gap.id, "addresses",
                          rationale="该缺口源于未满足的条件")


def _verdict_edge(verdict: str) -> str:
    if verdict == "SUPPORT":
        return "supports"
    if verdict in ("REFUTE", "CONFLICT"):
        return "refutes"
    return "checks"


# --------------------------------------------------------------------------
# 边界说明
# --------------------------------------------------------------------------


def _collect_limitations(graph: EvidenceGraph, claims: Sequence[Node]) -> List[str]:
    notes: List[str] = []
    for check in graph.checks:
        if check.verdict == "MISSING_RULE":
            notes.append(check.detail)
        elif check.kind == "rule_applicability":
            notes.append(check.detail)
    for claim in claims:
        if claim.scope_limited:
            notes.append(f"{claim.id} 的结论范围受当前检索范围限制。")
    notes.append("本图仅覆盖单份监控日志可核查的范围；数据源的现实真实性、业务规则完备性不在验证范围内。")
    # 去重并保持顺序
    unique: List[str] = []
    for note in notes:
        if note and note not in unique:
            unique.append(note)
    return unique


# --------------------------------------------------------------------------
# G6：重算差异
# --------------------------------------------------------------------------


def diff_graphs(before: EvidenceGraph, after: EvidenceGraph) -> List[Dict[str, Any]]:
    """对比补证前后两张图，输出结论/缺口的变化记录。"""
    changes: List[Dict[str, Any]] = []

    before_status = {n.id: n.evidence_status for n in before.nodes_of("claim")}
    after_status = {n.id: n.evidence_status for n in after.nodes_of("claim")}
    for claim_id in sorted(after_status, key=_claim_sort_key):
        old = before_status.get(claim_id)
        new = after_status.get(claim_id)
        if old == new:
            continue
        content = next((n.content for n in after.nodes_of("claim") if n.id == claim_id), "")
        changes.append(
            {
                "kind": "claim_status",
                "claim": claim_id,
                "content": content,
                "before": old,
                "after": new,
                "reason": _change_reason(old, new),
            }
        )

    before_gaps = {g.id: g for g in before.gaps}
    after_gaps = {g.id: g for g in after.gaps}
    for gap_id in sorted(after_gaps):
        if gap_id not in before_gaps:
            changes.append(
                {
                    "kind": "gap_added",
                    "gap": gap_id,
                    "description": after_gaps[gap_id].description,
                    "before": None,
                    "after": "OPEN",
                }
            )
    for gap_id in sorted(before_gaps):
        if gap_id not in after_gaps:
            changes.append(
                {
                    "kind": "gap_resolved",
                    "gap": gap_id,
                    "description": before_gaps[gap_id].description,
                    "before": "OPEN",
                    "after": "RESOLVED",
                }
            )
    return changes


def _change_reason(old: Optional[str], new: Optional[str]) -> str:
    if old is None:
        return "补证后新增该结论的判定"
    order = {"SUPPORT": 4, "UNKNOWN": 3, "MISSING_RULE": 2, "CONFLICT": 1, "REFUTE": 0}
    if order.get(new, 3) > order.get(old, 3):
        return "补证后证据增强"
    return "补证后证据变化（可能是新证据揭示的新问题）"


def _claim_sort_key(claim_id: str) -> Tuple[int, str]:
    try:
        return (int(claim_id.split("-")[-1]), claim_id)
    except ValueError:
        return (10 ** 6, claim_id)
