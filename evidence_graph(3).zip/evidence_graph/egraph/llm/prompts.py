"""Prompt 文件加载与渲染。

Prompt 以独立 Markdown 文件保存在 ``prompts/`` 目录，便于版本管理与评审。
模板变量使用 ``{{var}}`` 占位，渲染时做严格校验：未提供的变量会直接报错，
避免把半成品 Prompt 发给模型。
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List

_VAR_PATTERN = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")


class PromptLibrary:
    """从目录加载 ``*.md`` Prompt。"""

    def __init__(self, prompts_dir: Path) -> None:
        self.prompts_dir = Path(prompts_dir)
        self._cache: Dict[str, str] = {}

    def names(self) -> List[str]:
        return sorted(p.stem for p in self.prompts_dir.glob("*.md"))

    def raw(self, name: str) -> str:
        if name not in self._cache:
            path = self.prompts_dir / f"{name}.md"
            if not path.exists():
                raise FileNotFoundError(f"Prompt 文件不存在：{path}")
            self._cache[name] = path.read_text(encoding="utf-8")
        return self._cache[name]

    def render(self, name: str, **variables: Any) -> str:
        template = self.raw(name)
        declared = set(_VAR_PATTERN.findall(template))
        missing = declared - set(variables)
        if missing:
            raise ValueError(f"Prompt {name} 缺少变量：{sorted(missing)}")

        def _replace(match: re.Match) -> str:
            value = variables[match.group(1)]
            return value if isinstance(value, str) else str(value)

        return _VAR_PATTERN.sub(_replace, template)

    def system_prompt(self) -> str:
        return self.raw("system")
