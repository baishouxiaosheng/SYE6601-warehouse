"""模型调用模块（LLM）。

* 基于标准库 ``urllib`` 实现 OpenAI 兼容的 ``/chat/completions`` 调用，
  不引入任何第三方 SDK，DeepSeek / 通义 / 智谱 / OpenAI 等端点均可复用。
* 未配置 Key 时返回 :class:`NullLLM`（``available=False``），上层抽取器自动
  退回纯规则实现，保证工程在无 Key 情况下依然可复现运行。
* 所有模型输出都会经过 ``validator``（结构化输出校验模块）后才被采纳，
  校验失败按 ``max_retries`` 重试，仍失败则降级为规则结果。
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from config.settings import LLMSettings


class LLMUnavailable(RuntimeError):
    """模型不可用（未配置或调用失败）。"""


@dataclass
class LLMResponse:
    text: str = ""
    parsed: Optional[Dict[str, Any]] = None
    usage: Dict[str, Any] = field(default_factory=dict)
    model: str = ""
    attempts: int = 1


class NullLLM:
    """空实现：未配置模型时使用，显式表明不可用。"""

    name = "null"
    available = False

    def __init__(self, reason: str = "未配置 API Key") -> None:
        self.reason = reason

    def chat(self, messages: List[Dict[str, str]], json_mode: Optional[bool] = None) -> LLMResponse:
        raise LLMUnavailable(self.reason)

    def extract_json(
        self,
        system: str,
        user: str,
        validator: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        raise LLMUnavailable(self.reason)

    def describe(self) -> Dict[str, Any]:
        return {"name": self.name, "available": False, "reason": self.reason}


class LLMClient:
    """OpenAI 兼容的 Chat Completions 客户端。"""

    name = "openai_compatible"

    def __init__(self, settings: LLMSettings) -> None:
        self.settings = settings
        self.available = settings.is_configured()
        self._endpoint = settings.base_url.rstrip("/") + "/chat/completions"
        self.last_error: Optional[str] = None

    # -- 底层 HTTP -----------------------------------------------------
    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self._endpoint,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.settings.api_key}",
            },
        )
        with urllib.request.urlopen(request, timeout=self.settings.timeout) as response:
            return json.loads(response.read().decode("utf-8"))

    def chat(
        self,
        messages: List[Dict[str, str]],
        json_mode: Optional[bool] = None,
    ) -> LLMResponse:
        """发送一次对话补全请求，带重试与指数退避。"""
        if not self.available:
            raise LLMUnavailable("未配置 API Key")

        use_json = self.settings.json_mode if json_mode is None else json_mode
        payload: Dict[str, Any] = {
            "model": self.settings.model,
            "messages": messages,
            "temperature": self.settings.temperature,
            "max_tokens": self.settings.max_tokens,
        }
        if use_json:
            payload["response_format"] = {"type": "json_object"}

        last_exc: Optional[Exception] = None
        for attempt in range(1, self.settings.max_retries + 1):
            try:
                data = self._post(payload)
                choice = (data.get("choices") or [{}])[0]
                text = (choice.get("message") or {}).get("content") or ""
                return LLMResponse(
                    text=text,
                    usage=data.get("usage") or {},
                    model=data.get("model", self.settings.model),
                    attempts=attempt,
                )
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError) as exc:
                last_exc = exc
                self.last_error = str(exc)
                if attempt < self.settings.max_retries:
                    time.sleep(min(2 ** attempt * 0.5, 4.0))
        raise LLMUnavailable(f"模型调用失败：{last_exc}")

    # -- 结构化输出 ----------------------------------------------------
    def extract_json(
        self,
        system: str,
        user: str,
        validator: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """请求 JSON 输出，并用 ``validator`` 校验；失败则重试。"""
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        last_exc: Optional[Exception] = None
        for attempt in range(1, self.settings.max_retries + 1):
            response = self.chat(messages, json_mode=True)
            try:
                parsed = _parse_json(response.text)
                if validator is not None:
                    validator(parsed)
                response.parsed = parsed
                return parsed
            except Exception as exc:  # 校验失败 → 追加纠正提示后重试
                last_exc = exc
                messages.append({"role": "assistant", "content": response.text[:2000]})
                messages.append(
                    {
                        "role": "user",
                        "content": f"上一次输出未通过结构校验：{exc}。"
                        "请仅返回符合约定字段的合法 JSON，不要输出解释文字。",
                    }
                )
        raise LLMUnavailable(f"结构化输出校验失败：{last_exc}")

    def describe(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "available": self.available,
            "endpoint": self._endpoint,
            "model": self.settings.model,
            "last_error": self.last_error,
        }


def _parse_json(text: str) -> Dict[str, Any]:
    """从模型回复中提取 JSON 对象，容忍 ```json 围栏与前后缀说明。"""
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.split("```")[1] if "```" in text[3:] else text[3:]
        if text.lstrip().lower().startswith("json"):
            text = text.lstrip()[4:]
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start : end + 1])
        raise


def build_llm(settings: LLMSettings) -> Any:
    """按配置构造模型客户端；未配置则返回 NullLLM。"""
    client = LLMClient(settings)
    if client.available:
        return client
    return NullLLM("未配置 EG_LLM_API_KEY，已降级为纯规则后端")
