"""工业智能体动态证据图工程（evidence graph）。

对外入口：

* :func:`egraph.pipeline.analyze_run`   单次运行分析
* :func:`egraph.pipeline.analyze_all`   批量分析
* :func:`egraph.pipeline.recompute_with_updates`  新证据重算（G6）
* :func:`egraph.pipeline.write_artifacts`  产出落盘
"""

from .loader import RunRecord, load_runs, select_runs
from .pipeline import (
    RunArtifacts,
    analyze_all,
    analyze_run,
    load_updates,
    recompute_with_updates,
    write_artifacts,
)

__version__ = "1.0.0"

__all__ = [
    "RunRecord",
    "load_runs",
    "select_runs",
    "RunArtifacts",
    "analyze_run",
    "analyze_all",
    "recompute_with_updates",
    "write_artifacts",
    "load_updates",
    "__version__",
]
