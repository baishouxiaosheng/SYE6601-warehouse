"""结构化输出校验模块。

承担三件事：

1. **JSON Schema 子集校验**：不依赖第三方库，支持 ``type`` / ``properties`` /
   ``required`` / ``items`` / ``enum`` / ``minimum`` / ``maximum`` / ``minItems`` /
   ``additionalProperties``，足够约束模型输出与本工程的产出结构。
2. **模型输出校验器**：``model_output_validator`` 生成可传给 ``LLMClient.extract_json``
   的校验回调，模型输出不合规会被拒绝并触发重试。
3. **产出物自检**：``validate_artifact`` 用于对证据图 / 补查计划 / 成绩单做交付前校验。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional


class SchemaError(ValueError):
    """结构校验失败。"""

    def __init__(self, message: str, path: str = "$") -> None:
        super().__init__(f"{path}: {message}")
        self.path = path


_TYPES = {
    "object": dict,
    "array": list,
    "string": str,
    "number": (int, float),
    "integer": int,
    "boolean": bool,
    "null": type(None),
}


def _type_ok(value: Any, expected: str) -> bool:
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    python_type = _TYPES.get(expected)
    return isinstance(value, python_type) if python_type else True


def validate_against(payload: Any, schema: Dict[str, Any], path: str = "$") -> None:
    """按 schema 校验 payload，失败抛 :class:`SchemaError`。"""
    if not isinstance(schema, dict):
        return

    expected = schema.get("type")
    if expected:
        allowed = expected if isinstance(expected, list) else [expected]
        if not any(_type_ok(payload, item) for item in allowed):
            raise SchemaError(f"期望类型 {expected}，实际 {type(payload).__name__}", path)

    if "enum" in schema and payload not in schema["enum"]:
        raise SchemaError(f"取值必须是 {schema['enum']} 之一，实际 {payload!r}", path)

    if isinstance(payload, (int, float)) and not isinstance(payload, bool):
        if "minimum" in schema and payload < schema["minimum"]:
            raise SchemaError(f"应 >= {schema['minimum']}，实际 {payload}", path)
        if "maximum" in schema and payload > schema["maximum"]:
            raise SchemaError(f"应 <= {schema['maximum']}，实际 {payload}", path)

    if isinstance(payload, str):
        if "minLength" in schema and len(payload) < schema["minLength"]:
            raise SchemaError(f"长度应 >= {schema['minLength']}", path)
        if schema.get("pattern"):
            import re

            if not re.search(schema["pattern"], payload):
                raise SchemaError(f"不匹配模式 {schema['pattern']}", path)

    if isinstance(payload, dict):
        for key in schema.get("required", []):
            if key not in payload:
                raise SchemaError(f"缺少必需字段 {key!r}", path)
        properties = schema.get("properties", {})
        for key, subschema in properties.items():
            if key in payload:
                validate_against(payload[key], subschema, f"{path}.{key}")
        if schema.get("additionalProperties") is False:
            extra = set(payload) - set(properties)
            if extra:
                raise SchemaError(f"存在未声明字段 {sorted(extra)}", path)

    if isinstance(payload, list):
        if "minItems" in schema and len(payload) < schema["minItems"]:
            raise SchemaError(f"元素个数应 >= {schema['minItems']}", path)
        item_schema = schema.get("items")
        if item_schema:
            for index, item in enumerate(payload):
                validate_against(item, item_schema, f"{path}[{index}]")


def load_schema(name: str, schemas_dir: Path) -> Dict[str, Any]:
    path = Path(schemas_dir) / (name if name.endswith(".json") else f"{name}.schema.json")
    if not path.exists():
        raise FileNotFoundError(f"Schema 文件不存在：{path}")
    return json.loads(path.read_text(encoding="utf-8"))


def model_output_validator(schema: Dict[str, Any], required_keys: Optional[List[str]] = None):
    """构造传给 ``LLMClient.extract_json`` 的校验回调。"""

    def _validator(payload: Dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            raise SchemaError("模型输出必须是 JSON 对象")
        for key in required_keys or []:
            if key not in payload:
                raise SchemaError(f"缺少必需字段 {key!r}")
        validate_against(payload, schema)

    return _validator


def artifact_schemas(schemas_dir: Path) -> Dict[str, Dict[str, Any]]:
    """加载三份产出物 Schema。"""
    return {
        "graph": load_schema("graph", schemas_dir),
        "plan": load_schema("plan", schemas_dir),
        "scorecard": load_schema("scorecard", schemas_dir),
    }
