"""自动补证计划（对应需求第 4 节 B1–B3）。

职责：

* **B1 反推动作与选路**：由证据图里的缺口（``Gap``）反推应该执行什么动作、
  走哪条来源。来源选择优先复用本次运行已经用过的同类工具，避免臆造接口。
* **B2 可执行性判定**：给每个动作标注 ``executable`` / ``needs_confirmation`` /
  ``manual``，并区分「已知参数」与「待补参数」，让补查可落地、可公示。
* **B3 执行登记**：动作为执行结果预留 ``executed_at`` / ``evidence_time`` /
  ``acquired_at`` 三个时间位（业务时点与取证时间不同），并提供
  :func:`register_execution` 回填。

本模块完全使用确定性规则：同一张图必得同一份计划，保证补证链路可复现。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

from .extract.evidence import EvidenceBundle
from .loader import RunRecord
from .models import (
    EvidenceGraph,
    Gap,
    IdFactory,
    PlanAction,
    SupplementaryPlan,
)

#: 计划版本后缀
PLAN_VERSION_SUFFIX = "supplementary-plan-v1"

#: 缺口类型 → 默认动作类型
GAP_ACTION_MAP: Dict[str, str] = {
    "INCOMPLETE_RESULT": "refetch_page",
    "MISSING_RULE": "rule_lookup",
    "MISSING_DEPENDENCY": "rule_lookup",
    "CONFLICT": "recompute",
    "LIMITED_SCOPE": "requery",
    "MISSING_EVIDENCE": "requery",
}

#: 出现这些词说明只能现场/人工确认，无法靠再次查询解决
MANUAL_HINTS = (
    "现场", "人工", "检查记录", "检测记录", "校准", "维护", "审批", "授权",
    "签字", "确认", "铭牌", "实物",
)

#: 文档/知识库类工具名特征
DOCTOOL_HINTS = ("knowledge", "doc", "manual", "标准", "手册", "wiki")

#: 缺口严重度 → 动作优先级（数字越小越优先）
CRITICALITY_PRIORITY = {"HIGH": 1, "MEDIUM": 2, "LOW": 3}

#: 需要人工走进现场/审批流程的动作
MANUAL_ACTIONS = ("manual_confirm",)


# --------------------------------------------------------------------------
# 主入口
# --------------------------------------------------------------------------


def build_plan(
    *,
    run: RunRecord,
    ids: IdFactory,
    graph: EvidenceGraph,
    bundle: EvidenceBundle,
    settings: Any = None,
) -> SupplementaryPlan:
    """由证据图反推补查计划。"""
    plan = SupplementaryPlan(
        plan_version=f"{run.case_id}-{PLAN_VERSION_SUFFIX}",
        run_id=run.run_id,
        case_id=run.case_id,
    )

    device_models = _device_models(bundle)
    merged: Dict[Tuple[str, str], Dict[str, Any]] = {}

    for gap in graph.gaps:
        action_type = _action_type(gap)
        resolved = _resolve(
            gap=gap,
            action_type=action_type,
            graph=graph,
            bundle=bundle,
            device_models=device_models,
        )
        key = (action_type, resolved["tool"] or "")
        if key in merged:
            _merge(merged[key], gap=gap, resolved=resolved)
        else:
            merged[key] = _new_action(gap=gap, action_type=action_type, resolved=resolved)

    ordered = sorted(
        merged.values(),
        key=lambda item: (item["priority"], item["action_type"], item["tool"] or "", item["gap_ids"]),
    )
    for item in ordered:
        plan.actions.append(
            PlanAction(
                id=ids.next("ACT"),
                action_type=item["action_type"],
                gap_ids=sorted(item["gap_ids"]),
                target_claims=sorted(item["target_claims"]),
                tool=item["tool"],
                known_arguments=item["known_arguments"],
                pending_arguments=item["pending_arguments"],
                expected_outcome=item["expected_outcome"],
                success_criterion=item["success_criterion"],
                rationale=item["rationale"],
                executability=item["executability"],
                priority=item["priority"],
            )
        )

    if not plan.actions:
        plan.notes.append("本次运行未发现需要补证的缺口，无需额外动作。")
    plan.notes.extend(
        [
            "动作按「同一来源 + 同一动作类型」合并，避免对同一接口重复往返。",
            "executable 表示参数齐备可直接执行；needs_confirmation 表示需先确认参数或适用范围；"
            "manual 表示必须现场或走审批流程。",
            "执行后用 register_execution() 回填 executed_at（发起时间）、"
            "evidence_time（业务时点）、acquired_at（取证时间），三者不可互相代替。",
        ]
    )
    return plan


# --------------------------------------------------------------------------
# B1：动作类型与选路
# --------------------------------------------------------------------------


def _action_type(gap: Gap) -> str:
    if gap.type == "MISSING_EVIDENCE" and _needs_manual(gap):
        return "manual_confirm"
    return GAP_ACTION_MAP.get(gap.type, "manual_confirm")


def _needs_manual(gap: Gap) -> bool:
    text = f"{gap.description} {gap.target_source}"
    return any(hint in text for hint in MANUAL_HINTS)


def _device_models(bundle: EvidenceBundle) -> List[str]:
    models: List[str] = []
    for signal in bundle.signals:
        if signal.kind == "id" and isinstance(signal.value, str) and str(signal.key).lower().endswith("model"):
            if signal.value not in models:
                models.append(signal.value)
    return models


def _tools_for_claims(graph: EvidenceGraph, claim_ids: Sequence[str]) -> List[str]:
    """结论当前已经用到的工具（按边关系回溯），作为补查的候选来源。"""
    wanted = set(claim_ids)
    tools: List[str] = []
    for edge in graph.edges:
        if edge.target in wanted and edge.type in ("supports", "refutes", "checks", "uses"):
            node = graph.node(edge.source)
            if node is not None and node.type == "evidence" and node.tool:
                if node.tool not in tools:
                    tools.append(node.tool)
    return tools


def _doc_tool(graph: EvidenceGraph, bundle: EvidenceBundle) -> Optional[str]:
    for tool in _all_tools(graph, bundle):
        lowered = tool.lower()
        if any(hint in lowered for hint in DOCTOOL_HINTS):
            return tool
    return None


def _all_tools(graph: EvidenceGraph, bundle: EvidenceBundle) -> List[str]:
    tools: List[str] = []
    for node in graph.nodes:
        if node.type == "evidence" and node.tool and node.tool not in tools:
            tools.append(node.tool)
    if not tools:
        for info in bundle.paginations:
            if info.tool and info.tool not in tools:
                tools.append(info.tool)
    return tools


def _node_by_record(graph: EvidenceGraph, record_id: str):
    for node in graph.nodes:
        if node.type == "evidence" and node.record_id == record_id:
            return node
    return None


def _clean_arguments(arguments: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not arguments:
        return {}
    return {key: value for key, value in arguments.items() if value not in (None, "", [], {})}


def _resolve(
    *,
    gap: Gap,
    action_type: str,
    graph: EvidenceGraph,
    bundle: EvidenceBundle,
    device_models: Sequence[str],
) -> Dict[str, Any]:
    """为一类动作算出工具、参数、可执行性与成功判据。"""
    claims = gap.affected_claims or []

    if action_type == "refetch_page":
        info = next((p for p in bundle.paginations if (p.total_pages or 1) > (p.page or 1)), None) or (
            bundle.paginations[0] if bundle.paginations else None
        )
        tool = info.tool if info else None
        known: Dict[str, Any] = {}
        if info is not None:
            node = _node_by_record(graph, info.record_id)
            known.update(_clean_arguments(node.arguments if node else None))
            known.setdefault("page", (info.page or 1) + 1)
            if info.page_size:
                known["page_size"] = info.page_size
        return {
            "tool": tool,
            "known_arguments": known,
            "pending_arguments": {},
            "executability": "executable" if tool else "needs_confirmation",
            "expected_outcome": (
                f"翻取剩余分页（当前第 {getattr(info, 'page', '?')}/{getattr(info, 'total_pages', '?')} 页），"
                "使“全库检索”结论覆盖完整结果集"
            ),
            "success_criterion": (
                "工具返回的 page 递增至 total_pages，或 total_matches 全部返回，"
                "且每页结果均可定位到 trace[<事件ID>].result"
            ),
            "rationale": gap.description,
            "priority": CRITICALITY_PRIORITY.get(gap.criticality, 2),
        }

    if action_type == "rule_lookup":
        tool = _doc_tool(graph, bundle)
        query_terms = _query_terms(gap)
        known = {"query": query_terms}
        pending: Dict[str, Any] = {}
        if device_models:
            pending["applicable_to"] = "、".join(device_models)
        return {
            "tool": tool or "knowledge_base.search",
            "known_arguments": known,
            "pending_arguments": pending,
            "executability": "executable" if tool else "needs_confirmation",
            "expected_outcome": (
                f"取得可引用依据：{gap.target_source or '权威技术文件/审批授权'}"
            ),
            "success_criterion": (
                "检索到 excerpt 可逐字引用、且 applicable_to 覆盖当前设备型号的条款；"
                "若仅有通用条款则视为未满足"
            ),
            "rationale": gap.description,
            "priority": CRITICALITY_PRIORITY.get(gap.criticality, 2),
        }

    if action_type == "recompute":
        rule_id = gap.missing_condition or ""
        return {
            "tool": None,
            "known_arguments": {"rule_id": rule_id} if rule_id else {},
            "pending_arguments": {},
            "executability": "executable",
            "expected_outcome": "按日志给出的限制/规则对已有字段重新核算，得到与限值一致的结论",
            "success_criterion": (
                f"按规则 {rule_id or '（日志给出的限值）'} 复算后的数值满足限制，"
                "或明确给出超出量并触发降级/放行流程"
            ),
            "rationale": gap.description,
            "priority": CRITICALITY_PRIORITY.get(gap.criticality, 2),
        }

    if action_type == "manual_confirm":
        return {
            "tool": None,
            "known_arguments": {},
            "pending_arguments": {"确认事项": gap.description},
            "executability": "manual",
            "expected_outcome": f"取得现场/人工记录：{gap.target_source or '现场检查或审批记录'}",
            "success_criterion": (
                "获得书面或系统登记结果（含执行人、时间、结论），"
                "并能定位到对应记录编号"
            ),
            "rationale": gap.description,
            "priority": CRITICALITY_PRIORITY.get(gap.criticality, 2),
        }

    # 默认：requery（改参数重查）
    tools = _tools_for_claims(graph, claims)
    tool = tools[0] if tools else None
    known = {}
    if tool is not None:
        node = next(
            (n for n in graph.nodes if n.type == "evidence" and n.tool == tool),
            None,
        )
        known = _clean_arguments(node.arguments if node else None)
    pending: Dict[str, Any] = {}
    if not known:
        pending["查询条件"] = gap.description
    return {
        "tool": tool,
        "known_arguments": known,
        "pending_arguments": pending,
        "executability": "executable" if (tool and known) else "needs_confirmation",
        "expected_outcome": f"补齐缺失范围的数据：{gap.description}",
        "success_criterion": (
            "新返回字段能覆盖缺口所涉的对象/时段，且可定位到具体字段路径后复算出结论"
        ),
        "rationale": gap.description,
        "priority": CRITICALITY_PRIORITY.get(gap.criticality, 2),
    }


def _query_terms(gap: Gap) -> str:
    base = f"{gap.description} {gap.target_source}".strip()
    return base[:120]


# --------------------------------------------------------------------------
# 合并
# --------------------------------------------------------------------------


def _new_action(*, gap: Gap, action_type: str, resolved: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "action_type": action_type,
        "tool": resolved["tool"],
        "known_arguments": dict(resolved["known_arguments"]),
        "pending_arguments": dict(resolved["pending_arguments"]),
        "expected_outcome": resolved["expected_outcome"],
        "success_criterion": resolved["success_criterion"],
        "rationale": resolved["rationale"],
        "executability": resolved["executability"],
        "priority": resolved["priority"],
        "gap_ids": {gap.id},
        "target_claims": set(gap.affected_claims or []),
    }


def _merge(item: Dict[str, Any], *, gap: Gap, resolved: Dict[str, Any]) -> None:
    item["gap_ids"].add(gap.id)
    item["target_claims"].update(gap.affected_claims or [])
    item["known_arguments"].update(resolved["known_arguments"])
    item["pending_arguments"].update(resolved["pending_arguments"])
    item["priority"] = min(item["priority"], resolved["priority"])
    # 合并后取更保守的可执行性（manual > needs_confirmation > executable）
    item["executability"] = _more_conservative(item["executability"], resolved["executability"])
    if resolved["rationale"] not in item["rationale"]:
        item["rationale"] = f"{item['rationale']}；{resolved['rationale']}"


_ORDER = ("executable", "needs_confirmation", "manual")


def _more_conservative(left: str, right: str) -> str:
    return left if _ORDER.index(left) >= _ORDER.index(right) else right


# --------------------------------------------------------------------------
# B3：执行登记
# --------------------------------------------------------------------------


def register_execution(
    action: PlanAction,
    *,
    executed_at: Optional[str] = None,
    evidence_time: Optional[str] = None,
    acquired_at: Optional[str] = None,
) -> PlanAction:
    """登记动作执行情况（B3）。

    三者含义不同，不可互相代替：

    * ``executed_at``：动作发起时间；
    * ``evidence_time``：证据所描述的业务时点（例如统计到哪一天 22:00）；
    * ``acquired_at``：真正取得数据/记录的取证时间。
    """
    if executed_at:
        action.executed_at = executed_at
    if evidence_time:
        action.evidence_time = evidence_time
    if acquired_at:
        action.acquired_at = acquired_at
    return action
