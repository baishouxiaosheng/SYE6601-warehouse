"""证据抽取：把工具轨迹转成可定位的证据节点与结构化信号。

对应 G2：保留工具调用、输入参数、返回字段、证据条件之间的有向关系，
每个已引用的证据都能定位到 ``run_id``、事件 ID（``c1``）和原始 JSON 字段路径。

关键约定：
* 只有 ``event == "tool_call"`` 的轨迹才产生证据；``assistant_progress_note``
  只产生 ``note`` 节点，用于定位过程，**不作为证据**。
* 字段路径统一写成 ``trace[<事件ID>].result.<叶子键>``，可直接在原始 JSON 中定位。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ..loader import RunRecord
from ..models import IdFactory, Node
from ..verify import units

# ---------------------------------------------------------------- 分类关键字

RANGE_KEY_PREFIXES = ("normal_range", "normal_", "spec_range", "range", "allowable")
PAGINATION_KEYS = {"page", "total_pages", "page_size", "total_matches", "total", "total_count"}
TIME_HINTS = ("time", "date", "_at", "as_of", "timestamp", "valid_until", "expire")
ID_HINTS = ("_id", "id", "code", "keyword", "doc", "no", "certificate", "batch", "asset",
            "model", "controller", "technician", "operator", "inspector", "contact",
            "material", "collection", "site", "workshop", "fuel")
STATUS_KEYS = {
    "status", "result", "state", "inspection_result", "permit_status", "trend_2h", "trend",
    "data_quality", "power_state", "lockout_tagout", "ready_to_start", "interpretation",
    "restriction", "restriction_reason", "recommended_replacement", "severity", "conclusion",
    "defect_type", "note", "attribution_rule", "query_filter", "access_level",
}
DOC_TOOL_HINTS = ("knowledge_base", "document", "manual", "manual_search")
DOC_TEXT_KEYS = ("excerpt", "content", "description", "solution", "cause", "text", "snippet")


@dataclass
class Signal:
    """工具返回中的一条结构化信号（叶子值 + 定位路径）。"""

    node_id: str
    tool: str
    record_id: str
    path: str
    key: str
    kind: str
    value: Any = None
    unit: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "tool": self.tool,
            "record_id": self.record_id,
            "path": self.path,
            "key": self.key,
            "kind": self.kind,
            "value": self.value,
            "unit": self.unit,
        }


@dataclass
class Measurement:
    """带正常区间的读数（number + range 配对结果）。"""

    node_id: str
    tool: str
    record_id: str
    key: str
    value: float
    unit: Optional[str]
    low: Optional[float] = None
    high: Optional[float] = None
    value_path: str = ""
    range_path: str = ""
    range_unit: Optional[str] = None


@dataclass
class PaginationInfo:
    node_id: str
    tool: str
    record_id: str
    page: Optional[int] = None
    total_pages: Optional[int] = None
    page_size: Optional[int] = None
    total_matches: Optional[int] = None
    returned: Optional[int] = None
    note: str = ""


@dataclass
class DocEvidence:
    """来自知识库/文档检索的可引用段落。"""

    node_id: str
    tool: str
    record_id: str
    locator: str
    text: str
    title: str = ""
    doc_id: str = ""
    applicable_to: str = ""
    meta: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EvidenceBundle:
    nodes: List[Node] = field(default_factory=list)
    signals: List[Signal] = field(default_factory=list)
    measurements: List[Measurement] = field(default_factory=list)
    paginations: List[PaginationInfo] = field(default_factory=list)
    docs: List[DocEvidence] = field(default_factory=list)

    def signals_of(self, kind: str, node_id: Optional[str] = None) -> List[Signal]:
        return [s for s in self.signals if s.kind == kind and (node_id is None or s.node_id == node_id)]


# ---------------------------------------------------------------- 内部工具


def _is_range_pair(key: Any, value: Any) -> bool:
    """``[low, high]`` 形式的正常区间（键名以 range 类前缀开头）。"""
    return (
        isinstance(value, list)
        and len(value) == 2
        and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in value)
        and str(key).lower().startswith(RANGE_KEY_PREFIXES)
    )


def _walk(obj: Any, path: str):
    """递归遍历 JSON，产出 ``(字段路径, 叶子值)``。

    正常区间 ``normal_range_c: [140, 190]`` 整体作为一个 ``range`` 叶子产出，
    **不**拆成两个独立数字，否则无法与读数配对做区间复算。
    """
    if isinstance(obj, dict):
        for key, value in obj.items():
            child = f"{path}.{key}"
            if _is_range_pair(key, value):
                yield child, value
            else:
                yield from _walk(value, child)
    elif isinstance(obj, list):
        for index, item in enumerate(obj):
            yield from _walk(item, f"{path}[{index}]")
    else:
        yield path, obj


def _classify(key: str, value: Any) -> Tuple[str, Optional[str]]:
    lower = key.lower()
    if isinstance(value, list) and len(value) == 2 and all(
        isinstance(v, (int, float)) and not isinstance(v, bool) for v in value
    ) and lower.startswith(RANGE_KEY_PREFIXES):
        return "range", units.unit_from_key(key)
    if lower in PAGINATION_KEYS:
        return "pagination", None
    if isinstance(value, bool):
        return "status", None
    if isinstance(value, (int, float)):
        return "number", units.unit_from_key(key)
    if isinstance(value, str):
        if any(hint in lower for hint in TIME_HINTS):
            return "time", None
        if lower in STATUS_KEYS:
            return "status", None
        if any(lower.endswith(hint) or hint in lower for hint in ID_HINTS):
            return "id", None
        return "text", None
    return "other", None


def _is_doc_tool(tool: str) -> bool:
    lowered = tool.lower()
    return any(hint in lowered for hint in DOC_TOOL_HINTS)


# ---------------------------------------------------------------- 主流程


def extract_evidence(run: RunRecord, ids: IdFactory) -> EvidenceBundle:
    """构建证据节点、结构化信号、读数配对、分页信息与文档段落。"""
    bundle = EvidenceBundle()

    # 1) 阶段性说明：仅作为过程定位节点
    for index, item in enumerate(run.progress_notes()):
        bundle.nodes.append(
            Node(
                id=f"NOTE-{index + 1:03d}",
                type="note",
                content=str(item.get("text", "")),
                created_by="rule",
                record_id=str(item.get("id", f"s{index + 1}")),
                meta={"event": item.get("event", "note")},
            )
        )

    # 2) 工具调用：每个调用一个证据节点
    for call in run.tool_calls():
        record_id = str(call.get("id"))
        tool = str(call.get("tool", ""))
        node = Node(
            id=ids.next("MAT"),
            type="evidence",
            content=f"{tool} 返回结果",
            created_by="rule",
            source_id=tool.split(".")[0] if "." in tool else tool,
            record_id=record_id,
            locator=f"trace[{record_id}].result",
            tool=tool,
            arguments=dict(call.get("arguments") or {}),
            meta={"call_type": call.get("type", "")},
        )
        bundle.nodes.append(node)

        result = call.get("result")
        if result is None and call.get("error"):
            node.meta["error"] = call["error"]
            node.content = f"{tool} 调用失败：{call['error']}"
            continue

        signals: List[Signal] = []
        for leaf_path, value in _walk(result, f"trace[{record_id}].result"):
            key = leaf_path.rsplit(".", 1)[-1].split("[")[0]
            if key.isdigit():
                key = leaf_path.split("[")[-2].split(".")[-1] if "[" in leaf_path else key
            kind, unit = _classify(key, value)
            signals.append(
                Signal(
                    node_id=node.id,
                    tool=tool,
                    record_id=record_id,
                    path=leaf_path,
                    key=key,
                    kind=kind,
                    value=value,
                    unit=unit,
                )
            )
        bundle.signals.extend(signals)
        node.meta["signal_count"] = len(signals)

        # 分页信息
        page_info = _build_pagination(node, signals)
        if page_info:
            bundle.paginations.append(page_info)

        # 文档段落
        if _is_doc_tool(tool):
            bundle.docs.extend(_extract_docs(node, result, signals))

    bundle.measurements = _pair_ranges(bundle.signals)
    return bundle


def _build_pagination(node: Node, signals: List[Signal]) -> Optional[PaginationInfo]:
    values = {s.key: s.value for s in signals if s.kind == "pagination"}
    if not values:
        return None
    note = ""
    for signal in signals:
        if signal.kind in {"text", "status"} and isinstance(signal.value, str):
            if any(word in signal.value for word in ("页", "翻页", "未生效", "截断", "仅返回")):
                note = signal.value
    returned = len({s.path.split("[")[1].split("]")[0] for s in signals if "[0]" in s.path and ".results[" in s.path})
    return PaginationInfo(
        node_id=node.id,
        tool=node.tool or "",
        record_id=node.record_id or "",
        page=_as_int(values.get("page")),
        total_pages=_as_int(values.get("total_pages")),
        page_size=_as_int(values.get("page_size")),
        total_matches=_as_int(values.get("total_matches") or values.get("total") or values.get("total_count")),
        returned=returned or None,
        note=note,
    )


def _as_int(value: Any) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _extract_docs(node: Node, result: Any, signals: List[Signal]) -> List[DocEvidence]:
    """抽取知识库/文档返回中的可引用段落。"""
    docs: List[DocEvidence] = []
    container = result
    if isinstance(result, dict):
        for key in ("results", "documents", "items", "matches"):
            if isinstance(result.get(key), list):
                container = result[key]
                break
    entries = container if isinstance(container, list) else [container]
    for order, entry in enumerate(entries):
        if not isinstance(entry, dict):
            continue
        text = ""
        text_key = ""
        for key in DOC_TEXT_KEYS:
            if isinstance(entry.get(key), str) and entry[key].strip():
                text = entry[key]
                text_key = key
                break
        if not text:
            continue
        meta = {
            "doc_id": entry.get("doc_id") or entry.get("document_id") or entry.get("id") or "",
            "title": entry.get("title") or entry.get("section") or "",
            "applicable_models": entry.get("applicable_models") or entry.get("model") or "",
            "version": entry.get("version") or entry.get("revision") or "",
            "section": entry.get("section") or "",
        }
        docs.append(
            DocEvidence(
                node_id=node.id,
                tool=node.tool or "",
                record_id=node.record_id or "",
                locator=f"trace[{node.record_id}].result.{text_key}"
                if not isinstance(container, list)
                else f"trace[{node.record_id}].result.results[{order}].{text_key}",
                text=text.strip(),
                title=str(meta["title"]),
                doc_id=str(meta["doc_id"]),
                applicable_to=str(meta["applicable_models"]),
                meta=meta,
            )
        )
    return docs


def _pair_ranges(signals: List[Signal]) -> List[Measurement]:
    """把读数与同节点的正常区间配对（同量纲就近匹配）。"""
    by_node: Dict[str, List[Signal]] = {}
    for signal in signals:
        by_node.setdefault(signal.node_id, []).append(signal)

    measurements: List[Measurement] = []
    for node_id, items in by_node.items():
        ranges = [s for s in items if s.kind == "range"]
        numbers = [s for s in items if s.kind == "number"]
        for number in numbers:
            if not isinstance(number.value, (int, float)):
                continue
            for rng in ranges:
                if units.resolve(rng.unit) and units.resolve(number.unit):
                    if units.resolve(rng.unit).dimension != units.resolve(number.unit).dimension:
                        continue
                low, high = rng.value[0], rng.value[1]
                if units.same_dimension(rng.unit, number.unit):
                    low = units.convert(low, rng.unit, number.unit) or low
                    high = units.convert(high, rng.unit, number.unit) or high
                measurements.append(
                    Measurement(
                        node_id=node_id,
                        tool=number.tool,
                        record_id=number.record_id,
                        key=number.key,
                        value=float(number.value),
                        unit=number.unit,
                        low=float(low),
                        high=float(high),
                        value_path=number.path,
                        range_path=rng.path,
                        range_unit=rng.unit,
                    )
                )
                break
    return measurements
