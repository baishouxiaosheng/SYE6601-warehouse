"""规则抽取（G2/G5）：只采信日志中存在可引用依据的规则。

规则来源两类：

* **文档依据**：知识库/手册返回的段落，逐字保存 ``excerpt`` 与定位 ``locator``，
  并记录适用对象（``applicable_models``）与版本（如日志给出）。
* **字段依据**：工具返回中显式给出的状态、阈值与前置条件，
  例如 ``restriction="起重量不超过15吨"``、``permit_required=true``。

日志没有提供的适用对象或基准一律留空，**不做推断**。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..models import IdFactory, Node
from .evidence import DocEvidence, EvidenceBundle
from .text import to_number

_UNIT_ALT = r"kWh|kW|kPa|MPa|Pa|ppm|℃|°C|kg|km|cm|mm|m3|Hz|bar|%|t|g|m|L|件|吨|个|小时|分钟|倍"
THRESHOLD_RE = re.compile(
    rf"(?P<rel>不得超过|不超过|不低于|超过|高于|大于|低于|小于|上限为|上限|下限为)\s*"
    rf"(?P<val>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>{_UNIT_ALT})"
)

#: 关系词 → 比较运算符
_RELATION_OPS = {
    "超过": ">", "高于": ">", "大于": ">",
    "不低于": ">=",
    "不超过": "<=", "不得超过": "<=", "低于": "<", "小于": "<",
    "上限为": "<=", "上限": "<=", "下限为": ">=",
}

#: 作为「限值/上限」使用的运算符：数值必须满足该约束才合规。
_LIMIT_OPS = {"<=", "<", ">="}
#: 作为「触发条件」使用的运算符：数值达到该条件即进入某种情形（如“超过190℃即异常”），
#: 不能当作限值去做“越限”判定。
_TRIGGER_OPS = {">"}

AUTHORIZATION_HINTS = ("审批", "许可", "放行", "授权", "批准", "验收", "签字")
PROCEDURE_HINTS = ("建议", "检查", "排查", "应当", "需要先")


@dataclass
class Threshold:
    op: str
    value: float
    unit: str

    def describe(self) -> str:
        return f"{self.op} {self.value} {self.unit}"


def parse_threshold(text: str) -> Optional[Threshold]:
    """从文本中解析阈值，如「不超过15吨」→ ``<= 15 t``。"""
    match = THRESHOLD_RE.search(text or "")
    if not match:
        return None
    value = to_number(match.group("val"))
    if value is None:
        return None
    return Threshold(op=_RELATION_OPS.get(match.group("rel"), "?"), value=value, unit=match.group("unit"))


def _threshold_role(op: str) -> str:
    """区分阈值用途：限值（必须满足）还是触发条件（达到即进入某情形）。"""
    if op in _LIMIT_OPS:
        return "limit"
    if op in _TRIGGER_OPS:
        return "trigger"
    return "unknown"


def _classify_doc_rule(text: str, threshold: Optional[Threshold]) -> str:
    if any(hint in text for hint in AUTHORIZATION_HINTS):
        return "authorization_rule"
    if threshold is not None:
        return "threshold_rule"
    if any(hint in text for hint in PROCEDURE_HINTS):
        return "procedure_rule"
    return "procedure_rule"


def extract_rules(bundle: EvidenceBundle, ids: IdFactory) -> List[Node]:
    """返回规则节点列表。"""
    rules: List[Node] = []

    # 1) 文档依据
    for doc in bundle.docs:
        threshold = parse_threshold(doc.text)
        kind = _classify_doc_rule(doc.text, threshold)
        rules.append(
            Node(
                id=ids.next("RULE"),
                type="rule",
                content=doc.text,
                created_by="rule",
                review_status="verified",
                source_id=doc.node_id,
                record_id=doc.record_id,
                locator=doc.locator,
                excerpt=doc.text,
                doc_version=doc.meta.get("version") or None,
                meta={
                    "kind": kind,
                    "doc_id": doc.doc_id,
                    "title": doc.title,
                    "applicable_to": doc.applicable_to or None,
                    "threshold": (
                        {
                            "op": threshold.op,
                            "value": threshold.value,
                            "unit": threshold.unit,
                            "role": _threshold_role(threshold.op),
                        }
                        if threshold
                        else None
                    ),
                    "expression": (
                        f"value {threshold.op} {threshold.value} {threshold.unit}" if threshold else None
                    ),
                },
            )
        )

    # 2) 字段依据：显式阈值 / 限制 / 前置条件
    for signal in bundle.signals:
        key = signal.key.lower()
        if key == "restriction" and isinstance(signal.value, str):
            threshold = parse_threshold(signal.value)
            rules.append(
                Node(
                    id=ids.next("RULE"),
                    type="rule",
                    content=signal.value,
                    created_by="rule",
                    review_status="verified",
                    source_id=signal.node_id,
                    record_id=signal.record_id,
                    locator=signal.path,
                    excerpt=signal.value,
                    meta={
                        "kind": "limit_rule",
                        "applicable_to": None,
                        "threshold": (
                            {
                                "op": threshold.op,
                                "value": threshold.value,
                                "unit": threshold.unit,
                                "role": _threshold_role(threshold.op),
                            }
                            if threshold
                            else None
                        ),
                        "expression": (
                            f"value {threshold.op} {threshold.value} {threshold.unit}"
                            if threshold
                            else None
                        ),
                    },
                )
            )
        elif key == "permit_required" and signal.value is True:
            rules.append(
                Node(
                    id=ids.next("RULE"),
                    type="rule",
                    content="该项作业需要许可审批（日志显式给出）",
                    created_by="rule",
                    review_status="verified",
                    source_id=signal.node_id,
                    record_id=signal.record_id,
                    locator=signal.path,
                    excerpt=str(signal.value),
                    meta={"kind": "authorization_rule", "applicable_to": None, "threshold": None},
                )
            )
        elif key == "attribution_rule" and isinstance(signal.value, str):
            rules.append(
                Node(
                    id=ids.next("RULE"),
                    type="rule",
                    content=signal.value,
                    created_by="rule",
                    review_status="verified",
                    source_id=signal.node_id,
                    record_id=signal.record_id,
                    locator=signal.path,
                    excerpt=signal.value,
                    meta={"kind": "attribution_rule", "applicable_to": None, "threshold": None},
                )
            )
    return rules
