"""原子结论抽取（G1）与断言强度判定。

对应需求：分别提取最终回答中的原子结论，保留对象、时间范围、断言强度和原文；
读数、推测、审批状态和操作建议可以分别评价。
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from ..loader import RunRecord
from ..models import Goal, IdFactory, Node
from ..validate.schema import load_schema, model_output_validator
from .text import (
    INFERENCE_MARKERS,
    NEGATIVE_MARKERS,
    RECOMMENDATION_MARKERS,
    RELEASE_MARKERS,
    Numeral,
    extract_numerals,
    has_any,
    keyword_overlap,
    split_clauses,
    split_sentences,
)

#: 实体编码正则：设备/工单/批次/证书编号等
ENTITY_PATTERN = re.compile(r"\b(?:Line-[A-Z]|[A-Z]{2,}[A-Za-z0-9]*(?:-[A-Za-z0-9]+)+|[A-Z]{2,}\d{2,})\b")

MIN_CLAIM_LEN = 4
#: 纯连接/过渡片段，不构成结论
NOISE_PATTERNS = ("如需", "请告知", "可以协助", "谢谢", "以上")


def classify_strength(text: str) -> str:
    """判定断言强度。"""
    if has_any(text, RELEASE_MARKERS):
        return "approval"
    if has_any(text, RECOMMENDATION_MARKERS):
        return "recommendation"
    if has_any(text, NEGATIVE_MARKERS):
        return "negative_finding"
    if has_any(text, INFERENCE_MARKERS):
        return "inference"
    if extract_numerals(text):
        return "reading"
    return "assertion"


def _extract_entities(text: str, known: Set[str]) -> List[str]:
    found = {m.group(0) for m in ENTITY_PATTERN.finditer(text)}
    for entity in known:
        if entity and entity in text:
            found.add(entity)
    return sorted(found)


def _split_answer(answer: str) -> List[str]:
    """先按句切，再按逗号切，保证「一句话多个结论」被拆开。"""
    pieces: List[str] = []
    for sentence in split_sentences(answer):
        for clause in split_clauses(sentence):
            pieces.append(clause)
    return [p for p in pieces if p]


def extract_claims_rule(
    run: RunRecord,
    goals: List[Goal],
    known_entities: Optional[Set[str]] = None,
) -> List[Dict[str, Any]]:
    known_entities = known_entities or set()
    results: List[Dict[str, Any]] = []
    for index, piece in enumerate(_split_answer(run.ai_answer or "")):
        text = piece.strip()
        if len(text) < MIN_CLAIM_LEN or has_any(text, NOISE_PATTERNS):
            continue
        numerals = extract_numerals(text)
        covers = [
            position
            for position, goal in enumerate(goals)
            if keyword_overlap(text, goal.text) >= 0.25 or (goal.subject and goal.subject in text)
        ]
        results.append(
            {
                "text": text,
                "assertion_strength": classify_strength(text),
                "numerals": [
                    {"value": n.value, "unit": n.unit, "raw": n.raw, "upper": n.upper} for n in numerals
                ],
                "entities": _extract_entities(text, known_entities),
                "covers_goals": covers,
                "source_span": text,
                "created_by": "rule",
                "order": index,
            }
        )
    return results


def extract_claims(
    run: RunRecord,
    goals: List[Goal],
    ids: IdFactory,
    known_entities: Optional[Set[str]] = None,
    llm: Any = None,
    prompts: Any = None,
    schemas_dir: Optional[Path] = None,
) -> List[Node]:
    """返回 claim 节点列表。"""
    raw: List[Dict[str, Any]] = []
    if llm is not None and getattr(llm, "available", False) and prompts is not None and schemas_dir:
        try:
            schema = load_schema("llm_claims", schemas_dir)
            payload = llm.extract_json(
                system=prompts.system_prompt(),
                user=prompts.render(
                    "claims",
                    user_question=run.user_question,
                    ai_answer=run.ai_answer,
                    goals_json=json.dumps([g.to_dict() for g in goals], ensure_ascii=False),
                ),
                validator=model_output_validator(schema, ["claims"]),
            )
            raw = payload.get("claims", [])
            for order, item in enumerate(raw):
                item["created_by"] = "llm"
                item["order"] = order
        except Exception:
            raw = []
    if not raw:
        raw = extract_claims_rule(run, goals, known_entities)

    nodes: List[Node] = []
    for item in raw:
        numerals = item.get("numerals") or []
        value = None
        unit = None
        if numerals:
            first = numerals[0]
            value = first.get("value")
            unit = first.get("unit")
        node = Node(
            id=ids.next("CLM"),
            type="claim",
            content=str(item.get("text", "")).strip(),
            created_by=str(item.get("created_by", "rule")),
            review_status="proposed",
            assertion_strength=str(item.get("assertion_strength", "assertion")),
            evidence_status=None,
            value=value,
            unit=unit,
            scope_limited=False,
            meta={
                "order": item.get("order", 0),
                "numerals": numerals,
                "entities": item.get("entities", []),
                "covers_goals": item.get("covers_goals", []),
                "source_span": item.get("source_span", item.get("text", "")),
            },
        )
        nodes.append(node)
    return nodes
