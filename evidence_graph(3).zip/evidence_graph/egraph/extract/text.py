"""中文文本处理小工具：分句、数值抽取、关键词匹配。

供抽取模块与规则校验模块共用，全部为纯函数，便于单元测试。
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional

from ..verify import units

#: 数字（含千分位）— 允许尾部小数点
_NUM = r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?"

#: 单位词表（长的在前，避免 MPa 被 Pa 抢先匹配）
_UNIT_WORDS = [
    "kWh", "kW", "kPa", "MPa", "ppm", "℃", "°C", "kg", "km", "cm", "mm", "m3",
    "Hz", "bar", "ton", "%", "Pa", "t", "g", "m", "V", "A", "L", "h",
    "小时", "分钟", "千帕", "兆帕", "吨", "件", "个", "台", "只", "根", "次", "人", "倍",
    "摄氏度",
]
_UNIT_ALT = "|".join(re.escape(u) for u in sorted(_UNIT_WORDS, key=len, reverse=True))

#: 匹配「数值 [区间] 单位」，例如 218℃ / 140-190℃ / 21,500 kPa / 5.8%
_NUMERAL_RE = re.compile(
    rf"(?P<a>{_NUM})\s*(?:[-~至到—]\s*(?P<b>{_NUM})\s*)?(?P<unit>{_UNIT_ALT})(?![A-Za-z])"
)

_SENTENCE_SPLIT = re.compile(r"[。！？；\n]+")
_CLAUSE_SPLIT = re.compile(r"[，,、；;。！？\n]+")

#: 推测措辞
INFERENCE_MARKERS = ("可能", "也许", "或许", "大约", "约", "估计", "推测", "看起来", "似乎", "应该", "疑似")
#: 建议措辞
RECOMMENDATION_MARKERS = ("建议", "应当", "应该", "需要", "请", "务必", "可考虑", "宜")
#: 否定发现措辞
NEGATIVE_MARKERS = ("未找到", "未发现", "没有找到", "未检出", "无法确定", "不足以", "暂无法", "未能")
#: 放行/许可动作
RELEASE_MARKERS = ("可以开机", "能开机", "可以启动", "允许启动", "可以放行", "可以吊", "可以作业",
                   "可以投用", "可以开工", "可以正常作业", "没问题")


@dataclass
class Numeral:
    """文本中的带单位数值。"""

    value: float
    unit: str
    raw: str
    upper: Optional[float] = None   # 区间写法时的上界
    span: tuple = (0, 0)

    @property
    def is_range(self) -> bool:
        return self.upper is not None


def to_number(text: str) -> Optional[float]:
    try:
        return float(text.replace(",", ""))
    except (TypeError, ValueError):
        return None


def extract_numerals(text: str) -> List[Numeral]:
    """抽取带单位的数值；不带单位的数字（日期、时间、编号）不会被误抽。"""
    results: List[Numeral] = []
    for match in _NUMERAL_RE.finditer(text or ""):
        value = to_number(match.group("a"))
        if value is None:
            continue
        upper = to_number(match.group("b")) if match.group("b") else None
        results.append(
            Numeral(
                value=value,
                unit=match.group("unit"),
                raw=match.group(0).strip(),
                upper=upper,
                span=match.span(),
            )
        )
    return results


def split_sentences(text: str) -> List[str]:
    return [s.strip() for s in _SENTENCE_SPLIT.split(text or "") if s and s.strip()]


def split_clauses(text: str) -> List[str]:
    return [s.strip() for s in _CLAUSE_SPLIT.split(text or "") if s and s.strip()]


def has_any(text: str, words) -> bool:
    return any(word in text for word in words)


def first_match(text: str, words) -> Optional[str]:
    for word in words:
        if word in text:
            return word
    return None


def keyword_overlap(left: str, right: str, min_len: int = 2) -> float:
    """粗略计算两段文本的词面重叠度，用于目标—结论关联（Jaccard 变体）。"""
    a = _tokenize(left)
    b = _tokenize(right)
    if not a or not b:
        return 0.0
    inter = a & b
    return len(inter) / float(len(a | b))


def _tokenize(text: str) -> set:
    """中文按 2-gram 切分 + 英文/数字按词切分。"""
    tokens = set(re.findall(r"[A-Za-z0-9\-]+", text or ""))
    han = re.sub(r"[^\u4e00-\u9fff]", "", text or "")
    for i in range(len(han) - 1):
        tokens.add(han[i : i + 2])
    return tokens


def normalise_unit(unit: str) -> str:
    """把文本单位规范为展示形式（保留原样，仅用于换算）。"""
    info = units.resolve(unit)
    return info.canonical if info else unit
