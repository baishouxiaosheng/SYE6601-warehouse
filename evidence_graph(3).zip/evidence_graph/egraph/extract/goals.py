"""目标抽取（G1）：把用户问题拆成待回答目标。

规则实现保证无模型也可运行；配置了模型后优先采用模型拆解，
并用结构化输出校验把关，失败自动回落规则结果。
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..loader import RunRecord
from ..models import Goal, IdFactory
from ..validate.schema import load_schema, model_output_validator
from .text import has_any, split_sentences

#: 提问标记
QUESTION_MARKERS = ("吗", "呢", "？", "?", "怎么", "多少", "几", "有没有", "是否",
                    "能不能", "可以吗", "是什么", "干嘛", "为什么", "如何处理", "该怎么办", "几件")
#: 「确认完成」类陈述，虽非疑问句但等价于一个待确认目标
COMPLETION_MARKERS = ("做完", "完成了", "保养完", "检验过", "装好", "修好", "处理完", "验收")

DIAGNOSIS_MARKERS = ("怎么", "为什么", "怎么回事", "原因", "为何", "啥情况")
VALUE_MARKERS = ("多少", "读数", "数值", "大概", "几")
LIST_MARKERS = ("有没有", "有哪些", "有几", "是否已经")
STATUS_MARKERS = ("吗", "是否", "能不能", "可以吗", "正常吗", "好的吗", "可以")


def classify_question(text: str) -> str:
    if has_any(text, DIAGNOSIS_MARKERS):
        return "diagnosis"
    if has_any(text, LIST_MARKERS):
        return "list"
    if has_any(text, VALUE_MARKERS):
        return "value_query"
    if has_any(text, STATUS_MARKERS):
        return "status_query"
    return "unknown"


def _clean_subject(text: str) -> str:
    subject = text
    for marker in ("吗？", "吗?", "吗", "呢", "？", "?", "。"):
        if subject.endswith(marker):
            subject = subject[: -len(marker)]
    return subject.strip(" ，,、")


def extract_goals_rule(run: RunRecord) -> List[Dict[str, Any]]:
    """纯规则拆分目标。

    以**句子**为单位（``。！？；换行``）拆分，不在句子内部按逗号再切，
    避免把「三号锅炉排烟温度偏高了，看看怎么回事」这类问题里承载对象的
    前半句丢掉，只留下「看看怎么回事」。
    """
    question = (run.user_question or "").strip()
    sentences = [s.strip() for s in split_sentences(question) if s.strip()] or ["（空问题）"]

    selected: List[str] = []
    for sentence in sentences:
        if has_any(sentence, QUESTION_MARKERS) or has_any(sentence, COMPLETION_MARKERS):
            selected.append(sentence)
    if not selected:
        # 没有显式问句标记时，整条问题视为一个目标
        selected = [question] if question else ["（空问题）"]

    goals: List[Dict[str, Any]] = []
    for clause in selected:
        goals.append(
            {
                "text": clause,
                "question_type": classify_question(clause),
                "subject": _clean_subject(clause),
                "source_span": clause,
            }
        )
    return goals


def extract_goals(
    run: RunRecord,
    ids: IdFactory,
    llm: Any = None,
    prompts: Any = None,
    schemas_dir: Optional[Path] = None,
) -> List[Goal]:
    """返回 Goal 列表：优先模型，失败回落规则。"""
    raw: List[Dict[str, Any]] = []
    if llm is not None and getattr(llm, "available", False) and prompts is not None and schemas_dir:
        try:
            schema = load_schema("llm_goals", schemas_dir)
            payload = llm.extract_json(
                system=prompts.system_prompt(),
                user=prompts.render(
                    "goals",
                    user_question=run.user_question,
                    visible_context=json.dumps(run.visible_context, ensure_ascii=False),
                ),
                validator=model_output_validator(schema, ["goals"]),
            )
            raw = payload.get("goals", [])
            for item in raw:
                item["created_by"] = "llm"
        except Exception:  # 模型不可用/输出不合规 → 规则兜底
            raw = []
    if not raw:
        raw = extract_goals_rule(run)
        for item in raw:
            item["created_by"] = "rule"

    goals: List[Goal] = []
    for item in raw:
        goals.append(
            Goal(
                id=ids.next("GOAL"),
                text=str(item.get("text", "")).strip(),
                question_type=str(item.get("question_type", "unknown")),
                subject=str(item.get("subject", "") or _clean_subject(str(item.get("text", "")))),
                answered=False,
                coverage_note="",
            )
        )
    return goals
