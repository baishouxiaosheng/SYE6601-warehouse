"""规则约束校验子包（G4）。"""

from .engine import Verifier, VerifyContext, VerifyOutcome, combine_verdicts
from .units import convert, resolve, same_dimension, unit_from_key
from .timeutil import (
    Window,
    business_day_window,
    format_span,
    interval_union,
    parse_iso,
    subtract_window,
    window_from_question,
)

# 注意：不要在此导入 ``egraph.extract.rules``。
# 抽取层会反向依赖本包（text/evidence 需要 units），
# 若在此转发阈值解析会造成 ``extract.text ↔ verify`` 的循环导入。
# 阈值解析请直接从 ``egraph.extract.rules`` 引用。

__all__ = [
    "Verifier",
    "VerifyContext",
    "VerifyOutcome",
    "combine_verdicts",
    "convert",
    "resolve",
    "same_dimension",
    "unit_from_key",
    "Window",
    "business_day_window",
    "format_span",
    "interval_union",
    "parse_iso",
    "subtract_window",
    "window_from_question",
]
