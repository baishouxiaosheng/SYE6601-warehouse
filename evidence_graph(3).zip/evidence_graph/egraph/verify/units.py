"""单位换算与量纲判定（G4 可复算条件的基础）。

* 维护单位别名表与量纲换算因子；
* 支持从字段名推断单位（如 ``system_pressure_kpa`` → kPa）；
* 提供 :func:`convert`，用于把工具返回的读数换算到统一口径后复算区间。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

#: 单位 → (量纲, 规范单位, 相对规范单位的因子)
UNIT_TABLE: Dict[str, Tuple[str, str, float]] = {
    "pa": ("pressure", "Pa", 1.0),
    "kpa": ("pressure", "Pa", 1_000.0),
    "mpa": ("pressure", "Pa", 1_000_000.0),
    "bar": ("pressure", "Pa", 100_000.0),
    "kg": ("mass", "kg", 1.0),
    "g": ("mass", "kg", 0.001),
    "t": ("mass", "kg", 1_000.0),
    "m": ("length", "m", 1.0),
    "cm": ("length", "m", 0.01),
    "mm": ("length", "m", 0.001),
    "km": ("length", "m", 1_000.0),
    "ppm": ("ratio", "ppm", 1.0),
    "percent": ("percent", "%", 1.0),
    "c": ("temperature", "C", 1.0),
    "kw": ("power", "kW", 1.0),
    "kwh": ("energy", "kWh", 1.0),
    "hz": ("frequency", "Hz", 1.0),
    "v": ("voltage", "V", 1.0),
    "a": ("current", "A", 1.0),
    "l": ("volume", "L", 1.0),
    "m3": ("volume", "L", 1_000.0),
    "count": ("count", "count", 1.0),
    "hour": ("time", "h", 1.0),
    "minute": ("time", "h", 1.0 / 60.0),
}

#: 别名 → UNIT_TABLE 的键
UNIT_ALIASES: Dict[str, str] = {
    "c": "c",
    "℃": "c",
    "°c": "c",
    "摄氏度": "c",
    "celsius": "c",
    "度": "c",
    "kpa": "kpa",
    "kilopascal": "kpa",
    "mpa": "mpa",
    "兆帕": "mpa",
    "千帕": "kpa",
    "帕": "pa",
    "pa": "pa",
    "pascal": "pa",
    "bar": "bar",
    "巴": "bar",
    "kg": "kg",
    "千克": "kg",
    "公斤": "kg",
    "克": "g",
    "g": "g",
    "t": "t",
    "ton": "t",
    "tonne": "t",
    "吨": "t",
    "mm": "mm",
    "毫米": "mm",
    "cm": "cm",
    "厘米": "cm",
    "m": "m",
    "米": "m",
    "km": "km",
    "千米": "km",
    "ppm": "ppm",
    "%": "percent",
    "percent": "percent",
    "pct": "percent",
    "kw": "kw",
    "千瓦": "kw",
    "kwh": "kwh",
    "千瓦时": "kwh",
    "度电": "kwh",
    "hz": "hz",
    "v": "v",
    "a": "a",
    "l": "l",
    "升": "l",
    "m3": "m3",
    "件": "count",
    "个": "count",
    "台": "count",
    "只": "count",
    "根": "count",
    "次": "count",
    "人": "count",
    "倍": "count",
    "小时": "hour",
    "min": "minute",
    "分钟": "minute",
    "h": "hour",
}


@dataclass(frozen=True)
class UnitInfo:
    raw: str
    key: str
    dimension: str
    canonical: str
    factor: float


def resolve(unit: Optional[str]) -> Optional[UnitInfo]:
    """把用户书写的单位解析为规范单位信息；无法识别时返回 None。"""
    if unit is None:
        return None
    raw = str(unit).strip()
    if not raw:
        return None
    key = UNIT_ALIASES.get(raw) or UNIT_ALIASES.get(raw.lower())
    if key is None:
        return None
    dimension, canonical, factor = UNIT_TABLE[key]
    return UnitInfo(raw=raw, key=key, dimension=dimension, canonical=canonical, factor=factor)


def same_dimension(unit_a: Optional[str], unit_b: Optional[str]) -> bool:
    a, b = resolve(unit_a), resolve(unit_b)
    return bool(a and b and a.dimension == b.dimension)


def convert(value: float, from_unit: Optional[str], to_unit: Optional[str]) -> Optional[float]:
    """同量纲换算；量纲不一致或单位无法识别时返回 None。"""
    source, target = resolve(from_unit), resolve(to_unit)
    if source is None or target is None or source.dimension != target.dimension:
        return None
    return value * source.factor / target.factor


def to_canonical(value: float, unit: Optional[str]) -> Optional[Tuple[float, str, str]]:
    """换算到规范单位，返回 ``(值, 规范单位, 量纲)``。"""
    info = resolve(unit)
    if info is None:
        return None
    return value * info.factor, info.canonical, info.dimension


#: 从字段名推断单位：按长度降序匹配，避免 ``pa`` 抢先匹配 ``kpa``。
_KEY_UNIT_HINTS: List[Tuple[str, str]] = [
    ("_kwh", "kWh"),
    ("_kpa", "kPa"),
    ("_mpa", "MPa"),
    ("_ppm", "ppm"),
    ("_pct", "%"),
    ("_percent", "%"),
    ("_celsius", "℃"),
    ("_c", "℃"),
    ("_pa", "Pa"),
    ("_tons", "t"),
    ("_ton", "t"),
    ("_kg", "kg"),
    ("_mm", "mm"),
    ("_cm", "cm"),
    ("_m3", "m3"),
    ("_m", "m"),
    ("_kw", "kW"),
    ("_hz", "Hz"),
    ("_kv", "V"),
    ("_v", "V"),
    ("_kpa_g", "kPa"),
]
_KEY_UNIT_HINTS.sort(key=lambda item: len(item[0]), reverse=True)


def unit_from_key(key: str) -> Optional[str]:
    """从字段名推断单位，例如 ``normal_range_kpa`` → kPa。"""
    lowered = key.lower()
    if lowered in {"units", "count", "qty", "quantity", "total_units", "units_count"}:
        return "count"
    for suffix, unit in _KEY_UNIT_HINTS:
        if lowered.endswith(suffix):
            return unit
    if lowered.endswith("_h") or lowered.endswith("_hours"):
        return "h"
    if lowered.endswith("_min") or lowered.endswith("_minutes"):
        return "min"
    return None
