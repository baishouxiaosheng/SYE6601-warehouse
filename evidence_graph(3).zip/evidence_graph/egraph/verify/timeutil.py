"""时间解析与时间窗口工具（G4 时间窗口复算的基础）。

统一使用 ``+08:00`` 时区（日志全部为国内工厂数据）。纯函数，便于单元测试。
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple

TZ = timezone(timedelta(hours=8))

#: 支持的时间书写形式
_FORMATS = (
    "%Y-%m-%dT%H:%M:%S%z",
    "%Y-%m-%dT%H:%M:%S.%f%z",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d",
    "%Y/%m/%d",
)


def parse_iso(text: Optional[str]) -> Optional[datetime]:
    """解析时间字符串；仅有日期时按当天 00:00（+08:00）处理。"""
    if not text:
        return None
    raw = str(text).strip().replace("Z", "+0000")
    if raw.endswith("+08:00"):
        raw = raw.replace("+08:00", "+0800")
    for fmt in _FORMATS:
        try:
            value = datetime.strptime(raw, fmt)
        except ValueError:
            continue
        if value.tzinfo is None:
            value = value.replace(tzinfo=TZ)
        return value.astimezone(TZ)
    return None


@dataclass(frozen=True)
class Window:
    """一个时间窗口。"""

    start: datetime
    end: datetime
    label: str
    anchor_date: Optional[str] = None

    def contains(self, moment: datetime) -> bool:
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=TZ)
        return self.start <= moment.astimezone(TZ) < self.end

    def describe(self) -> str:
        return f"{self.start.isoformat()} ~ {self.end.isoformat()}（{self.label}）"


def window_from_question(question: str, received_at: Optional[str]) -> Optional[Window]:
    """根据问题中的时间指示词与接收时间推断目标时间窗口。"""
    anchor = parse_iso(received_at) or datetime.now(TZ)
    day = anchor.date()
    text = question or ""

    if "前天" in text:
        target = day - timedelta(days=2)
        return _day_window(target, "前天")
    if "昨天" in text or "昨日" in text:
        target = day - timedelta(days=1)
        return _day_window(target, "昨天")
    if "今天" in text or "今日" in text or "当天" in text:
        return _day_window(day, "今天")
    if "本月" in text or "这个月" in text or "当月" in text:
        start = day.replace(day=1)
        if start.month == 12:
            end = start.replace(year=start.year + 1, month=1)
        else:
            end = start.replace(month=start.month + 1)
        return Window(
            start=datetime.combine(start, datetime.min.time(), TZ),
            end=datetime.combine(end, datetime.min.time(), TZ),
            label="本月",
            anchor_date=day.isoformat(),
        )
    return None


def _day_window(target, label: str) -> Window:
    start = datetime.combine(target, datetime.min.time(), TZ)
    return Window(start=start, end=start + timedelta(days=1), label=label, anchor_date=target.isoformat())


def business_day_window(anchor_date: str, attribution_rule: Optional[str]) -> Window:
    """按日志给出的班次归属规则推导“业务日”覆盖区间。

    当日志明确说明「22:00 至次日 06:00 的夜班归属结束当天」时，
    业务日 ``D`` 的完整区间为 ``[D-1 22:00, D 22:00)``；
    否则退化为自然日 ``[D 00:00, D+1 00:00)``。
    """
    date_value = parse_iso(anchor_date)
    if date_value is None:
        raise ValueError(f"无法解析日期：{anchor_date}")
    day = date_value.date()
    rule = attribution_rule or ""
    if "夜班" in rule and ("归属结束当天" in rule or "归属次日" in rule) and "22:00" in rule:
        start = datetime.combine(day - timedelta(days=1), datetime.min.time(), TZ) + timedelta(hours=22)
        return Window(start=start, end=start + timedelta(days=1), label="业务日(前夜班归属当日)", anchor_date=anchor_date)
    return _day_window(day, "自然日")


def interval_union(intervals: List[Tuple[datetime, datetime]]) -> List[Tuple[datetime, datetime]]:
    """合并重叠区间。"""
    items = sorted((s, e) for s, e in intervals if e > s)
    merged: List[Tuple[datetime, datetime]] = []
    for start, end in items:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged


def subtract_window(window: Window, covered: List[Tuple[datetime, datetime]]) -> List[Tuple[datetime, datetime]]:
    """返回目标窗口内尚未被覆盖的区间列表。"""
    gaps: List[Tuple[datetime, datetime]] = []
    cursor = window.start
    for start, end in interval_union(covered):
        if end <= cursor:
            continue
        if start > cursor:
            gaps.append((cursor, min(start, window.end)))
        cursor = max(cursor, end)
        if cursor >= window.end:
            break
    if cursor < window.end:
        gaps.append((cursor, window.end))
    return [(s, e) for s, e in gaps if e > s]


def format_span(span: Tuple[datetime, datetime]) -> str:
    return f"{span[0].isoformat()} ~ {span[1].isoformat()}"
