"""规则约束校验引擎（G4）。

用**代码**判断可复算的条件，包括：对象匹配、时间窗口、单位换算、空值/离线、
分页完整性，以及日志明确给出的状态、阈值和前置条件。
相同证据与规则版本可复算出相同判断；代码找不到依据时保留 ``unknown``。

引擎产出的 :class:`~egraph.models.Check` 是「证据条件」的可复算载体，
图结构生成算法据此组装 AND/OR 路径并推导结论状态。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from config.settings import AppSettings
from ..extract.evidence import EvidenceBundle, Measurement, Signal
from ..loader import RunRecord
from ..models import Check, Gap, Goal, IdFactory, Node
from . import units
from .timeutil import (
    business_day_window,
    format_span,
    interval_union,
    parse_iso,
    subtract_window,
    window_from_question,
)

# ---------------------------------------------------------------- 关键词表

NORMAL_WORDS = ("正常", "在正常范围", "无异常", "符合要求", "符合标准")
ABNORMAL_WORDS = ("超出", "超限", "超标", "偏高", "过高", "异常", "危险", "严重后果", "高于正常")
DISPLAY_WORDS = ("显示", "系统显示", "界面显示")

NEGATIVE_STATUS = {
    "待审批", "待审核", "审核中", "未审批", "未批准", "未通过", "驳回", "拒绝",
    "pending", "rejected", "not_approved", "fail", "failed", "不合格",
}
POSITIVE_STATUS = {
    "已审批", "已批准", "已通过", "通过", "合格", "approved", "passed", "ok", "cleared",
    "completed", "done", "closed", "已完成", "已解除", "正常",
}
OFFLINE_STATUS = {
    "offline", "离线", "no_data", "无数据", "disconnected", "故障停机", "fault", "stopped", "停机",
}

#: 状态断言关键词 → 期望的日志状态取值
STATUS_ASSERTION_PATTERNS: Sequence[Tuple[Tuple[str, ...], Tuple[str, ...]]] = (
    (("已完成", "完成"), ("completed", "done", "closed", "已完成", "完成")),
    (("合格", "通过", "验收"), ("合格", "通过", "pass", "passed", "ok", "approved")),
    (("解除", "锁定已解除"), ("cleared", "已解除", "released", "解除")),
    (("上报", "已上报"), ("reported", "已上报")),
)

SIGNOFF_KEYS = ("signoff", "sign_off", "approved_by", "supervisor_signoff", "technician_signoff")

#: 放行/作业类动作词：断言「可以/能否」执行某项作业的结论，需要做越限与放行判定。
#: 注意不要放入「起重 / 吊装」这类名词，否则设备名称（如「桥式起重机」）
#: 会命中而把「设备检验通过」的陈述误判为越限。
ACTION_HINTS = (
    "可以吊", "能否吊", "可吊", "可以作业", "能否作业", "可以正常作业",
    "可以开机", "能否开机", "可以放行", "能否放行", "可以投用", "能否投用",
    "可以起吊", "允许作业", "能够作业", "可以运行", "能否运行", "可以继续",
)
#: 限值 / 降级使用类陈述词
LIMIT_HINTS = ("限值", "限重", "上限", "下限", "不超过", "不得超过", "额定", "降级")

#: 断言强度为「操作建议」的结论，在图结构里会转化为义务节点（CLM-xxx → OBL-xxx），
#: 它不属于待证命题，因此不参与证据可复算检查，避免缺口引用到已改名的节点。
NON_PROPOSITIONAL_STRENGTHS = ("recommendation",)

#: 结论中被逐字复述的字段值 token：字母数字编码（R2 / REC-204 / SZL-20 / INSP-2026-CR-0215）
_RESTATEMENT_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/+\-]*")

_VERDICT_PRIORITY = {"REFUTE": 0, "CONFLICT": 1, "MISSING_RULE": 2, "UNKNOWN": 3, "SUPPORT": 4}


@dataclass
class VerifyContext:
    run: RunRecord
    settings: AppSettings
    ids: IdFactory
    goals: List[Goal]
    claims: List[Node]
    bundle: EvidenceBundle
    rules: List[Node]


@dataclass
class VerifyOutcome:
    checks: List[Check] = field(default_factory=list)
    facts: List[Node] = field(default_factory=list)
    conditions: List[Node] = field(default_factory=list)
    gaps: List[Gap] = field(default_factory=list)


class Verifier:
    """执行全部确定性检查。"""

    def __init__(self, ctx: VerifyContext) -> None:
        self.ctx = ctx
        self.outcome = VerifyOutcome()
        self._tolerance = float(ctx.settings.verify.get("unit_mismatch_tolerance", 1e-9))
        # 只对命题结论做证据检查：操作建议会转成义务节点（CLM→OBL），
        # 若继续检查会让缺口引用到改名后的节点，产生悬空引用。
        self.ctx.claims = [
            c for c in ctx.claims if c.assertion_strength not in NON_PROPOSITIONAL_STRENGTHS
        ]
        self._claim_by_id = {c.id: c for c in self.ctx.claims}

    # ------------------------------------------------------------ 工具

    def _call(self, record_id: str) -> Dict[str, Any]:
        for call in self.ctx.run.trace:
            if str(call.get("id")) == str(record_id):
                return call
        return {}

    def _node(self, node_id: str) -> Optional[Node]:
        for node in self.ctx.bundle.nodes:
            if node.id == node_id:
                return node
        return None

    def _entity_set(self, node_id: str) -> Set[str]:
        """某个工具调用可识别的对象集合：调用参数 + 返回的 ID 类字段。"""
        entities: Set[str] = set()
        node = self._node(node_id)
        if node and node.arguments:
            for value in node.arguments.values():
                if isinstance(value, str) and len(value) >= 3:
                    entities.add(value)
        for signal in self.ctx.bundle.signals:
            if signal.node_id == node_id and signal.kind == "id" and isinstance(signal.value, str):
                entities.add(signal.value)
        return entities

    def _signals(self, kind: Optional[str] = None) -> List[Signal]:
        return self.ctx.bundle.signals_of(kind) if kind else self.ctx.bundle.signals

    def _add_check(
        self,
        kind: str,
        description: str,
        status: str,
        *,
        evidence_ref: Optional[str] = None,
        locator: Optional[str] = None,
        expected: Any = None,
        actual: Any = None,
        detail: str = "",
        affected: Optional[Sequence[str]] = None,
        verdict: str = "UNKNOWN",
        category: str = "support",
        rule_id: Optional[str] = None,
    ) -> Check:
        check = Check(
            check_id=self.ctx.ids.next("CHK"),
            kind=kind,
            description=description,
            status=status,
            evidence_ref=evidence_ref,
            locator=locator,
            expected=expected,
            actual=actual,
            detail=detail,
            rule_id=rule_id,
            created_by="rule",
            affected_claims=list(affected or []),
            verdict=verdict,
            category=category,
        )
        self.outcome.checks.append(check)
        # 每个可复算检查都对应一个「证据条件」节点（G3），
        # 图算法据此构造 AND/OR 路径并计算共同必要条件。
        self._add_condition(check, description)
        return check

    def _add_condition(self, check: Check, content: str) -> None:
        self.outcome.conditions.append(
            Node(
                id=self.ctx.ids.next("COND"),
                type="condition",
                content=content,
                created_by="rule",
                review_status="verified",
                record_id=check.evidence_ref,
                locator=check.locator,
                evidence_status=check.verdict,
                meta={"check_id": check.check_id, "status": check.status, "kind": check.kind},
            )
        )

    def _add_gap(
        self,
        gap_type: str,
        claims: Sequence[str],
        description: str,
        criticality: str = "MEDIUM",
        target_source: str = "",
        missing_condition: Optional[str] = None,
    ) -> Gap:
        gap = Gap(
            id=self.ctx.ids.next("GAP"),
            type=gap_type,
            affected_claims=list(claims),
            description=description,
            criticality=criticality,
            mandatory=False,
            target_source=target_source,
            missing_condition=missing_condition,
        )
        self.outcome.gaps.append(gap)
        return gap

    def _claims_with(self, predicate) -> List[Node]:
        return [c for c in self.ctx.claims if predicate(c)]

    # ------------------------------------------------------------ 主流程

    def run(self) -> VerifyOutcome:
        self._check_units()
        self._check_ranges()
        self._check_value_assertions()
        self._check_field_restatement()
        self._check_object_identity()
        self._check_status_assertions()
        self._check_display_status()
        self._check_time_window()
        self._check_pagination()
        self._check_availability()
        self._check_limit_rules()
        self._check_rule_applicability()
        self._check_release_preconditions()
        self._check_rule_content_support()
        self._check_inference_basis()
        return self.outcome

    # ------------------------------------------------------------ 1. 单位一致性

    def _check_units(self) -> None:
        numeric = [
            s for s in self._signals("number")
            if isinstance(s.value, (int, float)) and s.unit and units.resolve(s.unit)
        ]
        for claim in self.ctx.claims:
            for numeral in claim.meta.get("numerals", []):
                value = numeral.get("value")
                unit = numeral.get("unit")
                claim_unit = units.resolve(unit)
                if value is None or claim_unit is None:
                    continue
                for signal in numeric:
                    signal_unit = units.resolve(signal.unit)
                    if signal_unit.dimension != claim_unit.dimension:
                        continue
                    # 数值相同才可能是“抄错单位”；数值不同说明结论做过换算，不在此判定。
                    if abs(float(signal.value) - float(value)) > max(self._tolerance, abs(float(value)) * 1e-6):
                        continue
                    # 单位一致 → 正常，跳过。
                    if signal_unit.key == claim_unit.key:
                        continue
                    converted = units.convert(float(value), signal.unit, unit)
                    detail = (
                        f"原始读数 {signal.value} {signal.unit}"
                        + (f"（换算为 {_fmt(converted)} {unit}）" if converted is not None else "")
                        + f"，回答写作 {value} {unit}"
                    )
                    self._add_check(
                        "unit_consistency",
                        "结论中的数值单位应与工具返回字段的单位一致",
                        "violated",
                        evidence_ref=signal.node_id,
                        locator=signal.path,
                        expected={"value": signal.value, "unit": signal.unit},
                        actual={"value": value, "unit": unit},
                        detail=detail + "，数字相同但单位不同，属于可直接证实的单位错误",
                        affected=[claim.id],
                        verdict="REFUTE",
                        category="refute",
                    )
                    break

    # ------------------------------------------------------------ 2. 区间复算

    def _check_ranges(self) -> None:
        matched_claims: Set[str] = set()
        for measurement in self.ctx.bundle.measurements:
            within = measurement.low <= measurement.value <= measurement.high
            unit = measurement.unit or measurement.range_unit or ""
            self.outcome.facts.append(
                Node(
                    id=self.ctx.ids.next("FACT"),
                    type="fact",
                    content=(
                        f"{measurement.key} 读数 {_num(measurement.value)} {unit}，"
                        f"正常区间 {_num(measurement.low)}–{_num(measurement.high)} {unit}，"
                        f"当前{'在正常区间内' if within else '超出正常区间'}"
                    ),
                    created_by="rule",
                    review_status="verified",
                    source_id=measurement.node_id,
                    record_id=measurement.record_id,
                    locator=measurement.value_path,
                    evidence_status="SUPPORT",
                    value=measurement.value,
                    unit=unit,
                    meta={
                        "range": [measurement.low, measurement.high],
                        "within_range": within,
                        "tool": measurement.tool,
                    },
                )
            )
            dimension = units.resolve(measurement.unit or measurement.range_unit)
            if dimension is None:
                continue
            for claim in self.ctx.claims:
                if claim.id in matched_claims:
                    continue
                for numeral in claim.meta.get("numerals", []):
                    numeral_info = units.resolve(numeral.get("unit"))
                    if numeral_info is None or numeral_info.dimension != dimension.dimension:
                        continue
                    wants_abnormal = _has(claim.content, ABNORMAL_WORDS)
                    wants_normal = _has(claim.content, NORMAL_WORDS)
                    if not (wants_abnormal or wants_normal):
                        continue
                    if wants_abnormal:
                        ok = not within
                        detail = (
                            f"读数 {_num(measurement.value)} {unit} 与正常区间 "
                            f"[{_num(measurement.low)}, {_num(measurement.high)}] {unit} 比对："
                            + ("确实超出，结论成立" if ok else "并未超出，结论与证据矛盾")
                        )
                    else:
                        ok = within
                        detail = (
                            f"读数 {_num(measurement.value)} {unit} 与正常区间 "
                            f"[{_num(measurement.low)}, {_num(measurement.high)}] {unit} 比对："
                            + ("在区间内，结论成立" if ok else "超出区间，结论与证据矛盾")
                        )
                    self._add_check(
                        "range_check",
                        "结论中的正常/异常判断应与工具返回的正常区间复算结果一致",
                        "satisfied" if ok else "violated",
                        evidence_ref=measurement.node_id,
                        locator=measurement.value_path,
                        expected={"low": measurement.low, "high": measurement.high},
                        actual=measurement.value,
                        detail=detail,
                        affected=[claim.id],
                        verdict="SUPPORT" if ok else "REFUTE",
                        category="support" if ok else "refute",
                    )
                    matched_claims.add(claim.id)
                    break

        # 有「正常/异常」断言但日志未给出判定基准 → 保留未知（G4）
        for claim in self.ctx.claims:
            if claim.id in matched_claims:
                continue
            numerals = claim.meta.get("numerals") or []
            if not numerals:
                continue
            if not (_has(claim.content, NORMAL_WORDS) or _has(claim.content, ABNORMAL_WORDS)):
                continue
            self._add_check(
                "range_basis_missing",
                "判定“正常/异常”需要日志给出的正常区间或基准",
                "unknown",
                detail="日志中未找到该参数对应的正常区间或判定基准，按规则保留未知状态",
                affected=[claim.id],
                verdict="UNKNOWN",
                category="insufficient",
            )
            self._add_gap(
                "MISSING_DEPENDENCY",
                [claim.id],
                "缺少该参数的正常区间或判定基准，无法复算“正常/异常”结论",
                criticality="MEDIUM",
                target_source="设备运行标准或工艺参数文件",
            )

    # ------------------------------------------------------------ 3. 数值断言匹配

    def _check_value_assertions(self) -> None:
        pool: List[Tuple[Any, Optional[str], str, str]] = []
        for signal in self._signals("number"):
            if isinstance(signal.value, (int, float)):
                pool.append((signal.value, signal.unit, signal.node_id, signal.path))
        for signal in self._signals("pagination"):
            if isinstance(signal.value, (int, float)):
                pool.append((signal.value, "count", signal.node_id, signal.path))

        for claim in self.ctx.claims:
            for numeral in claim.meta.get("numerals", []):
                value, unit = numeral.get("value"), numeral.get("unit")
                info = units.resolve(unit)
                if value is None or info is None:
                    continue
                for candidate, cand_unit, node_id, path in pool:
                    cand_info = units.resolve(cand_unit)
                    if cand_info is None or cand_info.dimension != info.dimension:
                        continue
                    converted = units.convert(float(candidate), cand_unit, unit)
                    if converted is None:
                        continue
                    if abs(converted - float(value)) <= max(self._tolerance, abs(float(value)) * 1e-6):
                        self._add_check(
                            "value_match",
                            "结论中的数值应能在工具返回字段中找到一致读数",
                            "satisfied",
                            evidence_ref=node_id,
                            locator=path,
                            expected=value,
                            actual=candidate,
                            detail=f"字段值 {candidate} {cand_unit or ''} 与结论数值 {value} {unit} 一致",
                            affected=[claim.id],
                            verdict="SUPPORT",
                            category="support",
                        )
                        break

    # ------------------------------------------------------------ 3b. 字段复述

    def _check_field_restatement(self) -> None:
        """结论逐字复述的字符串字段值应能在工具返回中定位。

        数值断言由 ``_check_value_assertions`` 负责；本检查覆盖非数值的
        **编码类字段**（版本号、设备/证书编号、批次、状态码等），
        使「工具调用 → 返回字段 → 证据条件 → 原子结论」这条主轴对
        复述型结论同样成立。找不到对应字段时不做任何判定（保持 unknown）。
        """
        pool = [
            s for s in self.ctx.bundle.signals
            if isinstance(s.value, str) and s.value.strip() and s.kind in ("text", "id", "status")
        ]
        if not pool:
            return
        index: Dict[str, Signal] = {}
        for signal in pool:
            index.setdefault(signal.value.strip().lower(), signal)

        bound: Set[str] = set()
        for claim in self.ctx.claims:
            if claim.id in bound:
                continue
            entities = [str(e) for e in (claim.meta.get("entities") or []) if str(e)]
            for token in _restatement_tokens(claim.content):
                signal = index.get(token.lower())
                if signal is None:
                    continue
                if entities and not self._entity_related(entities, signal.node_id):
                    continue
                self._add_check(
                    "field_restatement",
                    "结论复述的字段值应能在工具返回字段中逐字定位",
                    "satisfied",
                    evidence_ref=signal.node_id,
                    locator=signal.path,
                    expected=token,
                    actual=signal.value,
                    detail=f"字段 {signal.key}={signal.value} 与结论复述的 {token} 逐字一致",
                    affected=[claim.id],
                    verdict="SUPPORT",
                    category="support",
                )
                bound.add(claim.id)
                break

    def _entity_related(self, entities: Sequence[str], node_id: str) -> bool:
        """结论引用的对象是否与该证据节点（参数或返回）相关。"""
        node = self._node(node_id)
        parts: List[str] = [str(v) for v in (node.arguments or {}).values()] if node else []
        parts.extend(
            str(s.value) for s in self.ctx.bundle.signals
            if s.node_id == node_id and isinstance(s.value, str)
        )
        blob = " ".join(parts)
        return any(entity in blob for entity in entities)

    # ------------------------------------------------------------ 4. 对象匹配

    def _check_object_identity(self) -> None:
        known: Set[str] = set()
        for signal in self._signals("id"):
            if isinstance(signal.value, str):
                known.add(signal.value)
        for node in self.ctx.bundle.nodes:
            if node.arguments:
                for value in node.arguments.values():
                    if isinstance(value, str):
                        known.add(value)

        for claim in self.ctx.claims:
            entities = [e for e in (claim.meta.get("entities") or []) if len(str(e)) >= 3]
            if not entities:
                continue
            matched = [e for e in entities if e in known]
            if matched:
                continue
            self._add_check(
                "object_identity",
                "结论引用的对象应出现在工具返回或调用参数中",
                "violated",
                detail=f"结论引用的对象 {sorted(entities)} 未出现在任何工具返回或调用参数中",
                affected=[claim.id],
                verdict="UNKNOWN",
                category="insufficient",
            )
            self._add_gap(
                "MISSING_EVIDENCE",
                [claim.id],
                f"结论引用的对象 {sorted(entities)} 缺少对应的工具返回",
                criticality="MEDIUM",
                target_source="对象档案 / 对应业务系统的查询结果",
            )

    # ------------------------------------------------------------ 5. 状态断言

    def _check_status_assertions(self) -> None:
        status_signals = [s for s in self._signals("status") if isinstance(s.value, str)]
        for claim in self.ctx.claims:
            entities = set(claim.meta.get("entities") or [])
            for keywords, targets in STATUS_ASSERTION_PATTERNS:
                if not _has(claim.content, keywords):
                    continue
                hit: Optional[Signal] = None
                for signal in status_signals:
                    if str(signal.value).strip().lower() not in {t.lower() for t in targets}:
                        continue
                    if entities:
                        node_entities = self._entity_set(signal.node_id)
                        if not (entities & node_entities):
                            continue
                    hit = signal
                    break
                if hit is not None:
                    self._add_check(
                        "status_assertion",
                        "状态类结论应与工具返回的状态字段一致",
                        "satisfied",
                        evidence_ref=hit.node_id,
                        locator=hit.path,
                        expected=list(targets),
                        actual=hit.value,
                        detail=f"字段 {hit.key}={hit.value} 支持该状态断言",
                        affected=[claim.id],
                        verdict="SUPPORT",
                        category="support",
                    )
                else:
                    self._add_check(
                        "status_assertion",
                        "状态类结论应与工具返回的状态字段一致",
                        "unknown",
                        detail=f"日志中未找到与该状态断言（{keywords[0]}）匹配的状态字段",
                        affected=[claim.id],
                        verdict="UNKNOWN",
                        category="insufficient",
                    )
                break

        # 签字确认类
        for claim in self.ctx.claims:
            if not _has(claim.content, ("签字", "确认")):
                continue
            hits = [
                s
                for s in self._signals("status")
                if any(key in s.key.lower() for key in SIGNOFF_KEYS) and s.value is True
            ]
            if hits:
                self._add_check(
                    "signoff_assertion",
                    "签字确认类结论应能在工具返回中找到对应字段",
                    "satisfied",
                    evidence_ref=hits[0].node_id,
                    locator=hits[0].path,
                    actual=True,
                    detail=f"字段 {hits[0].key}=true 支持该确认类断言",
                    affected=[claim.id],
                    verdict="SUPPORT",
                    category="support",
                )

    # ------------------------------------------------------------ 6. 展示状态断言

    def _check_display_status(self) -> None:
        ready = [
            s for s in self._signals("status")
            if s.key.lower() in {"ready_to_start", "ready", "start_ready"} and s.value is True
        ]
        for claim in self.ctx.claims:
            if not _has(claim.content, DISPLAY_WORDS):
                continue
            if not _has(claim.content, ("可以启动", "可启动", "可以开机", "正常", "就绪")):
                continue
            if ready:
                self._add_check(
                    "display_status",
                    "“系统显示…”类结论应能在监控返回中找到对应字段",
                    "satisfied",
                    evidence_ref=ready[0].node_id,
                    locator=ready[0].path,
                    actual=True,
                    detail=f"字段 {ready[0].key}=true 支持该展示类断言",
                    affected=[claim.id],
                    verdict="SUPPORT",
                    category="support",
                )
            else:
                self._add_check(
                    "display_status",
                    "“系统显示…”类结论应能在监控返回中找到对应字段",
                    "unknown",
                    detail="日志中未找到对应的就绪/可启动字段",
                    affected=[claim.id],
                    verdict="UNKNOWN",
                    category="insufficient",
                )

    # ------------------------------------------------------------ 7. 时间窗口

    def _intervals_of(self, record_id: str) -> List[Tuple[datetime, datetime]]:
        call = self._call(record_id)
        arguments = call.get("arguments") or {}
        result = call.get("result") or {}
        intervals: List[Tuple[datetime, datetime]] = []

        if isinstance(result, dict):
            shifts = result.get("shifts")
            if isinstance(shifts, list):
                for shift in shifts:
                    start, end = parse_iso(shift.get("start_at")), parse_iso(shift.get("end_at"))
                    if start and end:
                        intervals.append((start, end))
            for key in ("query_period", "period", "window"):
                value = result.get(key)
                if isinstance(value, str) and "~" in value:
                    left, right = [part.strip() for part in value.split("~", 1)]
                    start, end = parse_iso(left), parse_iso(right)
                    if start and end:
                        intervals.append((start, end))
            for key in ("as_of", "timestamp", "completed_at", "reading_time"):
                moment = parse_iso(result.get(key))
                if moment:
                    intervals.append((moment, moment))
        if not intervals:
            start = parse_iso(arguments.get("date_from") or arguments.get("start"))
            end = parse_iso(arguments.get("date_to") or arguments.get("end"))
            if start and end:
                intervals.append((start, end))
            elif start:
                intervals.append((start, start))
        return intervals

    def _check_time_window(self) -> None:
        window = window_from_question(self.ctx.run.user_question, self.ctx.run.received_at)
        if window is None:
            return

        rule_text = next(
            (s.value for s in self._signals("status") if s.key == "attribution_rule" and isinstance(s.value, str)),
            None,
        )
        if rule_text and window.label in ("昨天", "今天", "前天") and window.anchor_date:
            refined = business_day_window(window.anchor_date, rule_text)
            if refined.start < window.start:
                window = refined

        covered: List[Tuple[datetime, datetime]] = []
        for node in self.ctx.bundle.nodes:
            if node.type != "evidence" or not node.record_id:
                continue
            covered.extend(self._intervals_of(node.record_id))

        missing = subtract_window(window, covered)
        goal_ids = [g.id for g in self.ctx.goals if window.label in g.text or "产量" in g.text or "电费" in g.text]
        affected = [
            c.id
            for c in self.ctx.claims
            if _has(c.content, (window.label,)) or (c.meta.get("covers_goals") and goal_ids)
        ]
        # 只有“整日/整期汇总”类结论才承担时间窗条件：
        # 其它结论（如“今天要吊装…”）不因某个时段未被查询而改变命题状态。
        affected = [
            cid for cid in affected
            if any(w in self._claim_by_id[cid].content for w in ("产量", "合计", "总计", "全天", "昨日", "昨天", "本月", "总"))
        ]
        if not affected:
            return

        if missing:
            detail = (
                "目标时段 " + window.describe() + " 未被现有调用完整覆盖，缺失区间："
                + "；".join(format_span(span) for span in missing)
            )
            check = self._add_check(
                "time_window_coverage",
                "整期汇总类结论要求目标业务时段的全部区间均被工具返回覆盖",
                "violated",
                expected={"start": window.start.isoformat(), "end": window.end.isoformat()},
                actual={"missing": [format_span(s) for s in missing]},
                detail=detail,
                affected=affected,
                verdict="UNKNOWN",
                category="insufficient",
            )
            self._add_gap(
                "MISSING_EVIDENCE",
                affected,
                f"目标时段存在未覆盖区间：{'；'.join(format_span(s) for s in missing)}",
                criticality="HIGH",
                target_source="按业务日补齐对应班次/时段的产量或能耗数据",
                missing_condition=check.check_id,
            )
        elif covered:
            self._add_check(
                "time_window_coverage",
                "整期汇总类结论要求目标业务时段的全部区间均被工具返回覆盖",
                "satisfied",
                expected={"start": window.start.isoformat(), "end": window.end.isoformat()},
                actual={"covered": [format_span(s) for s in interval_union(covered)]},
                detail="目标时段已被现有调用完整覆盖",
                affected=affected,
                verdict="SUPPORT",
                category="support",
            )

    # ------------------------------------------------------------ 8. 分页完整性

    def _check_pagination(self) -> None:
        targets = [
            c for c in self.ctx.claims
            if c.assertion_strength == "negative_finding" or _has(c.content, ("未找到", "未发现", "有没有", "全库"))
        ]
        target_ids = [c.id for c in targets] or [c.id for c in self.ctx.claims]
        for info in self.ctx.bundle.paginations:
            if info.total_pages and info.page and info.total_pages > info.page:
                self._add_check(
                    "pagination_completeness",
                    "全库结论要求翻完所有分页；仅第 1 页不足以支撑“全库无此物料”",
                    "violated",
                    evidence_ref=info.node_id,
                    expected={"total_pages": info.total_pages},
                    actual={"page": info.page, "total_matches": info.total_matches},
                    detail=(
                        f"仅返回第 {info.page}/{info.total_pages} 页"
                        + (f"，共 {info.total_matches} 条匹配" if info.total_matches else "")
                        + "，其余页未检索"
                    ),
                    affected=target_ids,
                    verdict="UNKNOWN",
                    category="insufficient",
                )
                self._add_gap(
                    "INCOMPLETE_RESULT",
                    target_ids,
                    f"检索结果不完整：仅第 {info.page}/{info.total_pages} 页，全库结论缺证",
                    criticality="HIGH",
                    target_source="翻页检索或使用精确筛选条件重新查询",
                )
            if info.note and ("未生效" in info.note or "未应用" in info.note or "不生效" in info.note):
                self._add_check(
                    "filter_effectiveness",
                    "筛选条件应实际生效，否则返回结果的范围与问题不一致",
                    "violated",
                    evidence_ref=info.node_id,
                    actual=info.note,
                    detail="工具返回显式说明筛选参数未生效，返回的是全量结果",
                    affected=target_ids,
                    verdict="UNKNOWN",
                    category="insufficient",
                )
                self._add_gap(
                    "LIMITED_SCOPE",
                    target_ids,
                    "筛选参数未生效，返回范围与问题口径不一致，需使用精确条件重查",
                    criticality="MEDIUM",
                    target_source="使用生效的筛选参数重新查询",
                )

    # ------------------------------------------------------------ 9. 可用性

    def _check_availability(self) -> None:
        for signal in self._signals("status"):
            if isinstance(signal.value, str) and signal.value.strip().lower() in OFFLINE_STATUS:
                related = [
                    c.id for c in self.ctx.claims
                    if any(str(signal.key).split("_")[0] in c.content for _ in [0])
                ] or []
                self._add_check(
                    "availability",
                    "结论若依赖某数据源，则该数据源应在线且返回有效值",
                    "violated",
                    evidence_ref=signal.node_id,
                    locator=signal.path,
                    actual=signal.value,
                    detail=f"字段 {signal.key}={signal.value} 表明数据源不可用",
                    affected=related,
                    verdict="UNKNOWN",
                    category="insufficient",
                )
                self._add_gap(
                    "MISSING_EVIDENCE",
                    related,
                    f"数据源状态为 {signal.value}，依赖该源的结论缺证",
                    criticality="MEDIUM",
                    target_source="恢复数据源或改用其它来源",
                )

    # ------------------------------------------------------------ 10. 阈值/限制

    def _check_limit_rules(self) -> None:
        approval_claims = [
            c for c in self.ctx.claims
            if c.assertion_strength == "approval"
            or _has(c.content, ACTION_HINTS)
            or _has(c.content, LIMIT_HINTS)
        ]
        for rule in self.ctx.rules:
            threshold = (rule.meta or {}).get("threshold")
            if not threshold or not units.resolve(threshold.get("unit")):
                continue
            # “超过190℃即异常”这类是触发条件，不是必须满足的限值，
            # 只有 role == limit（不得超过 / 不低于 / 上限 / 下限）才做越限判定。
            if threshold.get("role") != "limit":
                continue
            dimension = units.resolve(threshold["unit"]).dimension
            op = threshold.get("op", "<=")
            limit = float(threshold["value"])

            offenders: List[Dict[str, Any]] = []
            # (a) 工具返回中的同类数值
            for signal in self._signals("number"):
                if not isinstance(signal.value, (int, float)):
                    continue
                if not units.same_dimension(signal.unit, threshold["unit"]):
                    continue
                value = units.convert(float(signal.value), signal.unit, threshold["unit"])
                if value is None:
                    continue
                if _violates(op, value, limit):
                    offenders.append({"key": signal.key, "value": signal.value, "unit": signal.unit,
                                      "locator": signal.path, "node": signal.node_id})

            # (b) 结论中直接断言的数值
            claim_offenders: List[str] = []
            for claim in approval_claims:
                for numeral in claim.meta.get("numerals", []):
                    info = units.resolve(numeral.get("unit"))
                    if info is None or info.dimension != dimension:
                        continue
                    value = units.convert(float(numeral["value"]), numeral["unit"], threshold["unit"])
                    if value is not None and _violates(op, value, limit):
                        claim_offenders.append(claim.id)
                        offenders.append({"key": "结论数值", "value": numeral["value"],
                                          "unit": numeral["unit"], "locator": None,
                                          "node": claim.id})

            if not offenders:
                continue
            affected = sorted(set(claim_offenders) | {c.id for c in approval_claims if _has(c.content, ACTION_HINTS)})
            self._add_check(
                "limit_threshold",
                "作业/载荷数值应满足日志给出的限值或降级使用限制",
                "violated",
                evidence_ref=rule.source_id,
                locator=rule.locator,
                expected={"op": op, "limit": limit, "unit": threshold["unit"]},
                actual=offenders,
                detail=(
                    f"日志给出的限制为 {op} {limit} {threshold['unit']}，"
                    f"但存在超出该限值的事实："
                    + "；".join(f"{o['key']}={o['value']} {o['unit'] or ''}" for o in offenders)
                ),
                affected=affected,
                verdict="REFUTE",
                category="refute",
                rule_id=rule.id,
            )
            self._add_gap(
                "CONFLICT",
                affected,
                "结论与日志给出的限值/降级使用限制冲突，需按限制重新核算或取得放行依据",
                criticality="HIGH",
                target_source="设备检验限制说明 / 载荷核算审批",
                missing_condition=rule.id,
            )

    # ------------------------------------------------------------ 11. 规则适用性

    def _check_rule_applicability(self) -> None:
        device_models: Set[str] = set()
        for signal in self._signals("id"):
            if isinstance(signal.value, str) and str(signal.key).lower().endswith("model"):
                device_models.add(signal.value)
        if not device_models:
            return
        for rule in self.ctx.rules:
            applicable = (rule.meta or {}).get("applicable_to")
            if not applicable:
                continue
            allowed = {token.strip() for token in re.split(r"[/,、;；\s]+", str(applicable)) if token.strip()}
            if allowed & device_models:
                continue
            affected = [c.id for c in self.ctx.claims if _overlap_entity(c.content, rule.content)]
            affected = affected or [c.id for c in self.ctx.claims if _has(c.content, ("代码", "故障", "手册"))]
            self._add_check(
                "rule_applicability",
                "引用的文档/规则必须适用于当前设备型号",
                "violated",
                evidence_ref=rule.source_id,
                locator=rule.locator,
                expected={"applicable_to": sorted(allowed)},
                actual={"device_models": sorted(device_models)},
                detail=(
                    f"引用依据仅适用于 {sorted(allowed)}，当前设备型号为 {sorted(device_models)}，"
                    "该依据不适用"
                ),
                affected=affected,
                verdict="MISSING_RULE",
                category="rule",
                rule_id=rule.id,
            )
            self._add_gap(
                "MISSING_RULE",
                affected,
                f"缺少适用于 {sorted(device_models)} 的权威依据（现有依据仅适用于 {sorted(allowed)}）",
                criticality="HIGH" if affected else "MEDIUM",
                target_source="该型号对应的手册 / 权威技术依据",
                missing_condition=rule.id,
            )

    # ------------------------------------------------------------ 12. 放行前置条件

    def _check_release_preconditions(self) -> None:
        approval_claims = [
            c for c in self.ctx.claims
            if c.assertion_strength == "approval" and not _has(c.content, DISPLAY_WORDS)
        ]
        if not approval_claims:
            return
        affected = [c.id for c in approval_claims]

        pending: List[Signal] = [
            s for s in self._signals("status")
            if isinstance(s.value, str) and s.value.strip() in NEGATIVE_STATUS
        ]
        auth_rules = [r for r in self.ctx.rules if (r.meta or {}).get("kind") == "authorization_rule"]

        if pending:
            detail = "；".join(f"{s.key}={s.value}（{s.path}）" for s in pending[:4])
            self._add_check(
                "release_precondition",
                "断言“可作业/可放行/可开机”需要日志中存在已生效的放行或审批依据",
                "violated",
                evidence_ref=pending[0].node_id,
                locator=pending[0].path,
                expected="已生效的放行/审批依据",
                actual=[s.value for s in pending],
                detail=f"审批或前置校验尚未完成：{detail}",
                affected=affected,
                verdict="MISSING_RULE",
                category="rule",
            )
            self._add_gap(
                "MISSING_RULE",
                affected,
                "缺少已生效的放行/审批依据（相关审批仍在待办状态）",
                criticality="HIGH",
                target_source="许可审批记录 / 授权人确认",
            )
        else:
            positive = [
                s for s in self._signals("status")
                if isinstance(s.value, str) and s.value.strip().lower() in POSITIVE_STATUS
                and str(s.key).lower() in {"permit_status", "release_status", "approval_status"}
            ]
            if positive:
                self._add_check(
                    "release_precondition",
                    "断言“可作业/可放行/可开机”需要日志中存在已生效的放行或审批依据",
                    "satisfied",
                    evidence_ref=positive[0].node_id,
                    locator=positive[0].path,
                    actual=positive[0].value,
                    detail=f"字段 {positive[0].key}={positive[0].value} 表明放行依据已生效",
                    affected=affected,
                    verdict="SUPPORT",
                    category="support",
                )
            else:
                self._add_check(
                    "release_precondition",
                    "断言“可作业/可放行/可开机”需要日志中存在已生效的放行或审批依据",
                    "unknown",
                    detail=(
                        "日志中未找到适用的放行规则或权威授权记录；"
                        "仅有维保完成/签字确认不足以支撑完整的业务放行结论"
                    ),
                    affected=affected,
                    verdict="MISSING_RULE",
                    category="rule",
                )
                self._add_gap(
                    "MISSING_RULE",
                    affected,
                    "缺少适用的放行规则或权威授权记录，无法判定完整业务放行条件是否满足",
                    criticality="HIGH",
                    target_source=(
                        auth_rules[0].locator if auth_rules else "设备放行审批记录 / 主管授权"
                    ),
                )

    # ------------------------------------------------------------ 13. 依据复述

    def _check_rule_content_support(self) -> None:
        """结论若复述了文档/规则内容，应能在可引用依据中找到来源。"""
        doc_rules = [
            r for r in self.ctx.rules
            if r.excerpt and (r.meta or {}).get("kind") in (
                "threshold_rule", "procedure_rule", "authorization_rule", "limit_rule"
            )
        ]
        if not doc_rules:
            return
        for claim in self.ctx.claims:
            claim_tokens = _tokens(claim.content)
            if not claim_tokens:
                continue
            best = None
            best_score = 0.0
            for rule in doc_rules:
                rule_tokens = _tokens(rule.content)
                if not rule_tokens:
                    continue
                score = len(claim_tokens & rule_tokens) / float(len(claim_tokens))
                if score > best_score:
                    best_score = score
                    best = rule
            if best is None or best_score < _RULE_SUPPORT_THRESHOLD:
                continue
            self._add_check(
                "rule_content_support",
                "复述型结论（如列举手册内容）应能在可引用依据中找到来源",
                "satisfied",
                evidence_ref=best.source_id,
                locator=best.locator,
                expected=best.id,
                actual=round(best_score, 3),
                detail=(
                    f"结论内容与依据 {best.id} 一致（覆盖度 {best_score:.2f}）"
                ),
                affected=[claim.id],
                verdict="SUPPORT",
                category="support",
                rule_id=best.id,
            )

    # ------------------------------------------------------------ 14. 推测依据

    def _check_inference_basis(self) -> None:
        """推测性结论若没有可支持依据，应保留未知并列出补证需求。"""
        for claim in self.ctx.claims:
            if claim.assertion_strength != "inference":
                continue
            supported = any(
                c.verdict == "SUPPORT" and claim.id in (c.affected_claims or [])
                for c in self.outcome.checks
            )
            if supported:
                continue
            check = self._add_check(
                "inference_basis",
                "推测性结论需要现场检查或诊断依据才能确认",
                "unknown",
                detail="该结论是推测，日志未给出可直接确认的现场/诊断依据，按规则保留未知状态",
                affected=[claim.id],
                verdict="UNKNOWN",
                category="insufficient",
            )
            self._add_gap(
                "MISSING_EVIDENCE",
                [claim.id],
                "推测性结论缺少现场检查或诊断依据，无法确认",
                criticality="MEDIUM",
                target_source="现场检查记录 / 设备诊断报告",
                missing_condition=check.check_id,
            )


# ---------------------------------------------------------------- 通用工具


#: 复述型结论与依据文本的包含度阈值
_RULE_SUPPORT_THRESHOLD = 0.45


def _tokens(text: str) -> Set[str]:
    """英文/数字按词、中文按 2-gram 切分，用于复述型结论与依据的匹配。"""
    tokens: Set[str] = set(re.findall(r"[A-Za-z0-9\-]{2,}", text or ""))
    han = re.sub(r"[^\u4e00-\u9fff]", "", text or "")
    for index in range(len(han) - 1):
        tokens.add(han[index : index + 2])
    return tokens


def _restatement_tokens(text: str) -> List[str]:
    """抽出结论中可能复述字段值的编码类 token，长 token 优先（更具区分度）。

    只保留「含数字」或「长度 >= 3」的 token，避免把 ``OK``、``A`` 之类的
    通用短词当作复述证据。
    """
    found: Set[str] = set()
    for match in _RESTATEMENT_TOKEN_RE.finditer(text or ""):
        token = match.group(0).strip("._/-+")
        if len(token) < 2:
            continue
        if not (any(ch.isdigit() for ch in token) or len(token) >= 3):
            continue
        found.add(token)
    return sorted(found, key=lambda t: (len(t), t), reverse=True)


def combine_verdicts(verdicts: Iterable[str]) -> str:
    """按优先级合并多个检查对结论状态的贡献。"""
    items = [v for v in verdicts if v]
    if not items:
        return "UNKNOWN"
    return sorted(items, key=lambda v: _VERDICT_PRIORITY.get(v, 3))[0]


def _violates(op: str, value: float, limit: float) -> bool:
    if op == "<=":
        return value > limit
    if op == "<":
        return value >= limit
    if op == ">=":
        return value < limit
    if op == ">":
        return value <= limit
    return False


def _has(text: str, words) -> bool:
    return any(word in text for word in words)


def _overlap_entity(text: str, other: str) -> bool:
    tokens = set(re.findall(r"[A-Za-z0-9\-]{2,}", text or ""))
    other_tokens = set(re.findall(r"[A-Za-z0-9\-]{2,}", other or ""))
    return bool(tokens & other_tokens)


def _num(value: Any) -> str:
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return str(value)


def _fmt(value: Any) -> str:
    if value is None:
        return "N/A"
    if isinstance(value, float):
        return f"{value:g}"
    return str(value)
