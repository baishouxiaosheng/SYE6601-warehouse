"""日志加载模块。

支持三种输入形态，保证“接其他日志数据也能稳定跑出链路”：

* 单个运行记录（dict，含 case_id/run_id/trace/ai_answer）
* 运行记录数组（本次交付的 60 条日志即为此形态）
* 目录（递归收集 *.json，逐个解析后合并）

加载后统一规范化：补齐缺失字段、校验必需字段，返回 ``RunRecord`` 列表。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Union


@dataclass
class RunRecord:
    """一条规范化的运行记录。"""

    case_id: str
    run_id: str
    user_question: str
    visible_context: Dict[str, Any] = field(default_factory=dict)
    trace: List[Dict[str, Any]] = field(default_factory=list)
    ai_answer: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)

    # -- 派生访问器 ----------------------------------------------------
    @property
    def site(self) -> Optional[str]:
        return self.visible_context.get("site")

    @property
    def workshop(self) -> Optional[str]:
        return self.visible_context.get("workshop")

    @property
    def received_at(self) -> Optional[str]:
        return self.visible_context.get("received_at")

    def tool_calls(self) -> List[Dict[str, Any]]:
        """仅返回工具调用事件（证据只能来自工具返回）。"""
        return [e for e in self.trace if e.get("event") == "tool_call"]

    def progress_notes(self) -> List[Dict[str, Any]]:
        """阶段性说明，仅用于定位过程，不作为证据。"""
        return [e for e in self.trace if e.get("event") != "tool_call"]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "case_id": self.case_id,
            "run_id": self.run_id,
            "user_question": self.user_question,
            "visible_context": self.visible_context,
            "trace": self.trace,
            "ai_answer": self.ai_answer,
        }


REQUIRED_FIELDS = ("case_id", "run_id", "user_question", "trace", "ai_answer")


def normalize_record(raw: Dict[str, Any], index: int = 0) -> RunRecord:
    """把任意来源的记录规范化为 RunRecord；缺失关键字段时抛出 ValueError。"""
    if not isinstance(raw, dict):
        raise ValueError(f"第 {index} 条记录不是对象：{type(raw)!r}")
    missing = [key for key in REQUIRED_FIELDS if key not in raw]
    if missing:
        raise ValueError(f"第 {index} 条记录缺少字段：{missing}")
    trace = raw.get("trace") or []
    if not isinstance(trace, list):
        raise ValueError(f"第 {index} 条记录的 trace 不是数组")
    return RunRecord(
        case_id=str(raw["case_id"]),
        run_id=str(raw["run_id"]),
        user_question=str(raw["user_question"]),
        visible_context=dict(raw.get("visible_context") or {}),
        trace=list(trace),
        ai_answer=str(raw.get("ai_answer") or ""),
        raw=raw,
    )


def _iter_raw_payloads(payload: Any) -> Iterator[Dict[str, Any]]:
    if isinstance(payload, list):
        for item in payload:
            yield item
    elif isinstance(payload, dict):
        # 兼容 {"runs": [...]} / {"records": [...]} 等包装形态
        for key in ("runs", "records", "data", "items"):
            if isinstance(payload.get(key), list):
                yield from payload[key]
                return
        yield payload
    else:
        raise ValueError(f"不支持的日志根类型：{type(payload)!r}")


def load_runs(source: Union[str, Path]) -> List[RunRecord]:
    """从文件或目录加载全部运行记录。"""
    path = Path(source)
    if path.is_dir():
        records: List[RunRecord] = []
        for child in sorted(path.rglob("*.json")):
            records.extend(_load_file(child))
        if not records:
            raise FileNotFoundError(f"目录中未找到可解析的 JSON：{path}")
        return records
    return _load_file(path)


def _load_file(path: Path) -> List[RunRecord]:
    text = path.read_text(encoding="utf-8")
    payload = json.loads(text)
    records = []
    for index, raw in enumerate(_iter_raw_payloads(payload)):
        records.append(normalize_record(raw, index))
    return records


def select_runs(records: Iterable[RunRecord], only: Optional[List[str]]) -> List[RunRecord]:
    """按 case_id 过滤。"""
    items = list(records)
    if not only:
        return items
    wanted = {str(x).strip() for x in only}
    return [r for r in items if r.case_id in wanted]
