"""动态证据图的数据模型。

对应需求说明第 3 节：图中最重要的关系是
``工具调用 → 返回字段 → 证据条件 → 推导规则 → 原子结论``。
本模块用 dataclass 定义节点/边/检查/缺口/路径/补证动作/成绩单结构，
并提供 ``to_dict`` 序列化，供 schemas/ 下的 JSON Schema 校验与可视化使用。
"""

from __future__ import annotations

import itertools
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

# --------------------------------------------------------------------------
# 枚举常量
# --------------------------------------------------------------------------

#: 节点类型
NODE_TYPES = (
    "goal",       # 用户问题中的待回答目标
    "claim",      # 回答中的原子结论
    "fact",       # 由工具返回字段复算/归一得到的事实
    "evidence",   # 工具调用或其返回字段（可定位）
    "rule",       # 业务规则/阈值/前置条件（须有可引用依据）
    "condition",  # 证据条件（对象/时间/状态/单位等）
    "obligation", # 需要执行的动作（补查、复核、人工确认）
    "note",       # 阶段性说明（仅用于定位过程，不作证据）
)

#: 边类型
EDGE_TYPES = (
    "supports",       # 支持
    "refutes",        # 反驳
    "derived_from",   # 由…推导
    "depends_on",     # 依赖
    "uses",           # 使用（结论 → 证据）
    "satisfies",      # 满足某条件
    "alternative_to", # 可替代路径
    "requires",       # 要求（规则 → 条件）
    "checks",         # 校验
    "addresses",      # 补证动作 → 缺口
)

#: 命题证据状态（对应需求 3.5）
EVIDENCE_STATUSES = ("SUPPORT", "REFUTE", "UNKNOWN", "CONFLICT", "MISSING_RULE")

#: 结构审核状态（与命题状态严格区分，见拆解文档第 7 节）
REVIEW_STATUSES = ("proposed", "verified", "rejected", "unresolved")

#: 断言强度：读数 / 一般断言 / 推测 / 审批状态 / 否定发现 / 操作建议
ASSERTION_STRENGTHS = (
    "reading", "assertion", "inference", "approval", "negative_finding", "recommendation",
)

#: 检查状态
CHECK_STATUSES = ("satisfied", "violated", "unknown", "not_applicable")

#: 缺口类型
GAP_TYPES = (
    "MISSING_EVIDENCE",   # 缺证据材料
    "MISSING_RULE",       # 缺适用规则/授权依据
    "MISSING_DEPENDENCY", # 缺判定基准
    "INCOMPLETE_RESULT",  # 结果被截断/分页不完整
    "CONFLICT",           # 来源冲突
    "LIMITED_SCOPE",      # 结论范围受限
)

#: 补证动作类型
ACTION_TYPES = (
    "recompute",      # 用已有字段重算
    "refetch_page",   # 补翻页
    "requery",        # 改参数重查（设备/时段）
    "alt_source",     # 改用可替代来源
    "rule_lookup",    # 查询适用规则
    "manual_confirm", # 请求人工/现场确认
)

#: 动作可执行性
EXECUTABILITY = ("executable", "needs_confirmation", "manual")

#: 一个节点的创建者
CREATORS = ("rule", "llm", "human")


# --------------------------------------------------------------------------
# 核心结构
# --------------------------------------------------------------------------


@dataclass
class Node:
    """证据图节点。"""

    id: str
    type: str
    content: str
    created_by: str = "rule"
    review_status: str = "verified"

    # 证据定位信息（G2）：可回到 run_id / 事件 ID / 原始 JSON 字段路径
    source_id: Optional[str] = None      # 数据源，如 plant_monitor
    record_id: Optional[str] = None      # 事件 ID，如 c1
    locator: Optional[str] = None        # JSON 字段路径，如 trace[c2].result.sensors[0].current_c
    excerpt: Optional[str] = None        # 文档原文摘录
    tool: Optional[str] = None           # 工具名
    arguments: Optional[Dict[str, Any]] = None
    doc_version: Optional[str] = None    # 规则/文档版本、适用对象、时效

    # 断言语义
    evidence_status: Optional[str] = None   # 命题证据状态
    assertion_strength: Optional[str] = None
    related_goals: List[str] = field(default_factory=list)
    scope_limited: bool = False             # 结论是否受限于当前检索范围

    # 数值
    value: Optional[float] = None
    unit: Optional[str] = None

    # 其它结构化细节
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Edge:
    """证据图有向边。``logic`` 仅在逻辑路径边上有值（AND/OR）。"""

    id: str
    source: str
    target: str
    type: str
    logic: Optional[str] = None
    rationale: Optional[str] = None
    created_by: str = "rule"
    review_status: str = "verified"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Check:
    """一次可复算的确定性检查（G4）。"""

    check_id: str
    kind: str
    description: str
    status: str = "unknown"
    target_node: Optional[str] = None
    evidence_ref: Optional[str] = None      # 证据节点 id
    locator: Optional[str] = None           # 原始字段路径
    expected: Any = None
    actual: Any = None
    detail: str = ""
    rule_id: Optional[str] = None
    created_by: str = "rule"
    #: 该检查影响到的结论节点 id
    affected_claims: List[str] = field(default_factory=list)
    #: 该检查对结论状态的贡献（SUPPORT/REFUTE/UNKNOWN/CONFLICT/MISSING_RULE）
    verdict: str = "UNKNOWN"
    #: 检查类别：support / refute / insufficient / conflict / rule
    category: str = "support"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class LogicPath:
    """一条逻辑路径：``AND(conditions)``。多条路径之间为 OR 关系。"""

    path_id: str
    goal_claim: str
    conditions: List[str] = field(default_factory=list)   # 检查/条件节点 id
    satisfied: bool = False
    satisfied_conditions: List[str] = field(default_factory=list)
    missing_conditions: List[str] = field(default_factory=list)
    rationale: str = ""
    created_by: str = "rule"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Gap:
    """证据缺口。"""

    id: str
    type: str
    affected_claims: List[str]
    description: str
    criticality: str = "MEDIUM"           # HIGH / MEDIUM / LOW
    mandatory: bool = False
    target_source: str = ""
    missing_condition: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class PlanAction:
    """补证动作（B1/B2/B3）。"""

    id: str
    action_type: str
    gap_ids: List[str]
    target_claims: List[str]
    tool: Optional[str] = None
    known_arguments: Dict[str, Any] = field(default_factory=dict)
    pending_arguments: Dict[str, Any] = field(default_factory=dict)
    expected_outcome: str = ""
    success_criterion: str = ""           # 用哪个字段路径 + 谓词判定补证成功
    rationale: str = ""
    executability: str = "needs_confirmation"
    priority: int = 3
    replaces_actions: List[str] = field(default_factory=list)
    executed_at: Optional[str] = None
    evidence_time: Optional[str] = None   # 业务时点
    acquired_at: Optional[str] = None     # 取证时间

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Goal:
    """用户问题中的待回答目标。"""

    id: str
    text: str
    question_type: str = "unknown"
    subject: str = ""
    answered: bool = False
    coverage_note: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class EvidenceGraph:
    """单次运行的动态证据图（输出之一，见需求第 6 节）。"""

    graph_version: str
    run_id: str
    case_id: str
    task: Dict[str, Any] = field(default_factory=dict)
    scope_declaration: Dict[str, Any] = field(default_factory=dict)
    goals: List[Goal] = field(default_factory=list)
    nodes: List[Node] = field(default_factory=list)
    edges: List[Edge] = field(default_factory=list)
    checks: List[Check] = field(default_factory=list)
    paths: List[LogicPath] = field(default_factory=list)
    gaps: List[Gap] = field(default_factory=list)
    common_necessary_conditions: List[Dict[str, Any]] = field(default_factory=list)
    changes: List[Dict[str, Any]] = field(default_factory=list)
    limitations: List[str] = field(default_factory=list)
    proposal_status: str = "proposed"

    # -- 便捷访问 ------------------------------------------------------
    def node(self, node_id: str) -> Optional[Node]:
        for item in self.nodes:
            if item.id == node_id:
                return item
        return None

    def nodes_of(self, node_type: str) -> List[Node]:
        return [n for n in self.nodes if n.type == node_type]

    def edges_from(self, node_id: str) -> List[Edge]:
        return [e for e in self.edges if e.source == node_id]

    def edges_to(self, node_id: str) -> List[Edge]:
        return [e for e in self.edges if e.target == node_id]

    def add_node(self, node: Node) -> Node:
        self.nodes.append(node)
        return node

    def add_edge(self, edge: Edge) -> Edge:
        self.edges.append(edge)
        return edge

    def to_dict(self) -> Dict[str, Any]:
        return {
            "graph_version": self.graph_version,
            "run_id": self.run_id,
            "case_id": self.case_id,
            "task": self.task,
            "scope_declaration": self.scope_declaration,
            "goals": [g.to_dict() for g in self.goals],
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "checks": [c.to_dict() for c in self.checks],
            "paths": [p.to_dict() for p in self.paths],
            "gaps": [g.to_dict() for g in self.gaps],
            "common_necessary_conditions": self.common_necessary_conditions,
            "changes": self.changes,
            "limitations": self.limitations,
            "proposal_status": self.proposal_status,
        }


@dataclass
class SupplementaryPlan:
    """补查计划（输出之二，对应需求第 4 节）。"""

    plan_version: str
    run_id: str
    case_id: str
    actions: List[PlanAction] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "plan_version": self.plan_version,
            "run_id": self.run_id,
            "case_id": self.case_id,
            "actions": [a.to_dict() for a in self.actions],
            "notes": self.notes,
        }


@dataclass
class ClaimScore:
    """逐结论评价（对应需求第 5 节）。"""

    claim_id: str
    text: str
    evidence_status: str
    assertion_strength: str
    main_basis: List[str] = field(default_factory=list)
    missing_or_conflicting: List[str] = field(default_factory=list)
    affected_goals: List[str] = field(default_factory=list)
    next_action: str = ""
    severity: Optional[str] = None          # HIGH 表示高风险主结论明确冲突

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Scorecard:
    """置信度成绩单（输出之三）。"""

    scorecard_version: str
    run_id: str
    case_id: str
    rule_version: str
    dimensions: Dict[str, Any] = field(default_factory=dict)
    overall: float = 0.0
    grade: str = "N/A"
    claims: List[ClaimScore] = field(default_factory=list)
    severity_flags: List[Dict[str, Any]] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scorecard_version": self.scorecard_version,
            "run_id": self.run_id,
            "case_id": self.case_id,
            "rule_version": self.rule_version,
            "dimensions": self.dimensions,
            "overall": self.overall,
            "grade": self.grade,
            "claims": [c.to_dict() for c in self.claims],
            "severity_flags": self.severity_flags,
            "notes": self.notes,
        }


# --------------------------------------------------------------------------
# ID 生成
# --------------------------------------------------------------------------


class IdFactory:
    """按前缀生成稳定、递增的节点/边 ID。

    同一批日志重复运行时 ID 序列一致，保证结果可复现（G4 可复算要求）。
    """

    def __init__(self) -> None:
        self._counters: Dict[str, itertools.count] = {}

    def next(self, prefix: str, width: int = 3) -> str:
        counter = self._counters.setdefault(prefix, itertools.count(1))
        return f"{prefix}-{next(counter):0{width}d}"

    def reset(self) -> None:
        self._counters.clear()
