"""可视化模块：把证据图渲染成自包含的 SVG 与 HTML 报告。

设计约束：

* 只用 Python 标准库，输出为**单文件、零外部依赖**的 HTML（内联 CSS 与 SVG），
  便于随工程交付、离线打开、直接放进评审材料；
* 布局为确定性的分层有向图：横轴按
  ``工具调用/返回字段 → 规则/证据条件 → 原子结论 → 目标/义务`` 分层，
  与需求第 3 节的关系主轴一致；节点颜色区分命题证据状态；
* 同一输入必得同一输出，可用于回归比对。

对外入口：

* :func:`render_graph_svg`   证据图 → SVG 字符串
* :func:`render_report`      单次运行 → ``<case_id>_report.html``
* :func:`render_index`       批量运行 → ``index.html`` 总览
* :func:`render_all`         批量渲染并返回路径映射
"""

from __future__ import annotations

from html import escape
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from .models import EvidenceGraph, Node

# --------------------------------------------------------------------------
# 布局常量
# --------------------------------------------------------------------------

BOX_W = 240
BOX_H = 52
COL_GAP = 96
ROW_GAP = 16
MARGIN = 32

#: 节点类型 → 列序号（0 在最上游）
_COLUMN: Dict[str, int] = {
    "evidence": 0,
    "note": 0,
    "fact": 1,
    "rule": 2,
    "condition": 3,
    "claim": 4,
    "goal": 5,
    "obligation": 5,
}

#: 命题证据状态 → 填充色
_STATUS_FILL: Dict[str, str] = {
    "SUPPORT": "#e3f6e9",
    "REFUTE": "#fbe0e0",
    "CONFLICT": "#fdeacd",
    "MISSING_RULE": "#eee3fb",
    "UNKNOWN": "#eef1f5",
}

_STATUS_STROKE: Dict[str, str] = {
    "SUPPORT": "#2e9e5b",
    "REFUTE": "#cf4747",
    "CONFLICT": "#c98a1b",
    "MISSING_RULE": "#7a52c9",
    "UNKNOWN": "#8a94a6",
}

_TYPE_FILL: Dict[str, str] = {
    "goal": "#dbe7fb",
    "obligation": "#fdf1d6",
    "rule": "#eef7e2",
    "condition": "#f2f2f2",
}

_EDGE_COLOR: Dict[str, str] = {
    "supports": "#2e9e5b",
    "refutes": "#cf4747",
    "checks": "#8a94a6",
    "requires": "#7a52c9",
    "derived_from": "#4a7fd0",
    "depends_on": "#4a7fd0",
    "uses": "#4a7fd0",
    "satisfies": "#2e9e5b",
    "alternative_to": "#c98a1b",
    "addresses": "#c98a1b",
}

#: 节点类型中文名
_TYPE_LABEL: Dict[str, str] = {
    "goal": "目标",
    "claim": "结论",
    "fact": "事实",
    "evidence": "证据",
    "rule": "规则",
    "condition": "条件",
    "obligation": "义务",
    "note": "说明",
}


# --------------------------------------------------------------------------
# SVG
# --------------------------------------------------------------------------


def _short(text: str, limit: int = 26) -> str:
    text = (text or "").strip().replace("\n", " ")
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _wrap(text: str, limit: int = 15) -> List[str]:
    text = (text or "").strip().replace("\n", " ")
    lines: List[str] = []
    current = ""
    for char in text:
        current += char
        if len(current) >= limit:
            lines.append(current)
            current = ""
            if len(lines) == 2:
                break
    if current and len(lines) < 2:
        lines.append(current)
    if not lines:
        lines = [""]
    if len("".join(lines)) < len(text) and len(lines) == 2:
        lines[1] = lines[1][:-1] + "…"
    return lines


def _node_fill(node: Node) -> str:
    if node.type == "claim" and node.evidence_status:
        return _STATUS_FILL.get(node.evidence_status, "#eef1f5")
    return _TYPE_FILL.get(node.type, "#f7f8fa")


def _node_stroke(node: Node) -> str:
    if node.type == "claim" and node.evidence_status:
        return _STATUS_STROKE.get(node.evidence_status, "#8a94a6")
    return "#c6ccd6"


def _layout(graph: EvidenceGraph) -> Dict[str, Tuple[float, float]]:
    """按列分层摆放节点，返回 ``node_id -> (x, y, column)``。"""
    columns: Dict[int, List[Node]] = {}
    for node in graph.nodes:
        col = _COLUMN.get(node.type, 3)
        columns.setdefault(col, []).append(node)

    positions: Dict[str, Tuple[float, float]] = {}
    for col, nodes in columns.items():
        ordered = sorted(nodes, key=lambda n: (n.type, n.id))
        for row, node in enumerate(ordered):
            x = MARGIN + col * (BOX_W + COL_GAP)
            y = MARGIN + row * (BOX_H + ROW_GAP)
            positions[node.id] = (x, y)
    return positions


def render_graph_svg(graph: EvidenceGraph, *, title: Optional[str] = None) -> str:
    """把证据图渲染为 SVG 字符串。"""
    positions = _layout(graph)
    if not positions:
        return '<svg xmlns="http://www.w3.org/2000/svg" width="320" height="80"><text x="16" y="40">空图</text></svg>'

    max_x = max(x for x, _ in positions.values()) + BOX_W + MARGIN
    max_y = max(y for _, y in positions.values()) + BOX_H + MARGIN

    parts: List[str] = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {max_x:.0f} {max_y:.0f}" '
        f'width="{max_x:.0f}" height="{max_y:.0f}" font-family="Segoe UI, PingFang SC, Microsoft YaHei, sans-serif">'
    )
    parts.append(
        '<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
        'markerHeight="7" orient="auto-start-reverse">'
        '<path d="M 0 0 L 10 5 L 0 10 z" fill="#8a94a6"/></marker>'
        '<marker id="arrow-red" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
        'markerHeight="7" orient="auto-start-reverse">'
        '<path d="M 0 0 L 10 5 L 0 10 z" fill="#cf4747"/></marker></defs>'
    )
    if title:
        parts.append(
            f'<text x="{MARGIN}" y="18" font-size="15" font-weight="600" fill="#243044">'
            f"{escape(title)}</text>"
        )

    # 边
    parts.append('<g stroke-width="1.6" fill="none">')
    for edge in graph.edges:
        if edge.source not in positions or edge.target not in positions:
            continue
        sx, sy = positions[edge.source]
        tx, ty = positions[edge.target]
        color = _EDGE_COLOR.get(edge.type, "#8a94a6")
        marker = "arrow-red" if edge.type == "refutes" else "arrow"
        if tx >= sx:
            x1, y1 = sx + BOX_W, sy + BOX_H / 2
            x2, y2 = tx, ty + BOX_H / 2
        else:
            x1, y1 = sx, sy + BOX_H / 2
            x2, y2 = tx + BOX_W, ty + BOX_H / 2
        mid = (x1 + x2) / 2
        parts.append(
            f'<path d="M {x1:.0f} {y1:.0f} C {mid:.0f} {y1:.0f}, {mid:.0f} {y2:.0f}, {x2:.0f} {y2:.0f}" '
            f'stroke="{color}" marker-end="url(#{marker})" opacity="0.85"/>'
        )
    parts.append("</g>")

    # 节点
    for node in graph.nodes:
        if node.id not in positions:
            continue
        x, y = positions[node.id]
        fill = _node_fill(node)
        stroke = _node_stroke(node)
        parts.append(
            f'<g><rect x="{x:.0f}" y="{y:.0f}" rx="7" ry="7" width="{BOX_W}" height="{BOX_H}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="1.6"/>'
        )
        tag = f"{node.id} · {_TYPE_LABEL.get(node.type, node.type)}"
        if node.type == "claim" and node.evidence_status:
            tag += f" · {node.evidence_status}"
        parts.append(
            f'<text x="{x + 10:.0f}" y="{y + 16:.0f}" font-size="10.5" fill="#5a6474">'
            f"{escape(tag)}</text>"
        )
        for index, line in enumerate(_wrap(node.content, 16)):
            parts.append(
                f'<text x="{x + 10:.0f}" y="{y + 31 + index * 13:.0f}" font-size="11" fill="#1f2733">'
                f"{escape(line)}</text>"
            )
        parts.append("</g>")

    # 图例
    legend_y = max_y - 22
    parts.append(f'<g font-size="11" fill="#5a6474">')
    parts.append(f'<text x="{MARGIN}" y="{legend_y:.0f}">图例：</text>')
    offset = MARGIN + 44
    for status in ("SUPPORT", "REFUTE", "CONFLICT", "MISSING_RULE", "UNKNOWN"):
        parts.append(
            f'<rect x="{offset}" y="{legend_y - 10:.0f}" width="12" height="12" rx="3" '
            f'fill="{_STATUS_FILL[status]}" stroke="{_STATUS_STROKE[status]}"/>'
        )
        parts.append(f'<text x="{offset + 17}" y="{legend_y:.0f}">{status}</text>')
        offset += 108
    parts.append("</g>")

    parts.append("</svg>")
    return "".join(parts)


# --------------------------------------------------------------------------
# HTML 报告
# --------------------------------------------------------------------------

_CSS = """
:root { color-scheme: light; }
body { margin: 0; padding: 24px 32px 64px; font-family: "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
       color: #1f2733; background: #f6f7f9; }
h1 { font-size: 22px; margin: 0 0 4px; }
h2 { font-size: 17px; margin: 30px 0 10px; padding-bottom: 6px; border-bottom: 1px solid #dde2ea; }
.sub { color: #5a6474; font-size: 13px; margin-bottom: 18px; }
.grid { display: flex; flex-wrap: wrap; gap: 16px; margin: 12px 0 4px; }
.card { background: #fff; border: 1px solid #e2e6ee; border-radius: 10px; padding: 14px 18px; min-width: 170px; }
.card .k { font-size: 12px; color: #5a6474; }
.card .v { font-size: 22px; font-weight: 600; margin-top: 4px; }
table { border-collapse: collapse; width: 100%; background: #fff; font-size: 13px;
        border: 1px solid #e2e6ee; border-radius: 8px; overflow: hidden; }
th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid #eef1f5; vertical-align: top; }
th { background: #f0f2f6; font-weight: 600; }
tr:last-child td { border-bottom: none; }
code, .mono { font-family: Consolas, "Courier New", monospace; font-size: 12px; }
.tag { display: inline-block; padding: 1px 7px; border-radius: 9px; font-size: 11px; border: 1px solid; }
.SUPPORT { background: #e3f6e9; color: #1f7a45; border-color: #2e9e5b; }
.REFUTE { background: #fbe0e0; color: #a92f2f; border-color: #cf4747; }
.CONFLICT { background: #fdeacd; color: #96650f; border-color: #c98a1b; }
.MISSING_RULE { background: #eee3fb; color: #5b3fa0; border-color: #7a52c9; }
.UNKNOWN { background: #eef1f5; color: #5a6474; border-color: #8a94a6; }
.HIGH { background: #fbe0e0; color: #a92f2f; border-color: #cf4747; }
.MEDIUM { background: #fdeacd; color: #96650f; border-color: #c98a1b; }
.svg-wrap { background: #fff; border: 1px solid #e2e6ee; border-radius: 10px; padding: 8px; overflow: auto; }
ul { margin: 6px 0 0 18px; padding: 0; }
li { margin: 3px 0; font-size: 13px; }
a { color: #2f6fbf; text-decoration: none; }
a:hover { text-decoration: underline; }
.muted { color: #5a6474; font-size: 12px; }
"""


def _tag(value: Optional[str]) -> str:
    if not value:
        return '<span class="tag UNKNOWN">—</span>'
    return f'<span class="tag {escape(value)}">{escape(value)}</span>'


def _table(headers: Sequence[str], rows: Sequence[Sequence[str]]) -> str:
    head = "".join(f"<th>{escape(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def _claims_table(graph: EvidenceGraph) -> str:
    rows = []
    for node in graph.nodes_of("claim"):
        rows.append(
            [
                f"<code>{escape(node.id)}</code>",
                escape(node.content),
                _tag(node.evidence_status),
                f"<code>{escape(node.assertion_strength or '')}</code>",
                escape("、".join(node.related_goals) or "—"),
            ]
        )
    if not rows:
        return '<p class="muted">无结论节点。</p>'
    return _table(("结论", "内容", "证据状态", "断言强度", "关联目标"), rows)


def _checks_table(graph: EvidenceGraph) -> str:
    rows = []
    for check in graph.checks:
        rows.append(
            [
                f"<code>{escape(check.check_id)}</code>",
                escape(check.kind),
                escape(check.status),
                _tag(check.verdict),
                escape(check.detail or ""),
                escape(check.locator or check.evidence_ref or "—"),
            ]
        )
    if not rows:
        return '<p class="muted">无检查记录。</p>'
    return _table(("检查", "类型", "状态", "判定", "说明", "定位"), rows)


def _gaps_table(graph: EvidenceGraph) -> str:
    rows = []
    for gap in graph.gaps:
        rows.append(
            [
                f"<code>{escape(gap.id)}</code>",
                escape(gap.type),
                _tag(gap.criticality),
                escape("、".join(gap.affected_claims) or "—"),
                escape(gap.description),
                escape(gap.target_source or "—"),
            ]
        )
    if not rows:
        return '<p class="muted">无证据缺口。</p>'
    return _table(("缺口", "类型", "严重度", "受影响结论", "说明", "建议来源"), rows)


def _paths_table(graph: EvidenceGraph) -> str:
    rows = []
    for path in graph.paths:
        rows.append(
            [
                f"<code>{escape(path.path_id)}</code>",
                f"<code>{escape(path.goal_claim)}</code>",
                "满足" if path.satisfied else "未满足",
                escape("、".join(path.conditions) or "—"),
                escape(path.rationale),
            ]
        )
    if not rows:
        return '<p class="muted">无逻辑路径。</p>'
    return _table(("路径", "结论", "状态", "条件（AND）", "说明"), rows)


def _plan_table(plan: Any) -> str:
    rows = []
    for action in plan.actions:
        rows.append(
            [
                f"<code>{escape(action.id)}</code>",
                escape(action.action_type),
                f"<code>{escape(action.tool or '—')}</code>",
                escape(action.executability),
                escape(",".join(action.gap_ids) or "—"),
                escape(",".join(action.target_claims) or "—"),
                escape(action.expected_outcome or ""),
            ]
        )
    if not rows:
        return '<p class="muted">本次运行未发现需要补证的缺口。</p>'
    return _table(("动作", "类型", "工具", "可执行性", "缺口", "目标结论", "预期产出"), rows)


def _scorecard_table(card: Any) -> str:
    rows = []
    for name, dim in card.dimensions.items():
        rows.append(
            [
                escape(str(dim.get("name", name))),
                f"{dim.get('score', 0):.3f}",
                f"{dim.get('weight', 0):.2f}",
                f"{dim.get('covered', 0)}/{dim.get('total', 0)}",
            ]
        )
    rows.append(["<b>总体</b>", f"<b>{card.overall:.3f}</b>", "—", f"<b>{escape(card.grade)}</b>"])
    return _table(("维度", "得分", "权重", "覆盖 / 案例"), rows)


def _claim_scores_table(card: Any) -> str:
    rows = []
    for item in card.claims:
        rows.append(
            [
                f"<code>{escape(item.claim_id)}</code>",
                escape(item.text),
                _tag(item.evidence_status),
                escape("；".join(item.main_basis) or "—"),
                escape("；".join(item.missing_or_conflicting) or "—"),
                escape(item.next_action or "—"),
            ]
        )
    if not rows:
        return '<p class="muted">无逐结论评分。</p>'
    return _table(("结论", "内容", "状态", "主要依据", "缺失/冲突", "下一步"), rows)


def _flags_table(card: Any) -> str:
    rows = []
    for flag in card.severity_flags:
        rows.append(
            [
                f"<code>{escape(flag.get('claim', ''))}</code>",
                _tag(flag.get("status")),
                _tag(flag.get("severity")),
                escape("、".join(flag.get("high_risk_keywords") or []) or "—"),
                escape(flag.get("content", "")),
            ]
        )
    if not rows:
        return '<p class="muted">无高风险标记。</p>'
    return _table(("结论", "状态", "严重度", "风险词", "内容"), rows)


def _bullets(items: Iterable[str]) -> str:
    items = [i for i in items if i]
    if not items:
        return '<p class="muted">无。</p>'
    return "<ul>" + "".join(f"<li>{escape(i)}</li>" for i in items) + "</ul>"


def render_report(
    artifacts: Any,
    output_dir: Path,
    *,
    back_link: Optional[str] = None,
) -> Path:
    """渲染单次运行的 HTML 报告，返回文件路径。"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    graph = artifacts.graph
    card = artifacts.scorecard
    plan = artifacts.plan
    run = artifacts.run

    navigation = (
        f'<p class="sub"><a href="{escape(back_link)}">← 返回总览</a></p>' if back_link else ""
    )
    notes = "".join(f"<li>{escape(n)}</li>" for n in plan.notes)
    schema_note = (
        "<p class='muted'>产出结构校验：通过（schema_errors 为空）</p>"
        if not artifacts.schema_errors
        else "<p class='muted'>产出结构校验发现问题：" + escape("；".join(artifacts.schema_errors)) + "</p>"
    )

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{escape(run.case_id)} 动态证据图报告</title>
<style>{_CSS}</style>
</head>
<body>
{navigation}
<h1>{escape(run.case_id)}｜工业智能体动态证据图报告</h1>
<p class="sub">
  Run：<code>{escape(run.run_id)}</code>　|　
  站点：{escape(str(run.site or '—'))} / {escape(str(run.workshop or '—'))}　|　
  数据时间：<code>{escape(str(run.received_at or '—'))}</code>
</p>
<p class="sub">用户问题：{escape(run.user_question)}</p>

<div class="grid">
  <div class="card"><div class="k">综合评级</div><div class="v">{escape(card.grade)} · {card.overall:.3f}</div></div>
  <div class="card"><div class="k">结论 / 缺口</div><div class="v">{len(graph.nodes_of('claim'))} / {len(graph.gaps)}</div></div>
  <div class="card"><div class="k">节点 / 边</div><div class="v">{len(graph.nodes)} / {len(graph.edges)}</div></div>
  <div class="card"><div class="k">补证动作</div><div class="v">{len(plan.actions)}</div></div>
  <div class="card"><div class="k">高风险标记</div><div class="v">{len(card.severity_flags)}</div></div>
</div>

<h2>1. 任务与范围</h2>
<p class="sub">任务：<code>{escape(str(graph.task.get('task_id', '')))}</code>　设备/事件：<code>{escape(str(graph.task.get('incident_id') or '—'))}</code></p>
<p class="sub">范围内：{escape("；".join(graph.scope_declaration.get("in_scope", [])))}</p>
<p class="sub">范围外：{escape("；".join(graph.scope_declaration.get("out_of_scope", [])))}</p>

<h2>2. 证据图（G1–G6）</h2>
<div class="svg-wrap">{render_graph_svg(graph)}</div>
<p class="muted">横轴分层：工具调用/返回字段 → 规则/证据条件 → 原子结论 → 目标/义务；节点颜色表示命题证据状态。</p>

<h2>3. 结论与命题证据状态</h2>
{_claims_table(graph)}

<h2>4. 逻辑路径与共同必要条件（G3）</h2>
{_paths_table(graph)}
<p class="muted">以下条件是某一结论所有路径的共同必要条件（任一缺失则该结论不成立）：</p>
{_bullets(f"{c['claim']} ← {c['condition']}（{c['content']}）" for c in graph.common_necessary_conditions)}

<h2>5. 可复算检查（G4）</h2>
{_checks_table(graph)}

<h2>6. 证据缺口</h2>
{_gaps_table(graph)}

<h2>7. 自动补证计划（B1–B3）</h2>
{_plan_table(plan)}
<ul>{notes}</ul>

<h2>8. 置信度成绩单</h2>
{_scorecard_table(card)}
<p class="muted">逐结论：</p>
{_claim_scores_table(card)}
<p class="muted">高风险标记：</p>
{_flags_table(card)}

<h2>9. 边界与说明</h2>
{_bullets(graph.limitations)}
{schema_note}
</body>
</html>
"""
    path = output_dir / f"{run.case_id}_report.html"
    path.write_text(html, encoding="utf-8")
    return path


def render_index(artifacts_list: Sequence[Any], output_dir: Path) -> Path:
    """渲染批量总览 ``index.html``，返回文件路径。"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for art in artifacts_list:
        run = art.run
        card = art.scorecard
        rows.append(
            [
                f'<a href="{escape(run.case_id)}_report.html"><code>{escape(run.case_id)}</code></a>',
                escape(run.user_question),
                _tag(card.grade),
                f"{card.overall:.3f}",
                str(len(art.graph.nodes_of("claim"))),
                str(len(art.graph.gaps)),
                str(len(art.plan.actions)),
                _tag("HIGH") if card.severity_flags else "—",
            ]
        )
    table = _table(("Case", "问题", "评级", "总分", "结论", "缺口", "补证动作", "高风险"), rows)
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>工业智能体动态证据图 · 总览</title>
<style>{_CSS}</style>
</head>
<body>
<h1>工业智能体动态证据图 · 总览</h1>
<p class="sub">共 {len(artifacts_list)} 条运行记录。点击 Case 查看单例报告（含证据图 SVG、逻辑路径、缺口、补证计划与成绩单）。</p>
{table}
</body>
</html>
"""
    path = output_dir / "index.html"
    path.write_text(html, encoding="utf-8")
    return path


def render_all(artifacts_list: Sequence[Any], output_dir: Path) -> Dict[str, Path]:
    """渲染全部报告并返回 ``{"index": ..., "<case_id>": ...}``。"""
    written: Dict[str, Path] = {}
    for art in artifacts_list:
        written[art.run.case_id] = render_report(art, output_dir, back_link="index.html")
    written["index"] = render_index(artifacts_list, output_dir)
    return written
