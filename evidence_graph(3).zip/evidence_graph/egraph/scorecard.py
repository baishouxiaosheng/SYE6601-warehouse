"""置信度成绩单（对应需求第 5 节）。

按三个维度给单次回答打分，并逐条结论给出依据与下一步动作：

* **证据支持度**：断言是否有可定位的证据支持，负向状态（REFUTE/CONFLICT/
  MISSING_RULE）显著拉低得分。
* **问题回应覆盖度**：用户问题拆出的目标有多少被结论覆盖。
* **不确定性表达准确性**：证据不足时是否如实表达不确定、证据充分时是否
  又过度含糊。

分数、权重与评级阈值全部来自 ``config/config.json`` 的 ``scoring`` 段，
便于评审调整；本模块不写死任何业务阈值。
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

from .extract.text import has_any
from .loader import RunRecord
from .models import ClaimScore, EvidenceGraph, Scorecard, SupplementaryPlan

#: 成绩单版本后缀
SCORECARD_VERSION_SUFFIX = "scorecard-v1"

#: 命题状态 → 证据支持度取值
STATUS_VALUE: Dict[str, float] = {
    "SUPPORT": 1.0,
    "UNKNOWN": 0.5,
    "MISSING_RULE": 0.2,
    "CONFLICT": 0.0,
    "REFUTE": 0.0,
}

#: 表达不确定性的措辞
HEDGE_MARKERS = (
    "可能", "也许", "或许", "大约", "估计", "推测", "看起来", "似乎", "疑似",
    "不足以", "无法确定", "尚不能确定", "暂无法", "未能", "不确定", "无法判断",
    "需确认", "待确认", "尚未确认", "不能确定",
)

#: 默认评级阈值（config 缺失时兜底）
DEFAULT_GRADE_THRESHOLDS = {"A": 0.9, "B": 0.75, "C": 0.6, "D": 0.4}
DEFAULT_WEIGHTS = {"evidence_support": 0.5, "question_coverage": 0.3, "uncertainty_accuracy": 0.2}


def build_scorecard(
    *,
    run: RunRecord,
    graph: EvidenceGraph,
    settings: Any,
    plan: Optional[SupplementaryPlan] = None,
) -> Scorecard:
    """计算单次运行的置信度成绩单。"""
    config = (getattr(settings, "scoring", None) or {})
    dims_config = config.get("dimensions", {})
    weights = {
        "evidence_support": _weight(dims_config, "evidence_support"),
        "question_coverage": _weight(dims_config, "question_coverage"),
        "uncertainty_accuracy": _weight(dims_config, "uncertainty_accuracy"),
    }
    grade_thresholds = config.get("grade_thresholds", DEFAULT_GRADE_THRESHOLDS)
    high_risk = list(config.get("high_risk_keywords", []))
    negative_statuses = set(config.get("negative_statuses", ["REFUTE", "CONFLICT", "MISSING_RULE"]))
    asserted = set(config.get("asserted_strengths", ["reading", "assertion", "inference", "approval", "negative_finding"]))

    claims = graph.nodes_of("claim")

    evidence = _score_evidence_support(claims, dims_config, weights["evidence_support"])
    coverage = _score_question_coverage(graph, dims_config, weights["question_coverage"])
    uncertainty = _score_uncertainty(claims, dims_config, weights["uncertainty_accuracy"])

    dimensions = {
        "evidence_support": evidence,
        "question_coverage": coverage,
        "uncertainty_accuracy": uncertainty,
    }
    overall = _clamp(
        sum(d["score"] * d["weight"] for d in dimensions.values()) / (sum(weights.values()) or 1.0)
    )
    grade = _grade(overall, grade_thresholds)

    claim_scores: List[ClaimScore] = []
    severity_flags: List[Dict[str, Any]] = []
    for claim in claims:
        status = claim.evidence_status or "UNKNOWN"
        score = _claim_score(
            claim=claim,
            graph=graph,
            plan=plan,
            high_risk=high_risk,
            asserted=asserted,
        )
        claim_scores.append(score)
        if status in negative_statuses:
            keywords = [k for k in high_risk if k in claim.content]
            is_high = score.assertion_strength == "approval" or bool(keywords)
            severity_flags.append(
                {
                    "claim": claim.id,
                    "status": status,
                    "assertion_strength": score.assertion_strength,
                    "severity": "HIGH" if is_high else "MEDIUM",
                    "high_risk_keywords": keywords,
                    "reason": f"结论状态为 {status}，与证据/规则冲突或缺少判定依据",
                    "content": claim.content,
                }
            )
            if is_high:
                score.severity = "HIGH"

    notes = [
        "三个维度均由可复算检查结果推导，不使用模型主观打分。",
        f"负向状态 {sorted(negative_statuses)} 会直接拉低证据支持度并触发高风险标记。",
        "评级仅供参考，不能替代人工复核；grade 为 N/A 表示未配置评级阈值。",
    ]

    return Scorecard(
        scorecard_version=f"{run.case_id}-{SCORECARD_VERSION_SUFFIX}",
        run_id=run.run_id,
        case_id=run.case_id,
        rule_version=str(getattr(settings, "rule_version", "1.0.0")),
        dimensions=dimensions,
        overall=overall,
        grade=grade,
        claims=claim_scores,
        severity_flags=severity_flags,
        notes=notes,
    )


# --------------------------------------------------------------------------
# 维度计算
# --------------------------------------------------------------------------


def _weight(dims_config: Dict[str, Any], name: str) -> float:
    value = (dims_config.get(name) or {}).get("weight")
    return float(value) if value is not None else DEFAULT_WEIGHTS.get(name, 0.0)


def _thresholds(dims_config: Dict[str, Any], name: str) -> Dict[str, Any]:
    return (dims_config.get(name) or {}).get("thresholds", {}) or {}


def _score_evidence_support(
    claims: Sequence[Any], dims_config: Dict[str, Any], weight: float
) -> Dict[str, Any]:
    details: List[Dict[str, Any]] = []
    values: List[float] = []
    for claim in claims:
        status = claim.evidence_status or "UNKNOWN"
        value = STATUS_VALUE.get(status, 0.5)
        values.append(value)
        details.append({"claim": claim.id, "status": status, "value": round(value, 3)})
    score = _clamp(sum(values) / len(values)) if values else 1.0
    return {
        "name": (dims_config.get("evidence_support") or {}).get("name", "证据支持度"),
        "score": score,
        "weight": weight,
        "thresholds": _thresholds(dims_config, "evidence_support"),
        "covered": sum(1 for v in values if v >= 1.0),
        "total": len(values),
        "details": details,
    }


def _score_question_coverage(
    graph: EvidenceGraph, dims_config: Dict[str, Any], weight: float
) -> Dict[str, Any]:
    claims = graph.nodes_of("claim")
    details: List[Dict[str, Any]] = []
    answered = 0
    for goal in graph.goals:
        covering = [
            c.id for c in claims if goal.id in (c.related_goals or [])
        ]
        goal.answered = bool(covering)
        goal.coverage_note = (
            f"由 {', '.join(covering)} 回应" if covering else "没有结论直接回应此目标"
        )
        if covering:
            answered += 1
        details.append(
            {
                "goal": goal.id,
                "text": goal.text,
                "answered": bool(covering),
                "claims": covering,
            }
        )
    total = len(graph.goals)
    score = _clamp(answered / total) if total else 1.0
    return {
        "name": (dims_config.get("question_coverage") or {}).get("name", "问题回应覆盖度"),
        "score": score,
        "weight": weight,
        "thresholds": _thresholds(dims_config, "question_coverage"),
        "covered": answered,
        "total": total,
        "details": details,
    }


def _score_uncertainty(
    claims: Sequence[Any], dims_config: Dict[str, Any], weight: float
) -> Dict[str, Any]:
    details: List[Dict[str, Any]] = []
    values: List[float] = []
    for claim in claims:
        status = claim.evidence_status or "UNKNOWN"
        hedged = has_any(claim.content, HEDGE_MARKERS)
        expects_uncertainty = status in {"UNKNOWN", "REFUTE", "CONFLICT", "MISSING_RULE"}
        if expects_uncertainty:
            value = 1.0 if hedged else 0.0
            reason = "证据不足但如实表达不确定" if hedged else "证据不足却给出了确定表述"
        else:
            value = 0.5 if hedged else 1.0
            reason = "证据充分且表述肯定" if not hedged else "证据充分但表述过度含糊"
        values.append(value)
        details.append(
            {
                "claim": claim.id,
                "status": status,
                "hedged": hedged,
                "value": value,
                "reason": reason,
            }
        )
    score = _clamp(sum(values) / len(values)) if values else 1.0
    return {
        "name": (dims_config.get("uncertainty_accuracy") or {}).get("name", "不确定性表达准确性"),
        "score": score,
        "weight": weight,
        "thresholds": _thresholds(dims_config, "uncertainty_accuracy"),
        "covered": sum(1 for v in values if v >= 1.0),
        "total": len(values),
        "details": details,
    }


# --------------------------------------------------------------------------
# 逐结论评价
# --------------------------------------------------------------------------


def _claim_score(
    *,
    claim: Any,
    graph: EvidenceGraph,
    plan: Optional[SupplementaryPlan],
    high_risk: Sequence[str],
    asserted: set,
) -> ClaimScore:
    main_basis: List[str] = []
    missing: List[str] = []
    for check in graph.checks:
        if claim.id not in (check.affected_claims or []):
            continue
        locator = check.locator or check.evidence_ref or check.rule_id or ""
        if check.verdict == "SUPPORT":
            main_basis.append(f"{check.kind}@ {locator}：{check.detail}")
        else:
            missing.append(f"{check.verdict}（{check.kind}）：{check.detail}")
    for gap in graph.gaps:
        if claim.id in gap.affected_claims:
            missing.append(f"{gap.id}（{gap.type}）：{gap.description}")

    next_action = ""
    if plan is not None:
        related = [a.id for a in plan.actions if claim.id in a.target_claims]
        if related:
            next_action = "补证动作：" + "、".join(related)

    return ClaimScore(
        claim_id=claim.id,
        text=claim.content,
        evidence_status=claim.evidence_status or "UNKNOWN",
        assertion_strength=claim.assertion_strength or "assertion",
        main_basis=_dedupe(main_basis),
        missing_or_conflicting=_dedupe(missing),
        affected_goals=list(claim.related_goals or []),
        next_action=next_action or "无需补证",
        severity=None,
    )


# --------------------------------------------------------------------------
# 工具
# --------------------------------------------------------------------------


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _grade(overall: float, thresholds: Dict[str, Any]) -> str:
    if not thresholds:
        return "N/A"
    for grade, bound in sorted(thresholds.items(), key=lambda kv: float(kv[1]), reverse=True):
        if overall >= float(bound):
            return str(grade)
    return "E"


def _dedupe(items: Sequence[str]) -> List[str]:
    seen: List[str] = []
    for item in items:
        if item and item not in seen:
            seen.append(item)
    return seen
