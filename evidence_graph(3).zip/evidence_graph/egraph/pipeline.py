"""端到端编排（对应需求第 3–6 节的串接与产出）。

一条链路：

``加载日志 → 拆解目标 → 抽取证据 → 抽取规则 → 抽取原子结论
→ 规则约束校验 → 生成证据图 → 生成补查计划 → 生成置信度成绩单 → 校验/落盘``

模型调用（``llm``）为可选增强：无 Key 时自动降级为纯规则实现，链路依然可复现。
新证据/规则到位后可再次运行并用 :func:`recompute_with_updates` 对比差异（G6）。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Optional, Sequence, Set, Tuple

from config.settings import AppSettings

from .extract.claims import extract_claims
from .extract.evidence import EvidenceBundle, extract_evidence
from .extract.goals import extract_goals
from .extract.rules import extract_rules
from .graph import build_graph, diff_graphs
from .llm.client import NullLLM, build_llm
from .llm.prompts import PromptLibrary
from .loader import RunRecord, load_runs, normalize_record, select_runs
from .models import EvidenceGraph, Goal, IdFactory, Node, Scorecard, SupplementaryPlan
from .plan import build_plan
from .scorecard import build_scorecard
from .validate.schema import artifact_schemas, validate_against
from .verify.engine import Verifier, VerifyContext


@dataclass
class RunArtifacts:
    """单次运行的全部产出。"""

    run: RunRecord
    graph: EvidenceGraph
    plan: SupplementaryPlan
    scorecard: Scorecard
    goals: List[Goal] = field(default_factory=list)
    claims: List[Node] = field(default_factory=list)
    rules: List[Node] = field(default_factory=list)
    bundle: Optional[EvidenceBundle] = None
    llm: Any = None
    schema_errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "case_id": self.run.case_id,
            "graph": self.graph.to_dict(),
            "plan": self.plan.to_dict(),
            "scorecard": self.scorecard.to_dict(),
        }


# --------------------------------------------------------------------------
# 单次运行
# --------------------------------------------------------------------------


def analyze_run(
    run: RunRecord,
    settings: AppSettings,
    *,
    llm: Any = None,
    prompts: Optional[PromptLibrary] = None,
    ids: Optional[IdFactory] = None,
    extra_gaps: Optional[Sequence[Any]] = None,
    global_obligations: Optional[Sequence[str]] = None,
    validate: bool = True,
) -> RunArtifacts:
    """分析单条运行记录，产出证据图 / 补查计划 / 成绩单。"""
    ids = ids or IdFactory()
    prompts = prompts or PromptLibrary(settings.prompts_dir)
    if llm is None:
        llm = NullLLM("rule 模式") if settings.mode == "rule" else build_llm(settings.llm)

    # 1) 目标
    goals = extract_goals(run, ids, llm, prompts, settings.schemas_dir)

    # 2) 证据
    bundle = extract_evidence(run, ids)
    known_entities = _known_entities(bundle)

    # 3) 规则
    rules = extract_rules(bundle, ids)

    # 4) 原子结论
    claims = extract_claims(
        run, goals, ids, known_entities, llm, prompts, settings.schemas_dir
    )

    # 5) 规则约束校验
    ctx = VerifyContext(
        run=run,
        settings=settings,
        ids=ids,
        goals=goals,
        claims=claims,
        bundle=bundle,
        rules=rules,
    )
    outcome = Verifier(ctx).run()

    # 6) 证据图
    graph = build_graph(
        run=run,
        ids=ids,
        goals=goals,
        claims=claims,
        bundle=bundle,
        rules=rules,
        outcome=outcome,
        extra_gaps=extra_gaps,
        global_obligations=global_obligations,
    )

    # 7) 补查计划
    plan = build_plan(run=run, ids=ids, graph=graph, bundle=bundle, settings=settings)

    # 8) 置信度成绩单
    scorecard = build_scorecard(run=run, graph=graph, settings=settings, plan=plan)

    artifacts = RunArtifacts(
        run=run,
        graph=graph,
        plan=plan,
        scorecard=scorecard,
        goals=goals,
        claims=claims,
        rules=rules,
        bundle=bundle,
        llm=llm,
    )

    if validate:
        artifacts.schema_errors = _validate_artifacts(artifacts, settings)
    return artifacts


def _known_entities(bundle: EvidenceBundle) -> Set[str]:
    entities: Set[str] = set()
    for signal in bundle.signals:
        if signal.kind == "id" and isinstance(signal.value, str) and len(signal.value) >= 2:
            entities.add(signal.value)
    for node in bundle.nodes:
        for value in (node.arguments or {}).values():
            if isinstance(value, str) and len(value) >= 2:
                entities.add(value)
    return entities


def _validate_artifacts(artifacts: RunArtifacts, settings: AppSettings) -> List[str]:
    schemas = artifact_schemas(settings.schemas_dir)
    errors: List[str] = []
    for name, payload in (
        ("graph", artifacts.graph.to_dict()),
        ("plan", artifacts.plan.to_dict()),
        ("scorecard", artifacts.scorecard.to_dict()),
    ):
        try:
            validate_against(payload, schemas[name])
        except Exception as exc:  # SchemaError 及其它结构问题
            errors.append(f"{name}: {exc}")
    return errors


# --------------------------------------------------------------------------
# 批量运行
# --------------------------------------------------------------------------


def analyze_all(
    settings: AppSettings,
    *,
    runs: Optional[Sequence[RunRecord]] = None,
    updates: Optional[Dict[str, List[Dict[str, Any]]]] = None,
    validate: bool = True,
) -> List[RunArtifacts]:
    """分析全部（或按 ``settings.only`` 过滤后的）运行记录。

    ``updates`` 用于 G6：形如 ``{case_id: [新增 trace 事件, ...]}``，
    会在原记录上追加证据后重算，并把 :func:`diff_graphs` 的差异写入图的 ``changes``。
    """
    records = list(runs) if runs is not None else load_runs(settings.resolve_log_path())
    records = select_runs(records, settings.only)
    if not records:
        raise ValueError("没有任何运行记录可分析（请检查日志路径与 --only 过滤条件）")

    updates = updates or {}
    artifacts: List[RunArtifacts] = []
    for record in records:
        result = analyze_run(record, settings, validate=validate)
        if record.case_id in updates:
            updated = _apply_updates(record, updates[record.case_id])
            after = analyze_run(updated, settings, validate=validate)
            after.graph.changes = diff_graphs(result.graph, after.graph)
            after.plan.notes.append(
                "本次为补证后重算：changes 记录了相对上一次运行的结论/缺口变化。"
            )
            result = after
        artifacts.append(result)
    return artifacts


def _apply_updates(record: RunRecord, extra_events: Sequence[Dict[str, Any]]) -> RunRecord:
    """把新增证据事件追加到原记录，得到补证后的记录。"""
    raw = json.loads(json.dumps(record.raw, ensure_ascii=False))
    raw.setdefault("trace", [])
    raw["trace"].extend(list(extra_events))
    return normalize_record(raw)


def recompute_with_updates(
    artifacts: RunArtifacts,
    settings: AppSettings,
    updates: Sequence[Dict[str, Any]],
    *,
    validate: bool = True,
) -> RunArtifacts:
    """对单条已有产出做 G6 重算，返回带 ``changes`` 的新产出。"""
    updated = _apply_updates(artifacts.run, updates)
    after = analyze_run(updated, settings, validate=validate)
    after.graph.changes = diff_graphs(artifacts.graph, after.graph)
    after.plan.notes.append("本次为补证后重算，changes 记录相对上一次运行的变化。")
    return after


# --------------------------------------------------------------------------
# 落盘
# --------------------------------------------------------------------------


def write_artifacts(artifacts: RunArtifacts, output_dir: Path) -> Dict[str, Path]:
    """把三类产出写入 ``output_dir``，返回文件路径映射。"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    case = artifacts.run.case_id
    written: Dict[str, Path] = {}
    for kind, payload in (
        ("graph", artifacts.graph.to_dict()),
        ("plan", artifacts.plan.to_dict()),
        ("scorecard", artifacts.scorecard.to_dict()),
    ):
        path = output_dir / f"{case}_{kind}.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        written[kind] = path
    return written


def load_updates(path: Path) -> Dict[str, List[Dict[str, Any]]]:
    """读取重算用新增证据文件，支持 ``{case: [...]}`` 或 ``{"updates": {...}}``。"""
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(payload, dict) and "updates" in payload and isinstance(payload["updates"], dict):
        payload = payload["updates"]
    if not isinstance(payload, dict):
        raise ValueError("新增证据文件应为 {case_id: [事件, ...]} 结构")
    return {str(k): list(v) for k, v in payload.items()}


def iter_summaries(artifacts: Iterable[RunArtifacts]) -> Iterator[Dict[str, Any]]:
    """产出便于打印的摘要行。"""
    for art in artifacts:
        yield {
            "case_id": art.run.case_id,
            "question": art.run.user_question,
            "claims": len(art.graph.nodes_of("claim")),
            "gaps": len(art.graph.gaps),
            "actions": len(art.plan.actions),
            "grade": art.scorecard.grade,
            "overall": art.scorecard.overall,
            "flags": len(art.scorecard.severity_flags),
            "schema_errors": len(art.schema_errors),
        }
